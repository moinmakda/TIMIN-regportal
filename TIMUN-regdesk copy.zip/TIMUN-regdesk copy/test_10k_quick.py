#!/usr/bin/env python3
"""
Quick 10K test to verify the fixes work before running full 100K
"""
import asyncio
import aiohttp
import time

BASE_URL = "http://localhost:8000"
TOTAL_DELEGATES = 10000  # FULL 10K TEST!

async def check_in_delegate(session, reg_number, semaphore):
    async with semaphore:
        try:
            import random
            # USE CAMPUS COORDINATES! Center: 28.658500, 77.212700 with 500m radius
            # Generate coordinates within 400m of campus center (safely inside)
            latitude = 28.658500 + random.uniform(-0.003, 0.003)  # ~±300m
            longitude = 77.212700 + random.uniform(-0.003, 0.003)  # ~±300m
            
            checkin_data = {
                "registration_number": reg_number,
                "latitude": latitude,
                "longitude": longitude
            }
            
            async with session.post(
                f"{BASE_URL}/api/geolocation-checkin",
                json=checkin_data,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:
                if response.status != 200:
                    text = await response.text()
                    print(f"❌ FAILED {reg_number}: {response.status} - {text[:200]}")
                return response.status == 200
        except Exception as e:
            print(f"❌ EXCEPTION {reg_number}: {e}")
            return False

async def main():
    print(f"🔥 Testing {TOTAL_DELEGATES:,} concurrent check-ins...")
    
    semaphore = asyncio.Semaphore(500)  # Reduced from 2000 to 500
    connector = aiohttp.TCPConnector(limit=500, force_close=False)  # Reduced from 2000
    
    start_time = time.time()
    
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = []
        for i in range(TOTAL_DELEGATES):
            reg_number = f"TIMUN{400286 + i:06d}"
            tasks.append(check_in_delegate(session, reg_number, semaphore))
        
        results = await asyncio.gather(*tasks)
    
    end_time = time.time()
    duration = end_time - start_time
    
    success = sum(results)
    failed = len(results) - success
    success_rate = (success / len(results)) * 100
    
    print(f"\n⏱️  Duration: {duration:.2f}s")
    print(f"⚡ Rate: {TOTAL_DELEGATES / duration:.0f} req/s")
    print(f"✅ Success: {success:,}")
    print(f"❌ Failed: {failed:,}")
    print(f"📈 Success Rate: {success_rate:.2f}%")

if __name__ == "__main__":
    asyncio.run(main())
