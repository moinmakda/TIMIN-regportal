# 🌊 Digital Ocean Deployment Guide for The Indraprastha MUN 2025

## Complete Step-by-Step Guide for Beginners

This guide assumes you have **ZERO experience** with server deployment. Follow each step carefully!

---

## Prerequisites

✅ Digital Ocean account with student credits enabled  
✅ Your system code ready (this folder)  
✅ A domain name (optional but recommended)  
✅ 30-60 minutes of time

---

## Part 1: Create Your Droplet (Virtual Server)

### Step 1.1: Login to Digital Ocean

1. Go to https://cloud.digitalocean.com/
2. Login with your student account
3. You should see "$200 in credit" banner

### Step 1.2: Create a New Droplet

1. Click the green **"Create"** button (top right)
2. Select **"Droplets"**

### Step 1.3: Choose Configuration

**Choose an image:**
- Select **"Ubuntu"**
- Version: **"24.04 (LTS) x64"**

**Choose Size:**
- Click **"Basic"** plan
- Select **"Regular"** (not Premium)
- Choose **$6/month** plan:
  - 1 GB RAM
  - 1 vCPU  
  - 25 GB SSD
  - 1000 GB transfer
  
  *(This is perfect for 100-1000 concurrent users)*

**Choose a datacenter region:**
- Select **"Bangalore"** (closest to India for best speed)
- Or **"Singapore"** as backup

**Authentication:**
- Select **"SSH Key"** (recommended)
- Click **"New SSH Key"**

### Step 1.4: Generate SSH Key (Mac)

Open your Mac Terminal and run:

```bash
# Generate SSH key
ssh-keygen -t rsa -b 4096 -C "your-email@example.com"

# Press Enter to save in default location
# Press Enter twice for no passphrase (or create one if you want)

# Display your public key
cat ~/.ssh/id_rsa.pub
```

Copy the ENTIRE output (starts with `ssh-rsa` and ends with your email).

Paste this into Digital Ocean's "New SSH Key" box.  
Give it a name like "My Mac"  
Click **"Add SSH Key"**

### Step 1.5: Finalize Droplet

- **Hostname**: Enter `timun-2025` (or any name you like)
- Click **"Create Droplet"**

Wait 1-2 minutes for creation.

---

## Part 2: Connect to Your Server

### Step 2.1: Get Your Server IP

1. After droplet is created, you'll see it in your dashboard
2. **Copy the IP address** (looks like: `159.203.123.45`)

### Step 2.2: Connect via SSH

Open Terminal on your Mac:

```bash
# Replace YOUR_IP with your actual IP
ssh root@YOUR_IP

# Example:
# ssh root@159.203.123.45
```

Type `yes` when asked about authenticity.

**You're now inside your server!** 🎉

---

## Part 3: Setup Your Server

### Step 3.1: Update System

```bash
# Update package list
apt update

# Upgrade packages
apt upgrade -y

# Install essential tools
apt install -y python3.11 python3.11-venv python3-pip nginx supervisor git curl
```

Wait 2-5 minutes for installation.

### Step 3.2: Install Node.js (for frontend)

```bash
# Add Node.js repository
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -

# Install Node.js
apt install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 3.3: Create Application Directory

```bash
# Create directory
mkdir -p /var/www/timun-2025
cd /var/www/timun-2025
```

---

## Part 4: Upload Your Code

### Step 4.1: From Your Mac Terminal (NEW WINDOW)

Open a **NEW Terminal window** on your Mac (don't close the SSH one).

```bash
# Navigate to your project folder
cd /Users/moinmakda/Desktop/TIMUN-regdesk

# Upload code to server (replace YOUR_IP)
scp -r ./* root@YOUR_IP:/var/www/timun-2025/

# This will take 2-5 minutes
```

**Alternative: Use Git (if you have GitHub repo)**

In your server SSH window:
```bash
cd /var/www/timun-2025
git clone https://github.com/yourusername/timun-regdesk.git .
```

---

## Part 5: Setup Backend

### Step 5.1: Create Python Virtual Environment

Back in your **SSH window**:

```bash
cd /var/www/timun-2025

# Create virtual environment
python3.11 -m venv venv

# Activate it
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
pip install -r backend/requirements.txt
```

Wait 3-5 minutes for installation.

### Step 5.2: Create Environment File

```bash
# Create .env file
nano .env
```

Paste this content (modify as needed):

```env
# Application
ENVIRONMENT=production
DEBUG=false

# Database
DATABASE_URL=sqlite:////var/www/timun-2025/database/mun_complete_system.db

# JWT Secret (generate new one below)
SECRET_KEY=REPLACE_WITH_GENERATED_KEY

# Email (Use your real SMTP credentials)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=announcement.indraprastha@gmail.com
SMTP_PASSWORD=your-app-specific-password
SMTP_USE_TLS=true

# Frontend URL (use your domain or IP)
FRONTEND_URL=http://YOUR_IP

# Server
HOST=0.0.0.0
PORT=8000
WORKERS=4
```

**Generate SECRET_KEY:**
```bash
# In another terminal, run:
python3 -c "import secrets; print(secrets.token_urlsafe(32))"

# Copy the output and replace REPLACE_WITH_GENERATED_KEY above
```

Save file: `Ctrl+X`, then `Y`, then `Enter`

### Step 5.3: Initialize Database

```bash
cd /var/www/timun-2025

# Activate virtual environment
source venv/bin/activate

# Create database directory
mkdir -p database

# Initialize database
python -c "from backend.database import init_database; init_database(); print('✅ Database initialized')"

# Create admin user
python create_admin.py
```

You'll see:
```
✅ Default admin user created successfully!
Username: admin
Password: admin123
```

**IMPORTANT**: Change this password after first login!

---

## Part 6: Setup Frontend

### Step 6.1: Build Frontend

```bash
cd /var/www/timun-2025/frontend-react

# Install dependencies
npm install

# Build production version
npm run build
```

Wait 2-3 minutes. You'll see a `dist/` folder created.

---

## Part 7: Configure Nginx (Web Server)

### Step 7.1: Create Nginx Configuration

```bash
# Create config file
nano /etc/nginx/sites-available/timun
```

Paste this configuration (replace `YOUR_IP` with your actual IP):

```nginx
# Main Server Configuration
server {
    listen 80;
    server_name YOUR_IP;  # Replace with your IP or domain

    # Max upload size for CSV files
    client_max_body_size 50M;

    # Serve React Frontend
    root /var/www/timun-2025/frontend-react/dist;
    index index.html;

    # Frontend - Serve React SPA
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend API - Proxy to FastAPI
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # WebSocket Support
    location /ws/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
    }

    # Health check
    location /health {
        proxy_pass http://127.0.0.1:8000;
        access_log off;
    }

    # Static assets caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

Save: `Ctrl+X`, `Y`, `Enter`

### Step 7.2: Enable Configuration

```bash
# Create symbolic link
ln -s /etc/nginx/sites-available/timun /etc/nginx/sites-enabled/

# Remove default site
rm /etc/nginx/sites-enabled/default

# Test configuration
nginx -t
```

You should see: `configuration file /etc/nginx/nginx.conf test is successful`

```bash
# Reload Nginx
systemctl reload nginx
systemctl enable nginx
```

---

## Part 8: Setup Backend as Service

### Step 8.1: Create Supervisor Configuration

```bash
# Create supervisor config
nano /etc/supervisor/conf.d/timun-backend.conf
```

Paste this:

```ini
[program:timun-backend]
directory=/var/www/timun-2025
command=/var/www/timun-2025/venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000 --workers 4
user=www-data
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stderr_logfile=/var/log/timun/backend.err.log
stdout_logfile=/var/log/timun/backend.out.log
environment=PATH="/var/www/timun-2025/venv/bin"
```

Save: `Ctrl+X`, `Y`, `Enter`

### Step 8.2: Start Service

```bash
# Create log directory
mkdir -p /var/log/timun

# Set permissions
chown -R www-data:www-data /var/www/timun-2025
chmod -R 755 /var/www/timun-2025
chmod 644 /var/www/timun-2025/database/mun_complete_system.db

# Reload supervisor
supervisorctl reread
supervisorctl update
supervisorctl start timun-backend

# Check status
supervisorctl status
```

You should see: `timun-backend  RUNNING   pid 1234, uptime 0:00:05`

---

## Part 9: Setup Firewall

```bash
# Allow SSH (IMPORTANT - do this first!)
ufw allow 22/tcp

# Allow HTTP
ufw allow 80/tcp

# Allow HTTPS (for future SSL)
ufw allow 443/tcp

# Enable firewall
ufw enable

# Check status
ufw status
```

---

## Part 10: Test Your Deployment

### Step 10.1: Test Backend

```bash
# Check if backend is running
curl http://localhost:8000/health
```

Should return: `{"status":"healthy"}`

### Step 10.2: Check Logs

```bash
# View backend logs
tail -50 /var/log/timun/backend.out.log

# Check for errors
tail -50 /var/log/timun/backend.err.log
```

### Step 10.3: Test from Your Browser

On your Mac, open Chrome/Safari:

```
http://YOUR_IP
```

You should see the login page with The Indraprastha MUN logo!

**Login credentials:**
- Username: `admin`
- Password: `admin123`

---

## Part 11: Setup Domain (Optional but Recommended)

### Step 11.1: Get a Domain

Options:
1. **Freenom** (Free): https://www.freenom.com
2. **Namecheap** ($1-10/year): https://www.namecheap.com
3. **GoDaddy**: https://www.godaddy.com

### Step 11.2: Point Domain to Your Server

In your domain registrar's DNS settings:

```
Type: A Record
Name: @
Value: YOUR_IP
TTL: 3600
```

Add another for www:
```
Type: A Record
Name: www
Value: YOUR_IP  
TTL: 3600
```

Wait 5-30 minutes for DNS propagation.

### Step 11.3: Update Nginx for Domain

```bash
nano /etc/nginx/sites-available/timun
```

Change line 3:
```nginx
server_name yourdomain.com www.yourdomain.com;
```

```bash
nginx -t
systemctl reload nginx
```

---

## Part 12: Setup SSL Certificate (HTTPS)

### Step 12.1: Install Certbot

```bash
apt install -y certbot python3-certbot-nginx
```

### Step 12.2: Get SSL Certificate

```bash
# Replace with your domain
certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Follow prompts:
1. Enter your email
2. Agree to terms
3. Choose option 2 (Redirect HTTP to HTTPS)

### Step 12.3: Test Auto-Renewal

```bash
certbot renew --dry-run
```

---

## Part 13: Setup Automatic Backups

### Step 13.1: Create Backup Script

```bash
nano /root/backup-timun.sh
```

Paste:

```bash
#!/bin/bash
BACKUP_DIR="/root/timun-backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
cp /var/www/timun-2025/database/mun_complete_system.db $BACKUP_DIR/db_$DATE.db

# Keep only last 7 days
find $BACKUP_DIR -name "db_*.db" -mtime +7 -delete

echo "Backup completed: $DATE"
```

Save and make executable:

```bash
chmod +x /root/backup-timun.sh
```

### Step 13.2: Schedule Daily Backups

```bash
# Edit crontab
crontab -e
```

Choose nano (option 1), then add:

```cron
# Daily backup at 3 AM
0 3 * * * /root/backup-timun.sh >> /var/log/timun/backup.log 2>&1
```

Save: `Ctrl+X`, `Y`, `Enter`

---

## Part 14: Monitoring & Maintenance

### Useful Commands

```bash
# Check backend status
supervisorctl status timun-backend

# Restart backend
supervisorctl restart timun-backend

# View live logs
tail -f /var/log/timun/backend.out.log

# Check Nginx status
systemctl status nginx

# Restart Nginx
systemctl restart nginx

# Check disk space
df -h

# Check memory usage
free -m

# Check CPU usage
top

# Exit from top: Press 'q'
```

### Check System Health

```bash
# Create monitoring script
nano /root/check-health.sh
```

Paste:

```bash
#!/bin/bash
echo "=== TIMUN System Health ==="
echo "Date: $(date)"
echo ""
echo "Backend Status:"
supervisorctl status timun-backend
echo ""
echo "Nginx Status:"
systemctl is-active nginx
echo ""
echo "Disk Usage:"
df -h /var/www
echo ""
echo "Memory Usage:"
free -h
echo ""
echo "Recent Errors:"
tail -20 /var/log/timun/backend.err.log
```

Make executable:
```bash
chmod +x /root/check-health.sh
```

Run anytime:
```bash
/root/check-health.sh
```

---

## Part 15: Post-Deployment Checklist

✅ **Security:**
- [ ] Change admin password from `admin123`
- [ ] Update SECRET_KEY in `.env`
- [ ] Enable UFW firewall
- [ ] Setup SSL certificate

✅ **Testing:**
- [ ] Login to admin dashboard
- [ ] Upload a test CSV file
- [ ] Send test email
- [ ] Test QR scanner station
- [ ] Test manual check-in

✅ **Monitoring:**
- [ ] Check backend logs
- [ ] Verify database backups
- [ ] Test website from mobile phone
- [ ] Setup uptime monitoring (UptimeRobot)

✅ **Documentation:**
- [ ] Document your domain/IP
- [ ] Save admin credentials securely
- [ ] Note SSH key location
- [ ] Write down droplet IP

---

## Troubleshooting

### Backend Not Starting

```bash
# Check logs
tail -100 /var/log/timun/backend.err.log

# Check if port is in use
netstat -tulpn | grep 8000

# Restart
supervisorctl restart timun-backend
```

### Frontend Not Loading

```bash
# Check Nginx error log
tail -100 /var/log/nginx/error.log

# Verify build exists
ls -la /var/www/timun-2025/frontend-react/dist/

# Reload Nginx
systemctl reload nginx
```

### Database Locked

```bash
# Check WAL mode
sqlite3 /var/www/timun-2025/database/mun_complete_system.db "PRAGMA journal_mode;"

# Should show: wal
```

### Can't Connect via SSH

```bash
# From your Mac, check SSH key
ssh -v root@YOUR_IP

# Reset password via Digital Ocean console
# (Go to Droplet → Access → Reset Root Password)
```

---

## Cost Breakdown

**Monthly Costs:**
- Droplet: $6/month (covered by student credits!)
- Domain: ~$1-2/month (optional)
- SSL: Free (Let's Encrypt)

**Total: $0-8/month** (FREE with student credits!)

---

## Support & Resources

**Digital Ocean:**
- Community Tutorials: https://www.digitalocean.com/community/tutorials
- Support: https://www.digitalocean.com/support

**Your System:**
- Admin Guide: `/var/www/timun-2025/ADMIN_GUIDE.md`
- API Docs: `http://YOUR_IP/docs` (FastAPI auto-docs)

**Emergency Contact:**
- Check logs: `/var/log/timun/`
- System health: `/root/check-health.sh`

---

## 🎉 Congratulations!

Your **The Indraprastha MUN 2025** registration system is now LIVE!

**Next Steps:**
1. Visit `http://YOUR_IP` (or your domain)
2. Login with `admin` / `admin123`
3. **IMMEDIATELY change password**
4. Upload your delegate CSV
5. Test all features
6. Share the link with your team!

**Your system can handle 1000+ concurrent users!** 🚀

---

**Good luck with TIMUN 2025!** 🎊

