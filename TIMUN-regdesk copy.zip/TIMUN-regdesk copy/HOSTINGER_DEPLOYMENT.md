# 🌐 Hostinger Deployment Guide for TIMUN Registration System

## Overview

This guide will help you deploy the TIMUN MUN Attendance System on Hostinger hosting. The system consists of:
- **Backend**: FastAPI (Python) REST API with WebSocket support
- **Frontend**: React SPA (Single Page Application)
- **Database**: SQLite (or upgrade to PostgreSQL/MySQL)

## Prerequisites

- Hostinger VPS or Business hosting plan (Shared hosting may not support Python applications)
- SSH access to your server
- Domain name configured
- Python 3.11+ support on server

## Hostinger Plan Recommendations

### Option 1: VPS Hosting (Recommended)
- **Best for**: Production deployment with 100K+ users
- **Plan**: VPS 1 or higher
- **Benefits**: Full control, Python support, systemd services, SSL certificates
- **Cost**: ~$5-10/month

### Option 2: Business Hosting
- **Best for**: Smaller deployments
- **Plan**: Business hosting with SSH access
- **Limitations**: May have restricted Python version, limited process control
- **Cost**: ~$4-7/month

## Step-by-Step Deployment

### 1. Prepare Your Hostinger VPS

```bash
# SSH into your Hostinger server
ssh root@your-server-ip

# Update system packages
apt update && apt upgrade -y

# Install required packages
apt install -y python3.11 python3.11-venv python3-pip nginx supervisor git
```

### 2. Set Up Application Directory

```bash
# Create application directory
mkdir -p /var/www/timun-regdesk
cd /var/www/timun-regdesk

# Clone or upload your code
# Option A: Upload via SCP/SFTP
# scp -r /Users/moinmakda/Desktop/TIMUN-regdesk/* root@your-server-ip:/var/www/timun-regdesk/

# Option B: Git clone (if you have a repository)
# git clone https://github.com/yourusername/timun-regdesk.git .
```

### 3. Set Up Python Virtual Environment

```bash
cd /var/www/timun-regdesk

# Create virtual environment
python3.11 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install -r backend/requirements.txt

# Verify installation
python -c "import fastapi; import uvicorn; print('✓ Dependencies installed')"
```

### 4. Configure Environment Variables

```bash
# Create .env file
nano /var/www/timun-regdesk/.env
```

Add the following content:

```env
# Application Settings
ENVIRONMENT=production
DEBUG=false

# Database Configuration
DATABASE_URL=sqlite:////var/www/timun-regdesk/database/mun_complete_system.db
# Or use MySQL/PostgreSQL:
# DATABASE_URL=mysql://username:password@localhost/timun_db
# DATABASE_URL=postgresql://username:password@localhost/timun_db

# JWT Secret (Generate with: python -c "import secrets; print(secrets.token_urlsafe(32))")
SECRET_KEY=your-super-secret-key-here-change-this

# Email Configuration (for sending confirmation emails)
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=587
SMTP_USERNAME=noreply@yourdomain.com
SMTP_PASSWORD=your-email-password
SMTP_USE_TLS=true

# Frontend URL
FRONTEND_URL=https://yourdomain.com

# Server Configuration
HOST=0.0.0.0
PORT=8000
WORKERS=4
```

Save with `Ctrl+X`, then `Y`, then `Enter`.

### 5. Initialize Database and Create Admin

```bash
cd /var/www/timun-regdesk

# Initialize database
source venv/bin/activate
python create_admin.py

# You should see:
# ✅ Default admin user created successfully!
# Username: admin
# Password: admin123
```

### 6. Build Frontend

```bash
cd /var/www/timun-regdesk/frontend-react

# Install Node.js if not already installed
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install dependencies
npm install

# Build for production
npm run build

# The built files will be in /var/www/timun-regdesk/frontend-react/dist
```

### 7. Configure Nginx as Reverse Proxy

```bash
# Create Nginx configuration
nano /etc/nginx/sites-available/timun-regdesk
```

Add the following configuration:

```nginx
# HTTP - Redirect to HTTPS
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

# HTTPS
server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    # SSL Configuration (Hostinger provides free SSL)
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    
    # SSL Security Settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;

    # Serve Frontend (React SPA)
    root /var/www/timun-regdesk/frontend-react/dist;
    index index.html;

    # Max upload size for CSV files
    client_max_body_size 50M;

    # Frontend - Serve React app
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend API - Proxy to FastAPI
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # WebSocket Support
    location /ws/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 86400;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:8000;
        access_log off;
    }

    # Static assets caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
}
```

Enable the site:

```bash
# Create symbolic link
ln -s /etc/nginx/sites-available/timun-regdesk /etc/nginx/sites-enabled/

# Test configuration
nginx -t

# If test passes, reload Nginx
systemctl reload nginx
```

### 8. Set Up SSL Certificate (Free with Hostinger)

```bash
# Install Certbot
apt install -y certbot python3-certbot-nginx

# Get SSL certificate
certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Follow the prompts and provide your email
```

### 9. Configure Supervisor to Run Backend

Create a supervisor configuration:

```bash
nano /etc/supervisor/conf.d/timun-backend.conf
```

Add:

```ini
[program:timun-backend]
directory=/var/www/timun-regdesk
command=/var/www/timun-regdesk/venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000 --workers 4
user=www-data
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stderr_logfile=/var/log/timun/backend.err.log
stdout_logfile=/var/log/timun/backend.out.log
environment=PATH="/var/www/timun-regdesk/venv/bin"

[program:timun-backend-websocket]
directory=/var/www/timun-regdesk
command=/var/www/timun-regdesk/venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8001 --workers 1
user=www-data
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stderr_logfile=/var/log/timun/websocket.err.log
stdout_logfile=/var/log/timun/websocket.out.log
environment=PATH="/var/www/timun-regdesk/venv/bin"
```

Create log directory and start services:

```bash
# Create log directory
mkdir -p /var/log/timun
chown www-data:www-data /var/log/timun

# Set proper permissions
chown -R www-data:www-data /var/www/timun-regdesk
chmod -R 755 /var/www/timun-regdesk
chmod 600 /var/www/timun-regdesk/database/mun_complete_system.db

# Reload supervisor
supervisorctl reread
supervisorctl update
supervisorctl start timun-backend
supervisorctl status
```

### 10. Verify Deployment

```bash
# Check backend is running
curl http://localhost:8000/health

# Check logs
tail -f /var/log/timun/backend.out.log

# Check Nginx status
systemctl status nginx

# Check Supervisor status
supervisorctl status
```

### 11. Update Frontend API URL

Before building the frontend, make sure to update the API URL:

```bash
# Edit the API configuration
nano /var/www/timun-regdesk/frontend-react/src/services/api.ts
```

Update the base URL:

```typescript
const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://yourdomain.com/api';
```

Or set environment variable:

```bash
# Create .env file in frontend-react/
echo "VITE_API_URL=https://yourdomain.com/api" > /var/www/timun-regdesk/frontend-react/.env.production

# Rebuild
cd /var/www/timun-regdesk/frontend-react
npm run build
```

### 12. Post-Deployment Security

```bash
# Change default admin password
# Login to https://yourdomain.com/admin
# Username: admin
# Password: admin123
# Then change password immediately!

# Set up firewall
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw enable

# Set up automatic backups
crontab -e
```

Add to crontab:

```cron
# Daily database backup at 2 AM
0 2 * * * cp /var/www/timun-regdesk/database/mun_complete_system.db /var/www/timun-regdesk/database/backups/mun_$(date +\%Y\%m\%d).db

# Weekly log rotation
0 0 * * 0 find /var/log/timun/*.log -mtime +7 -delete
```

## Troubleshooting

### Backend Not Starting

```bash
# Check logs
tail -100 /var/log/timun/backend.err.log

# Check if port is in use
netstat -tulpn | grep 8000

# Restart service
supervisorctl restart timun-backend
```

### Database Permission Errors

```bash
# Fix permissions
chown www-data:www-data /var/www/timun-regdesk/database/mun_complete_system.db
chmod 644 /var/www/timun-regdesk/database/mun_complete_system.db
```

### Frontend Not Loading

```bash
# Check Nginx error log
tail -100 /var/log/nginx/error.log

# Verify build exists
ls -la /var/www/timun-regdesk/frontend-react/dist/

# Test Nginx config
nginx -t
```

### WebSocket Connection Issues

```bash
# Check if WebSocket endpoint is accessible
curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" http://localhost:8000/ws/admin

# Check Nginx WebSocket configuration
nginx -T | grep -A 10 "location /ws"
```

## Maintenance Commands

```bash
# View backend logs
tail -f /var/log/timun/backend.out.log

# Restart backend
supervisorctl restart timun-backend

# Reload Nginx
systemctl reload nginx

# Backup database
cp /var/www/timun-regdesk/database/mun_complete_system.db ~/backup-$(date +%Y%m%d).db

# Update application
cd /var/www/timun-regdesk
git pull  # if using git
supervisorctl restart timun-backend
```

## Performance Optimization

### Enable Gzip Compression

Add to Nginx config:

```nginx
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
```

### Database Optimization (If using PostgreSQL)

```bash
# Install PostgreSQL
apt install -y postgresql postgresql-contrib

# Create database
sudo -u postgres createdb timun_db
sudo -u postgres createuser timun_user
sudo -u postgres psql -c "ALTER USER timun_user WITH PASSWORD 'strong_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE timun_db TO timun_user;"

# Update DATABASE_URL in .env
DATABASE_URL=postgresql://timun_user:strong_password@localhost/timun_db
```

### Enable Redis for Session Management (Optional)

```bash
apt install -y redis-server
systemctl enable redis-server
systemctl start redis-server
```

## Monitoring & Alerts

### Set Up Uptime Monitoring

1. Use Hostinger's built-in monitoring
2. Or set up external monitoring: UptimeRobot, Pingdom, etc.
3. Monitor these endpoints:
   - `https://yourdomain.com/health`
   - `https://yourdomain.com/` (frontend)

### Log Monitoring

```bash
# Install logwatch for daily summaries
apt install -y logwatch

# Or use paid service like Papertrail, Loggly
```

## Cost Estimate

- **VPS Hosting**: $5-10/month
- **Domain Name**: $10-15/year
- **SSL Certificate**: Free (Let's Encrypt)
- **Total**: ~$70-135/year

## Support

- **Hostinger Support**: https://www.hostinger.com/support
- **System Docs**: `/Users/moinmakda/Desktop/TIMUN-regdesk/README.md`
- **API Docs**: `https://yourdomain.com/docs` (FastAPI auto-generated)

## Next Steps After Deployment

1. ✅ Access your site at `https://yourdomain.com`
2. ✅ Login with `admin` / `admin123`
3. ⚠️ **IMMEDIATELY change the admin password**
4. ✅ Upload delegate CSV file
5. ✅ Test check-in functionality
6. ✅ Test scanner station
7. ✅ Generate test reports
8. ✅ Monitor logs for first 24 hours

---

**Congratulations! 🎉 Your TIMUN Registration System is now live on Hostinger!**
