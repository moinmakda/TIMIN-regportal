# 🚀 Quick Start Guide - MUN 2025 Attendance System

## ⚡ 5-Minute Setup

### 1. Install Dependencies (2 minutes)
```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Email (1 minute)
Edit `backend/email_service.py`:
```python
SMTP_CONFIG = {
    "email": "YOUR_EMAIL@gmail.com",
    "password": "YOUR_APP_PASSWORD",
}
```

### 3. Initialize Database (30 seconds)
```bash
python database.py
```

### 4. Start Server (30 seconds)
```bash
python main.py
```

### 5. Access Dashboard (30 seconds)
Open browser: http://localhost:8000/admin
- Username: `admin`
- Password: `mun2025admin`

## 🎯 Test the System

### Upload Sample Delegates
1. Go to **Bulk Upload** tab
2. Upload `uploads/sample_delegates.csv`
3. Click **Process & Generate Links**
4. Emails will be sent (if SMTP configured)

### Test Check-in
1. Copy a check-in link from the database or console
2. Open in new tab: `http://localhost:8000/checkin/[TOKEN]`
3. Click "Mark My Attendance"
4. Allow location (or test with fake coordinates)

### View Statistics
1. Go to **Overview** tab
2. See real-time attendance stats
3. Check committee breakdowns

## 📱 Event Day Workflow

### Morning Setup (30 minutes before)
1. ✅ Open admin dashboard on laptop
2. ✅ Open scanner station on tablet 1
3. ✅ Open kit desk on tablets 2-5
4. ✅ Verify internet connection
5. ✅ Test one delegate check-in

### During Event
- **80% delegates** will use geolocation (auto check-in)
- **15% delegates** will scan QR at express desk
- **5% delegates** will need manual entry

### Key Pages

| Role | URL | What They Do |
|------|-----|--------------|
| Organizer | /admin | Monitor everything, generate reports |
| Express Desk | /scanner | Scan QR codes for check-in |
| Kit Desks | /kit-desk | Mark kit collection |
| Delegates | /checkin/[TOKEN] | Mark attendance via GPS |

## 🔥 Common Tasks

### Generate EB Report
```
Admin → Reports → Select Committee → Generate Report → Download
```

### Export All Data
```
Admin → Exports → Complete Delegate List → Download CSV
```

### Manual Check-in
```
Admin → Manual Check-in → Enter name → Search → Mark Attendance
```

### Mark Kit Collected
```
Kit Desk → Enter name → Search → Mark Kit Collected
```

## 🐛 Quick Fixes

### Emails Not Sending?
1. Check SMTP config in `email_service.py`
2. Use Gmail App Password (not regular password)
3. Test with one email first

### Location Not Working?
1. Only works on HTTPS (or localhost)
2. Delegate must allow location permission
3. Must be within 500m of campus

### Database Error?
```bash
rm database/mun_complete_system.db
python database.py
```

## 📊 Success Metrics

After your event, check:
- ✅ **Attendance Rate**: Should be 90%+
- ✅ **Check-in Speed**: <10 seconds per delegate
- ✅ **Kit Collection**: <30 seconds per delegate
- ✅ **Geolocation Usage**: 70-80% of check-ins

## 🎉 You're Ready!

The system is now running and ready for your MUN event.

**Key URLs:**
- Admin: http://localhost:8000/admin
- Scanner: http://localhost:8000/scanner
- Kit Desk: http://localhost:8000/kit-desk
- API Docs: http://localhost:8000/docs

For detailed documentation, see `README.md` and `build_plan.md`.

---

**Need Help?** Check the troubleshooting section in README.md
