#!/usr/bin/env python3
"""
Send check-in email to Moin and test the complete flow
"""
import sys
sys.path.insert(0, '/Users/moinmakda/Desktop/TIMUN-regdesk/backend')

from backend.database import SessionLocal, Delegate
from backend.email_service import send_email

# Get Moin's registration
db = SessionLocal()
moin = db.query(Delegate).filter(Delegate.email == 'moinmakda1@gmail.com').first()

if not moin:
    print("❌ Moin not found in database!")
    sys.exit(1)

print(f"✅ Found delegate: {moin.name}")
print(f"📧 Email: {moin.email}")
print(f"🎫 Registration: {moin.registration_number}")
print(f"🔗 Check-in Link: http://localhost:8000{moin.unique_checkin_link}")
print()

# Send email via SMTP
print("📨 Sending check-in email via SMTP...")
try:
    result = send_email(moin)
    if result:
        print("✅ Email sent successfully!")
        print(f"📬 Check your inbox: {moin.email}")
    else:
        print("❌ Failed to send email")
except Exception as e:
    print(f"❌ Error sending email: {e}")

print()
print("=" * 60)
print("🎯 YOUR CHECK-IN LINK (click to test):")
print(f"http://localhost:8000{moin.unique_checkin_link}")
print("=" * 60)
print()
print("📊 View admin dashboard at:")
print("http://localhost:8000/admin")
print("=" * 60)

db.close()
