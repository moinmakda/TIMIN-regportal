#!/bin/bash

# MUN 2025 Attendance System - Setup Script
# This script automates the setup process

echo "🎯 MUN 2025 Attendance System - Setup"
echo "========================================"
echo ""

# Check Python version
echo "📋 Checking Python version..."
python3 --version

if [ $? -ne 0 ]; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python 3 is installed"
echo ""

# Navigate to backend directory
echo "📂 Navigating to backend directory..."
cd backend

# Install dependencies
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies."
    exit 1
fi

echo "✅ Dependencies installed successfully"
echo ""

# Initialize database
echo "🗄️  Initializing database..."
python3 database.py

if [ $? -ne 0 ]; then
    echo "❌ Failed to initialize database."
    exit 1
fi

echo "✅ Database initialized"
echo ""

# Success message
echo "🎉 Setup Complete!"
echo "=================="
echo ""
echo "⚠️  IMPORTANT: Before running the server, please:"
echo "1. Edit backend/email_service.py"
echo "2. Update SMTP_CONFIG with your email credentials"
echo "3. For Gmail: Use App Password (not regular password)"
echo ""
echo "📝 Quick Start:"
echo "  cd backend"
echo "  python3 main.py"
echo ""
echo "🌐 Then open in browser:"
echo "  http://localhost:8000/admin"
echo ""
echo "🔐 Default Login:"
echo "  Username: admin"
echo "  Password: mun2025admin"
echo ""
echo "📚 For more information, see:"
echo "  - QUICKSTART.md (5-minute guide)"
echo "  - README.md (full documentation)"
echo "  - BUILD_SUMMARY.md (system overview)"
echo ""
echo "✨ Your MUN Attendance System is ready!"
