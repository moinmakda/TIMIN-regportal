"""
Production-Grade Load Testing with Locust
Test 10,000 concurrent requests
"""
from locust import HttpUser, task, between, events
import json
import random
import string
import time
from datetime import datetime


class MUNAttendanceUser(HttpUser):
    """Simulates a delegate using the MUN attendance system"""
    
    wait_time = between(1, 3)
    
    def on_start(self):
        """Initialize test user data"""
        self.registration_number = None
        self.unique_token = None
        self.qr_token = None
        self.delegate_name = f"Test_{self.generate_random_string(10)}"
        self.email = f"test_{self.generate_random_string(8)}@test.com"
        
    @staticmethod
    def generate_random_string(length):
        """Generate random string for unique IDs"""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    
    @task(1)
    def get_stats(self):
        """Test: Get overall statistics (Light operation)"""
        with self.client.get("/api/stats", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Failed to get stats: {response.status_code}")
    
    @task(2)
    def get_delegates(self):
        """Test: Get all delegates list (Medium operation)"""
        with self.client.get("/api/delegates", catch_response=True) as response:
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    response.success()
                else:
                    response.failure("API returned success=false")
            else:
                response.failure(f"Failed to get delegates: {response.status_code}")
    
    @task(3)
    def search_delegate(self):
        """Test: Search for specific delegate (Heavy DB operation)"""
        search_term = random.choice(['John', 'Jane', 'Test', 'Smith', 'Kumar'])
        with self.client.get(f"/api/delegates?search={search_term}", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Search failed: {response.status_code}")
    
    @task(5)
    def geolocation_checkin(self):
        """Test: Geolocation check-in (Most critical operation)"""
        # Simulate campus coordinates (within 500m)
        lat = 28.658500 + random.uniform(-0.004, 0.004)  # ±0.004° ≈ ±440m
        lon = 77.212700 + random.uniform(-0.004, 0.004)
        
        # Generate a fake token for testing
        fake_token = self.generate_random_string(48)
        
        payload = {
            "unique_link": fake_token,
            "latitude": lat,
            "longitude": lon
        }
        
        with self.client.post("/api/geolocation-checkin", 
                            json=payload, 
                            catch_response=True) as response:
            # We expect 404 for fake tokens, but we're testing server capacity
            if response.status_code in [200, 404]:
                response.success()
            else:
                response.failure(f"Unexpected error: {response.status_code}")
    
    @task(2)
    def qr_checkin(self):
        """Test: QR code check-in"""
        fake_qr_token = self.generate_random_string(32)
        
        payload = {
            "qr_code": fake_qr_token,
            "station_id": f"Station_{random.choice(['A', 'B', 'C', 'D'])}"
        }
        
        with self.client.post("/api/mark-attendance-qr", 
                            json=payload, 
                            catch_response=True) as response:
            if response.status_code in [200, 404]:
                response.success()
            else:
                response.failure(f"QR scan failed: {response.status_code}")
    
    @task(1)
    def get_committee_stats(self):
        """Test: Get committee-specific statistics"""
        committee = random.choice(['UNSC', 'UNGA', 'UNHRC', 'DISEC', 'ECOSOC'])
        with self.client.get(f"/api/committee-stats/{committee}", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Committee stats failed: {response.status_code}")
    
    @task(1)
    def filter_delegates_by_committee(self):
        """Test: Filter delegates by committee"""
        committee = random.choice(['UNSC', 'UNGA', 'UNHRC', 'DISEC', 'ECOSOC'])
        with self.client.get(f"/api/delegates?committee={committee}", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Filter failed: {response.status_code}")


class AdminUser(HttpUser):
    """Simulates admin operations (heavier load)"""
    
    wait_time = between(2, 5)
    
    @task(1)
    def admin_dashboard_stats(self):
        """Test: Admin dashboard loading all stats"""
        with self.client.get("/api/stats", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure("Dashboard stats failed")
    
    @task(1)
    def export_all_delegates(self):
        """Test: Export all delegates (Heavy operation)"""
        with self.client.get("/api/export/all", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure("Export failed")
    
    @task(1)
    def generate_report(self):
        """Test: Generate EB report"""
        committee = random.choice(['UNSC', 'UNGA', 'UNHRC', 'DISEC', 'ECOSOC'])
        with self.client.get(f"/api/generate-eb-report/{committee}", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure("Report generation failed")


# Event listeners for detailed reporting
@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """Called when test starts"""
    print("=" * 80)
    print("🚀 STARTING PRODUCTION-GRADE LOAD TEST")
    print("=" * 80)
    print(f"Target: {environment.host}")
    print(f"Test Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Called when test stops"""
    print("=" * 80)
    print("🏁 LOAD TEST COMPLETED")
    print("=" * 80)
    print(f"Test End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Calculate statistics
    stats = environment.stats
    print(f"\n📊 PERFORMANCE SUMMARY:")
    print(f"Total Requests: {stats.total.num_requests}")
    print(f"Total Failures: {stats.total.num_failures}")
    print(f"Success Rate: {((stats.total.num_requests - stats.total.num_failures) / stats.total.num_requests * 100):.2f}%")
    print(f"Average Response Time: {stats.total.avg_response_time:.2f}ms")
    print(f"Max Response Time: {stats.total.max_response_time:.2f}ms")
    print(f"Min Response Time: {stats.total.min_response_time:.2f}ms")
    print(f"Requests per Second: {stats.total.total_rps:.2f}")
    print("=" * 80)


# Configuration for different test scenarios
class QuickTest(MUNAttendanceUser):
    """Quick test with fewer users"""
    wait_time = between(0.5, 1)


class StressTest(MUNAttendanceUser):
    """Stress test with heavy load"""
    wait_time = between(0.1, 0.5)


if __name__ == "__main__":
    print("Use locust CLI to run this test:")
    print("locust -f tests/locustfile.py --host=http://localhost:8000")
    print("\nFor 10,000 concurrent users:")
    print("locust -f tests/locustfile.py --host=http://localhost:8000 --users=10000 --spawn-rate=100")
