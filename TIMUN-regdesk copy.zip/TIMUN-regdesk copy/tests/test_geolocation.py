"""
Unit Tests for Geolocation Module
Tests GPS calculations, distance validation, and utility functions
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from geolocation import (
    calculate_distance,
    is_on_campus,
    generate_registration_number,
    generate_checkin_link_token,
    generate_qr_token,
    assign_arrival_slot,
    validate_committee,
    validate_email
)


class TestDistanceCalculation:
    """Test haversine distance calculations"""
    
    def test_same_location(self):
        """Test distance between same coordinates is 0"""
        lat, lon = 28.658500, 77.212700
        distance = calculate_distance(lat, lon, lat, lon)
        assert distance < 1  # Should be very close to 0
        
    def test_known_distance(self):
        """Test against known distance"""
        # Delhi to Jaipur (approximately 280 km)
        delhi = (28.7041, 77.1025)
        jaipur = (26.9124, 75.7873)
        
        distance = calculate_distance(delhi[0], delhi[1], jaipur[0], jaipur[1])
        
        # Allow 10% margin of error
        assert 250000 < distance < 310000  # 250-310 km
        
    def test_short_distance(self):
        """Test short distance (few hundred meters)"""
        # Campus center
        lat1, lon1 = 28.658500, 77.212700
        # Point ~400m away
        lat2, lon2 = 28.662000, 77.212700
        
        distance = calculate_distance(lat1, lon1, lat2, lon2)
        assert 350 < distance < 450  # ~400 meters
        
    def test_negative_coordinates(self):
        """Test with negative coordinates"""
        # Test with southern hemisphere
        distance = calculate_distance(-33.8688, 151.2093, -33.8650, 151.2100)
        assert distance > 0


class TestCampusValidation:
    """Test on-campus location validation"""
    
    def test_on_campus_center(self):
        """Test point at campus center"""
        result = is_on_campus(28.658500, 77.212700)
        assert result["on_campus"] == True
        assert result["distance"] < 10
        
    def test_on_campus_edge(self):
        """Test point at edge of 500m radius"""
        # Point approximately 450m away (inside geofence)
        result = is_on_campus(28.662500, 77.212700)
        assert result["on_campus"] == True
        assert result["distance"] < 500
        
    def test_off_campus_near(self):
        """Test point just outside 500m radius"""
        # Point approximately 550m away (outside geofence)
        result = is_on_campus(28.663500, 77.212700)
        assert result["on_campus"] == False
        assert result["distance"] > 500
        
    def test_off_campus_far(self):
        """Test point far from campus"""
        # Delhi Railway Station (far from campus)
        result = is_on_campus(28.6414, 77.2209)
        assert result["on_campus"] == False
        assert result["distance"] > 500
        
    def test_result_structure(self):
        """Test result contains required fields"""
        result = is_on_campus(28.658500, 77.212700)
        assert "on_campus" in result
        assert "distance" in result
        assert isinstance(result["on_campus"], bool)
        assert isinstance(result["distance"], (int, float))


class TestTokenGeneration:
    """Test token generation functions"""
    
    def test_registration_number_format(self):
        """Test registration number follows format"""
        reg_num = generate_registration_number(1, "UNSC")
        assert reg_num.startswith("TIMUN25-")
        assert "UNSC" in reg_num
        assert len(reg_num) > 10
        
    def test_registration_number_unique(self):
        """Test registration numbers are unique"""
        reg_nums = set()
        for i in range(100):
            reg_num = generate_registration_number(i, "UNGA")
            reg_nums.add(reg_num)
        
        assert len(reg_nums) == 100  # All unique
        
    def test_unique_token_length(self):
        """Test unique token has correct length"""
        token = generate_unique_token()
        assert len(token) == 48
        
    def test_unique_token_characters(self):
        """Test unique token contains only alphanumeric"""
        token = generate_unique_token()
        assert token.isalnum()
        
    def test_unique_tokens_are_unique(self):
        """Test multiple tokens are different"""
        tokens = set()
        for _ in range(1000):
            tokens.add(generate_unique_token())
        
        assert len(tokens) == 1000  # All unique
        
    def test_qr_token_length(self):
        """Test QR token has correct length"""
        qr_token = generate_qr_token()
        assert len(qr_token) == 32
        
    def test_qr_token_characters(self):
        """Test QR token contains only alphanumeric"""
        qr_token = generate_qr_token()
        assert qr_token.isalnum()
        
    def test_qr_tokens_are_unique(self):
        """Test multiple QR tokens are different"""
        tokens = set()
        for _ in range(1000):
            tokens.add(generate_qr_token())
        
        assert len(tokens) == 1000  # All unique


class TestArrivalSlotAssignment:
    """Test arrival slot assignment logic"""
    
    def test_slot_distribution(self):
        """Test slots are distributed evenly"""
        slots = {}
        
        for i in range(200):
            slot = assign_arrival_slot(i, 200)
            slots[slot] = slots.get(slot, 0) + 1
        
        # Should have 4 slots
        assert len(slots) == 4
        
        # Each slot should have ~50 delegates (±10)
        for count in slots.values():
            assert 40 <= count <= 60
            
    def test_slot_names(self):
        """Test slot names are correct"""
        valid_slots = ["Slot 1: 8:00 AM - 9:00 AM", 
                      "Slot 2: 9:00 AM - 10:00 AM",
                      "Slot 3: 10:00 AM - 11:00 AM", 
                      "Slot 4: 11:00 AM - 12:00 PM"]
        
        for i in range(200):
            slot = assign_arrival_slot(i, 200)
            assert slot in valid_slots
            
    def test_small_batch(self):
        """Test with small number of delegates"""
        slot = assign_arrival_slot(1, 10)
        assert "Slot" in slot
        assert "AM" in slot
        
    def test_large_batch(self):
        """Test with large number of delegates"""
        slot = assign_arrival_slot(500, 1000)
        assert "Slot" in slot


class TestTokenValidation:
    """Test token validation"""
    
    def test_validate_valid_token(self):
        """Test validation of properly formatted token"""
        token = generate_unique_token()
        assert validate_token(token) == True
        
    def test_validate_short_token(self):
        """Test rejection of short token"""
        assert validate_token("short") == False
        
    def test_validate_empty_token(self):
        """Test rejection of empty token"""
        assert validate_token("") == False
        
    def test_validate_none_token(self):
        """Test rejection of None token"""
        assert validate_token(None) == False
        
    def test_validate_special_characters(self):
        """Test rejection of tokens with special characters"""
        assert validate_token("abc123!@#$%^&*()def456ghi789") == False
        
    def test_validate_spaces(self):
        """Test rejection of tokens with spaces"""
        token = generate_unique_token()
        token_with_space = token[:20] + " " + token[20:]
        assert validate_token(token_with_space) == False


class TestEdgeCases:
    """Test edge cases and error handling"""
    
    def test_distance_with_zeros(self):
        """Test distance calculation with zero coordinates"""
        distance = calculate_distance(0, 0, 0, 0)
        assert distance == 0
        
    def test_distance_with_extreme_coordinates(self):
        """Test with coordinates at extremes"""
        # North pole to south pole
        distance = calculate_distance(90, 0, -90, 0)
        assert distance > 0
        
    def test_campus_validation_with_invalid_coords(self):
        """Test campus validation with invalid coordinates"""
        result = is_on_campus(None, None)
        assert result["on_campus"] == False
        
    def test_registration_number_with_special_committee(self):
        """Test registration with committee having spaces"""
        reg_num = generate_registration_number(1, "UN SC")
        assert reg_num is not None
        assert "TIMUN25" in reg_num


class TestPerformance:
    """Test performance of critical functions"""
    
    def test_distance_calculation_speed(self):
        """Test distance calculation is fast"""
        import time
        
        start = time.time()
        for _ in range(10000):
            calculate_distance(28.658500, 77.212700, 28.662500, 77.212700)
        end = time.time()
        
        # Should complete 10,000 calculations in under 1 second
        assert (end - start) < 1.0
        
    def test_token_generation_speed(self):
        """Test token generation is fast"""
        import time
        
        start = time.time()
        for _ in range(10000):
            generate_unique_token()
        end = time.time()
        
        # Should generate 10,000 tokens in under 1 second
        assert (end - start) < 1.0
        
    def test_campus_validation_speed(self):
        """Test campus validation is fast"""
        import time
        
        start = time.time()
        for _ in range(10000):
            is_on_campus(28.658500, 77.212700)
        end = time.time()
        
        # Should complete 10,000 validations in under 2 seconds
        assert (end - start) < 2.0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
