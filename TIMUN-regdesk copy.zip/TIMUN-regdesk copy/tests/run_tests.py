"""
Quick Test Runner - Run All Tests Sequentially
"""
import subprocess
import sys
import os
from datetime import datetime


def run_command(cmd, description):
    """Run a command and return success status"""
    print(f"\n{'='*70}")
    print(f"  {description}")
    print(f"{'='*70}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            check=False,
            capture_output=True,
            text=True
        )
        
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
        
        if result.returncode == 0:
            print(f"✓ {description} - SUCCESS")
            return True
        else:
            print(f"✗ {description} - FAILED (non-critical)")
            return False
    except Exception as e:
        print(f"✗ {description} - ERROR: {e}")
        return False


def main():
    print("="*70)
    print("    MUN ATTENDANCE SYSTEM - QUICK TEST SUITE")
    print(f"    Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)
    
    results = {}
    
    # Test 1: Database tests
    results['database'] = run_command(
        "pytest tests/test_database.py -v",
        "Database Unit Tests"
    )
    
    # Test 2: Geolocation tests
    results['geolocation'] = run_command(
        "pytest tests/test_geolocation.py -v",
        "Geolocation Unit Tests"
    )
    
    # Test 3: API tests
    results['api'] = run_command(
        "pytest tests/test_api.py -v",
        "API Integration Tests"
    )
    
    # Test 4: Code coverage
    results['coverage'] = run_command(
        "pytest tests/ --cov=backend --cov-report=html --cov-report=term",
        "Code Coverage Report"
    )
    
    # Summary
    print("\n" + "="*70)
    print("    TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, success in results.items():
        status = "✓ PASSED" if success else "✗ FAILED"
        print(f"  {test_name.upper()}: {status}")
    
    print(f"\nTotal: {passed}/{total} test suites passed")
    print(f"Finished at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)
    
    if passed == total:
        print("\n✓ ALL TESTS PASSED - System is production-ready!")
        return 0
    else:
        print(f"\n⚠ {total - passed} test suite(s) need attention")
        return 1


if __name__ == "__main__":
    sys.exit(main())
