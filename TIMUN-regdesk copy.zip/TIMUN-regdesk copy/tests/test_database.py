"""
Unit Tests for Database Module
Tests all SQLAlchemy models and database operations
"""
import pytest
import sys
import os
from datetime import datetime

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from database import Delegate, Admin, engine, SessionLocal, init_database
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


@pytest.fixture(scope="function")
def test_db():
    """Create a test database"""
    # Use in-memory SQLite for testing
    test_engine = create_engine("sqlite:///:memory:")
    
    # Create all tables
    from database import Base
    Base.metadata.create_all(test_engine)
    
    TestSessionLocal = sessionmaker(bind=test_engine)
    db = TestSessionLocal()
    
    yield db
    
    db.close()


@pytest.fixture
def sample_delegate():
    """Create sample delegate data"""
    return {
        "full_name": "Test Delegate",
        "email": "test@example.com",
        "phone": "+919876543210",
        "committee": "UNSC",
        "country": "India",
        "registration_number": "REG001",
        "unique_token": "test_token_123456",
        "qr_token": "qr_test_123456"
    }


class TestDelegateModel:
    """Test Delegate model operations"""
    
    def test_create_delegate(self, test_db, sample_delegate):
        """Test creating a new delegate"""
        delegate = Delegate(**sample_delegate)
        test_db.add(delegate)
        test_db.commit()
        test_db.refresh(delegate)
        
        assert delegate.id is not None
        assert delegate.full_name == "Test Delegate"
        assert delegate.email == "test@example.com"
        assert delegate.payment_status == False  # Default
        assert delegate.attendance_marked == False  # Default
        
    def test_delegate_attendance_marking(self, test_db, sample_delegate):
        """Test marking attendance"""
        delegate = Delegate(**sample_delegate)
        test_db.add(delegate)
        test_db.commit()
        
        # Mark attendance
        delegate.attendance_marked = True
        delegate.checked_in_at = datetime.now()
        delegate.checkin_method = "geolocation"
        test_db.commit()
        
        assert delegate.attendance_marked == True
        assert delegate.checked_in_at is not None
        assert delegate.checkin_method == "geolocation"
        
    def test_delegate_kit_collection(self, test_db, sample_delegate):
        """Test kit collection tracking"""
        delegate = Delegate(**sample_delegate)
        test_db.add(delegate)
        test_db.commit()
        
        # Mark kit collected
        delegate.kit_collected = True
        delegate.kit_collected_at = datetime.now()
        test_db.commit()
        
        assert delegate.kit_collected == True
        assert delegate.kit_collected_at is not None
        
    def test_delegate_geolocation(self, test_db, sample_delegate):
        """Test geolocation data storage"""
        delegate = Delegate(**sample_delegate)
        delegate.checkin_latitude = 28.658500
        delegate.checkin_longitude = 77.212700
        delegate.distance_from_campus = 50.5
        
        test_db.add(delegate)
        test_db.commit()
        test_db.refresh(delegate)
        
        assert delegate.checkin_latitude == 28.658500
        assert delegate.checkin_longitude == 77.212700
        assert delegate.distance_from_campus == 50.5
        
    def test_unique_constraints(self, test_db, sample_delegate):
        """Test unique constraints on email and registration number"""
        # Create first delegate
        delegate1 = Delegate(**sample_delegate)
        test_db.add(delegate1)
        test_db.commit()
        
        # Try to create duplicate email (should fail)
        delegate2 = Delegate(
            **{**sample_delegate, "registration_number": "REG002"}
        )
        test_db.add(delegate2)
        
        with pytest.raises(Exception):  # Should raise IntegrityError
            test_db.commit()
        
        test_db.rollback()


class TestAdminModel:
    """Test Admin model operations"""
    
    def test_create_admin(self, test_db):
        """Test creating admin user"""
        admin = Admin(
            username="testadmin",
            password_hash="hashed_password",
            role="organizer"
        )
        test_db.add(admin)
        test_db.commit()
        test_db.refresh(admin)
        
        assert admin.id is not None
        assert admin.username == "testadmin"
        assert admin.role == "organizer"
        
    def test_admin_roles(self, test_db):
        """Test different admin roles"""
        roles = ["super_admin", "organizer", "volunteer"]
        
        for role in roles:
            admin = Admin(
                username=f"admin_{role}",
                password_hash="hash",
                role=role
            )
            test_db.add(admin)
        
        test_db.commit()
        
        # Verify all roles created
        admins = test_db.query(Admin).filter(Admin.username.like("admin_%")).all()
        assert len(admins) == 3
        
    def test_admin_unique_username(self, test_db):
        """Test unique username constraint"""
        admin1 = Admin(
            username="duplicate_test",
            password_hash="hash1",
            role="volunteer"
        )
        test_db.add(admin1)
        test_db.commit()
        
        admin2 = Admin(
            username="duplicate_test",
            password_hash="hash2",
            role="volunteer"
        )
        test_db.add(admin2)
        
        with pytest.raises(Exception):  # Should raise IntegrityError
            test_db.commit()
        
        test_db.rollback()


class TestDatabaseQueries:
    """Test common database queries"""
    
    def test_filter_by_committee(self, test_db):
        """Test filtering delegates by committee"""
        committees = ["UNSC", "UNGA", "UNHRC"]
        
        for committee in committees:
            for i in range(3):
                delegate = Delegate(
                    full_name=f"{committee} Delegate {i}",
                    email=f"{committee.lower()}{i}@test.com",
                    committee=committee,
                    registration_number=f"{committee}_{i}",
                    unique_token=f"token_{committee}_{i}",
                    qr_token=f"qr_{committee}_{i}"
                )
                test_db.add(delegate)
        
        test_db.commit()
        
        # Query UNSC delegates
        unsc_delegates = test_db.query(Delegate).filter(Delegate.committee == "UNSC").all()
        assert len(unsc_delegates) == 3
        
    def test_count_attended_delegates(self, test_db):
        """Test counting attended vs not attended"""
        # Create 10 delegates, mark 6 as attended
        for i in range(10):
            delegate = Delegate(
                full_name=f"Delegate {i}",
                email=f"delegate{i}@test.com",
                committee="UNGA",
                registration_number=f"COUNT_{i}",
                unique_token=f"token_count_{i}",
                qr_token=f"qr_count_{i}",
                attendance_marked=(i < 6)
            )
            test_db.add(delegate)
        
        test_db.commit()
        
        total = test_db.query(Delegate).filter(Delegate.registration_number.like("COUNT_%")).count()
        attended = test_db.query(Delegate).filter(
            Delegate.registration_number.like("COUNT_%"),
            Delegate.attendance_marked == True
        ).count()
        
        assert total == 10
        assert attended == 6
        
    def test_search_delegates(self, test_db):
        """Test searching delegates by name or email"""
        delegate = Delegate(
            full_name="John Smith",
            email="john.smith@example.com",
            committee="DISEC",
            registration_number="SEARCH_TEST",
            unique_token="search_token",
            qr_token="search_qr"
        )
        test_db.add(delegate)
        test_db.commit()
        
        # Search by name
        results = test_db.query(Delegate).filter(
            Delegate.full_name.ilike("%john%")
        ).all()
        assert len(results) >= 1
        
        # Search by email
        results = test_db.query(Delegate).filter(
            Delegate.email.ilike("%smith%")
        ).all()
        assert len(results) >= 1


class TestDatabaseInitialization:
    """Test database initialization"""
    
    def test_init_database(self, tmp_path):
        """Test init_database function creates tables correctly"""
        # Create temporary database file
        db_path = tmp_path / "test.db"
        test_url = f"sqlite:///{db_path}"
        
        # Override database URL and force engine recreation
        import database
        original_url = database.DATABASE_URL
        original_engine = database.engine
        database.DATABASE_URL = test_url
        database.engine = None  # Force recreation with new URL
        
        # Initialize database
        init_database()
        
        # Check if tables were created by trying to query them
        from database import SessionLocal
        db = SessionLocal()
        
        # Should be able to query delegates (empty at first)
        delegates = db.query(Delegate).all()
        assert delegates == []
        
        # Should be able to query admins (empty - not auto-created anymore)
        admins = db.query(Admin).all()
        assert admins == []
        
        db.close()
        
        # Restore original URL and engine
        database.DATABASE_URL = original_url
        database.engine = original_engine


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
