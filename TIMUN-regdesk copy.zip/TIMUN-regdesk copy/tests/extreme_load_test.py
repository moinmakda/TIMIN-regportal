"""
EXTREME LOAD TEST - Progressive Scaling
Tests system capacity by progressively increasing load
"""
import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

BASE_URL = 'http://127.0.0.1:8000'

def test_request():
    """Single test request"""
    try:
        r = requests.get(f'{BASE_URL}/api/stats', timeout=10)
        return r.status_code == 200
    except:
        return False

print('='*80)
print('    🚀 EXTREME PRODUCTION STRESS TEST')
print('    Progressive Load Testing - Scaling to Maximum Capacity')
print('='*80)
print()

# Test stages: (num_requests, max_workers, label)
stages = [
    (1000, 50, '1K requests'),
    (5000, 100, '5K requests'),
    (10000, 200, '10K requests'),
    (50000, 500, '50K requests'),
    (100000, 1000, '100K requests'),
    (500000, 2000, '500K requests'),
    (1000000, 3000, '1M requests'),
]

total_success = 0
total_failed = 0
total_time = 0

for num_requests, max_workers, label in stages:
    print(f'[STAGE] Testing {label} with {max_workers} concurrent workers...')
    
    success = 0
    failed = 0
    start = time.time()
    
    try:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(test_request) for _ in range(num_requests)]
            
            completed = 0
            for future in as_completed(futures):
                if future.result():
                    success += 1
                else:
                    failed += 1
                
                completed += 1
                # Show progress every 5%
                if completed % max(1, num_requests // 20) == 0:
                    progress = completed / num_requests * 100
                    print(f'  Progress: {completed:,}/{num_requests:,} ({progress:.1f}%) | Success: {success:,} | Failed: {failed}', end='\r')
        
        end = time.time()
        duration = end - start
        rps = num_requests / duration
        
        total_success += success
        total_failed += failed
        total_time += duration
        
        print()  # New line after progress
        print(f'  ✅ Completed in {duration:.2f}s')
        print(f'     • RPS: {rps:,.2f}')
        print(f'     • Success: {success:,}')
        print(f'     • Failed: {failed}')
        print(f'     • Success Rate: {success/num_requests*100:.4f}%')
        
        # Stop if failure rate is too high
        if failed > num_requests * 0.01:  # More than 1% failure
            print(f'  ⚠️  High failure rate detected ({failed/num_requests*100:.2f}%). Stopping progression.')
            break
        
        # Stop if RPS is declining significantly
        if total_time > 0:
            avg_rps = (total_success + total_failed) / total_time
            if rps < avg_rps * 0.5:  # If current RPS is less than 50% of average
                print(f'  ⚠️  Performance degradation detected. System at capacity.')
                break
            
    except KeyboardInterrupt:
        print(f'\n  ⚠️  Test interrupted by user')
        break
    except Exception as e:
        print(f'  ❌ Error: {e}')
        break
    
    print()

print()
print('='*80)
print('    📊 FINAL RESULTS')
print('='*80)
print(f'Total Requests Sent:     {total_success + total_failed:,}')
print(f'Total Successful:        {total_success:,}')
print(f'Total Failed:            {total_failed:,}')
print(f'Overall Success Rate:    {total_success/(total_success+total_failed)*100:.6f}%')
print(f'Total Test Duration:     {total_time:.2f}s')
print(f'Average Throughput:      {(total_success+total_failed)/total_time:,.2f} RPS')
print('='*80)

if total_failed == 0:
    print('🎉 PERFECT! System handled ALL requests without ANY failures!')
    print(f'✨ Tested capacity: {total_success:,} requests at 100% success rate')
elif total_success/(total_success+total_failed) >= 0.9999:
    print(f'🏆 EXCELLENT! System achieved 99.99%+ success rate!')
    print(f'✨ Production-ready for {total_success:,}+ concurrent users')
else:
    failure_rate = total_failed/(total_success+total_failed)*100
    print(f'⚠️  System failure rate: {failure_rate:.6f}%')
    print(f'✨ Max stable capacity: ~{total_success:,} requests')

print('='*80)

# Calculate projected capacity for 1 billion requests
if total_failed == 0 and total_time > 0:
    current_rps = (total_success + total_failed) / total_time
    time_for_1b = 1_000_000_000 / current_rps
    hours = time_for_1b / 3600
    print()
    print(f'📈 PROJECTION FOR 1 BILLION REQUESTS:')
    print(f'   At current RPS ({current_rps:,.2f}), would take: {hours:.2f} hours')
    print(f'   Estimated completion: ~{time_for_1b/3600/24:.2f} days')
    print('='*80)
