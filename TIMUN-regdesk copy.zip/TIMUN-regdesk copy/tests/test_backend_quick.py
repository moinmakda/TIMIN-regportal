"""
Integration Test - Backend Server Quick Test
Tests that the backend API starts and responds correctly
"""
import subprocess
import time
import requests
import sys
from pathlib import Path

TOTAL_STEPS = 7
PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _print_step(step: int, message: str) -> None:
    print(f"[{step}/{TOTAL_STEPS}] {message}")


def _fail(message: str) -> None:
    raise AssertionError(message)


def run_backend_quick_test() -> bool:
    print("=" * 70)
    print("    BACKEND SERVER QUICK TEST")
    print("=" * 70)

    print()
    _print_step(1, "Ensuring default admin user exists...")
    create_admin_process = subprocess.run(
        [sys.executable, "create_admin.py"],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
    )

    if create_admin_process.returncode != 0:
        if create_admin_process.stdout:
            print(create_admin_process.stdout)
        if create_admin_process.stderr:
            print(create_admin_process.stderr)
        _fail("Failed to ensure admin user")

    print("    ✓ Admin user ready")
    admin_output = create_admin_process.stdout.strip()
    if admin_output:
        for line in admin_output.splitlines():
            print(f"    {line}")

    print()
    _print_step(2, "Starting backend server...")
    server_process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "backend.main:app",
            "--host",
            "127.0.0.1",
            "--port",
            "8000",
        ],
        cwd=str(PROJECT_ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    try:
        _print_step(3, "Waiting for server to initialize...")
        time.sleep(5)

        if server_process.poll() is not None:
            stdout, stderr = server_process.communicate(timeout=1)
            print("\n✗ ERROR: Backend server failed to start")
            if stdout:
                print(stdout.decode())
            if stderr:
                print(stderr.decode())
            _fail("Backend server terminated unexpectedly")

        _print_step(4, "Testing health endpoint...")
        response = requests.get("http://127.0.0.1:8000/health", timeout=5)
        if response.status_code != 200:
            _fail(f"Health check failed ({response.status_code})")
        print("    ✓ Health check PASSED")

        _print_step(5, "Authenticating admin user...")
        auth_response = requests.post(
            "http://127.0.0.1:8000/api/auth/login",
            json={"username": "admin", "password": "admin123"},
            timeout=5,
        )

        if auth_response.status_code != 200:
            print(f"    Status: {auth_response.status_code}")
            print(f"    Response: {auth_response.text}")
            _fail("Admin authentication failed")

        token = auth_response.json().get("access_token")
        if not token:
            _fail("Authentication response missing access token")

        headers = {"Authorization": f"Bearer {token}"}
        print("    ✓ Admin authentication PASSED")

        _print_step(6, "Testing stats endpoint...")
        response = requests.get("http://127.0.0.1:8000/api/stats", headers=headers, timeout=5)
        if response.status_code != 200:
            _fail(f"Stats endpoint failed ({response.status_code})")
        data = response.json()
        print("    ✓ Stats endpoint PASSED")
        print(f"      Total Registered: {data.get('total_registered', 0)}")

        _print_step(7, "Testing delegates endpoint...")
        response = requests.get("http://127.0.0.1:8000/api/delegates", headers=headers, timeout=5)
        if response.status_code != 200:
            _fail(f"Delegates endpoint failed ({response.status_code})")
        data = response.json()
        print("    ✓ Delegates endpoint PASSED")
        print(f"      Success: {data.get('success')}")

        print("\n" + "=" * 70)
        print("    ✓ ALL BACKEND TESTS PASSED")
        print("=" * 70)
        return True
    finally:
        print("\nStopping backend server...")
        server_process.terminate()
        try:
            server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server_process.kill()
        print("✓ Server stopped")


def test_backend_quick() -> None:
    assert run_backend_quick_test()


if __name__ == "__main__":
    try:
        run_backend_quick_test()
    except AssertionError as exc:
        print(f"\n✗ ERROR: {exc}")
        sys.exit(1)
