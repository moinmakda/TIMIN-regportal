"""
Integration Tests for FastAPI Endpoints
Tests all API routes and request/response handling
"""
import pytest
import sys
import os
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from main import app
from database import Delegate, Admin, SessionLocal, engine, Base
import json


@pytest.fixture(scope="module")
def test_client():
    """Create test client"""
    # Create test database tables
    Base.metadata.create_all(bind=engine)
    
    client = TestClient(app)
    yield client
    
    # Cleanup
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def db_session():
    """Create database session for tests"""
    db = SessionLocal()
    yield db
    db.close()


@pytest.fixture
def sample_delegate_data():
    """Sample delegate data for testing"""
    return {
        "full_name": "Test Delegate API",
        "email": "api_test@example.com",
        "phone": "+919876543210",
        "committee": "UNSC",
        "country": "India",
        "registration_number": "API_TEST_001",
        "unique_token": "api_test_token_123456789012345678901234567890123456",
        "qr_token": "api_test_qr_12345678901234567890"
    }


class TestHealthAndInfo:
    """Test basic health and info endpoints"""
    
    def test_root_endpoint(self, test_client):
        """Test root endpoint returns welcome message"""
        response = test_client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        
    def test_health_endpoint(self, test_client):
        """Test health check endpoint"""
        response = test_client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"


class TestStatisticsEndpoints:
    """Test statistics and analytics endpoints"""
    
    def test_get_overall_stats(self, test_client):
        """Test getting overall statistics"""
        response = test_client.get("/api/stats")
        assert response.status_code == 200
        data = response.json()
        
        assert "total_registered" in data
        assert "total_checked_in" in data
        assert "pending_checkin" in data
        assert "kit_collected" in data
        
    def test_get_committee_stats(self, test_client):
        """Test getting committee-specific statistics"""
        response = test_client.get("/api/committee-stats/UNSC")
        assert response.status_code == 200
        data = response.json()
        
        assert "committee" in data
        assert data["committee"] == "UNSC"


class TestDelegateEndpoints:
    """Test delegate management endpoints"""
    
    def test_get_all_delegates(self, test_client):
        """Test retrieving all delegates"""
        response = test_client.get("/api/delegates")
        assert response.status_code == 200
        data = response.json()
        
        assert "success" in data
        assert "delegates" in data
        assert isinstance(data["delegates"], list)
        
    def test_search_delegates(self, test_client, db_session, sample_delegate_data):
        """Test searching delegates"""
        # Add a test delegate
        delegate = Delegate(**sample_delegate_data)
        db_session.add(delegate)
        db_session.commit()
        
        # Search for delegate
        response = test_client.get("/api/delegates?search=API")
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] == True
        # Should find the delegate we added
        
    def test_filter_by_committee(self, test_client):
        """Test filtering delegates by committee"""
        response = test_client.get("/api/delegates?committee=UNSC")
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] == True
        
    def test_filter_by_attendance(self, test_client):
        """Test filtering by attendance status"""
        response = test_client.get("/api/delegates?attendance=checked_in")
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] == True


class TestGeolocationCheckin:
    """Test geolocation-based check-in"""
    
    def test_geolocation_checkin_on_campus(self, test_client, db_session, sample_delegate_data):
        """Test successful geolocation check-in"""
        # Add delegate to database
        delegate = Delegate(**sample_delegate_data)
        delegate.payment_status = True  # Payment confirmed
        db_session.add(delegate)
        db_session.commit()
        
        # Attempt check-in with on-campus coordinates
        payload = {
            "unique_link": sample_delegate_data["unique_token"],
            "latitude": 28.658500,
            "longitude": 77.212700
        }
        
        response = test_client.post("/api/geolocation-checkin", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] == True
        
    def test_geolocation_checkin_off_campus(self, test_client, db_session):
        """Test geolocation check-in off campus"""
        # Create delegate
        delegate = Delegate(
            full_name="Off Campus Test",
            email="offcampus@test.com",
            committee="UNGA",
            registration_number="OFF_001",
            unique_token="off_campus_token_123456789012345678901234567890",
            qr_token="off_qr_123456789012345678901234",
            payment_status=True
        )
        db_session.add(delegate)
        db_session.commit()
        
        # Try check-in from far location
        payload = {
            "unique_link": "off_campus_token_123456789012345678901234567890",
            "latitude": 28.7041,  # Delhi Railway Station
            "longitude": 77.1025
        }
        
        response = test_client.post("/api/geolocation-checkin", json=payload)
        assert response.status_code == 400  # Should fail
        data = response.json()
        
        assert data["success"] == False
        assert "not on campus" in data.get("message", "").lower()
        
    def test_geolocation_checkin_invalid_token(self, test_client):
        """Test check-in with invalid token"""
        payload = {
            "unique_link": "invalid_token_that_does_not_exist",
            "latitude": 28.658500,
            "longitude": 77.212700
        }
        
        response = test_client.post("/api/geolocation-checkin", json=payload)
        assert response.status_code == 404


class TestQRCheckin:
    """Test QR code based check-in"""
    
    def test_qr_checkin_success(self, test_client, db_session):
        """Test successful QR check-in"""
        # Create delegate
        delegate = Delegate(
            full_name="QR Test",
            email="qr@test.com",
            committee="UNHRC",
            registration_number="QR_001",
            unique_token="qr_unique_token_123456789012345678901234567890",
            qr_token="qr_test_token_12345678901234",
            payment_status=True
        )
        db_session.add(delegate)
        db_session.commit()
        
        # Create QR data
        qr_data = {
            "registration_number": "QR_001",
            "token": "qr_test_token_12345678901234",
            "full_name": "QR Test"
        }
        
        payload = {
            "qr_code": json.dumps(qr_data),
            "station_id": "Station_A"
        }
        
        response = test_client.post("/api/mark-attendance-qr", json=payload)
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] == True
        
    def test_qr_checkin_invalid_json(self, test_client):
        """Test QR check-in with invalid JSON"""
        payload = {
            "qr_code": "invalid json string",
            "station_id": "Station_A"
        }
        
        response = test_client.post("/api/mark-attendance-qr", json=payload)
        assert response.status_code == 400


class TestManualCheckin:
    """Test manual check-in by admin"""
    
    def test_manual_checkin_by_registration(self, test_client, db_session):
        """Test manual check-in using registration number"""
        # Create delegate
        delegate = Delegate(
            full_name="Manual Test",
            email="manual@test.com",
            committee="DISEC",
            registration_number="MANUAL_001",
            unique_token="manual_unique_token_1234567890123456789012345678",
            qr_token="manual_qr_token_12345678901",
            payment_status=True
        )
        db_session.add(delegate)
        db_session.commit()
        
        payload = {
            "registration_number": "MANUAL_001",
            "admin_id": "admin_test"
        }
        
        response = test_client.post("/api/manual-checkin", json=payload)
        # May fail if delegate doesn't exist or already checked in
        # Just verify response structure
        assert response.status_code in [200, 404, 400]


class TestKitCollection:
    """Test kit collection tracking"""
    
    def test_mark_kit_collected(self, test_client, db_session):
        """Test marking kit as collected"""
        # Create delegate with attendance marked
        delegate = Delegate(
            full_name="Kit Test",
            email="kit@test.com",
            committee="ECOSOC",
            registration_number="KIT_001",
            unique_token="kit_unique_token_123456789012345678901234567890",
            qr_token="kit_qr_token_1234567890123456",
            payment_status=True,
            attendance_marked=True
        )
        db_session.add(delegate)
        db_session.commit()
        
        payload = {
            "registration_number": "KIT_001"
        }
        
        response = test_client.post("/api/kit-collect", json=payload)
        assert response.status_code in [200, 404, 400]
        
    def test_get_kit_stats(self, test_client):
        """Test getting kit collection statistics"""
        response = test_client.get("/api/kit-stats")
        assert response.status_code == 200
        data = response.json()
        
        assert "total_eligible" in data
        assert "total_collected" in data


class TestBulkUpload:
    """Test bulk delegate upload via CSV"""
    
    def test_bulk_upload_valid_csv(self, test_client):
        """Test uploading valid CSV"""
        csv_content = """full_name,email,phone,committee,country
John Doe,john@test.com,+919876543210,UNSC,USA
Jane Smith,jane@test.com,+919876543211,UNGA,UK"""
        
        files = {
            "file": ("delegates.csv", csv_content, "text/csv")
        }
        
        response = test_client.post("/api/admin/bulk-upload", files=files)
        # Should succeed or fail with validation message
        assert response.status_code in [200, 400]
        
    def test_bulk_upload_invalid_csv(self, test_client):
        """Test uploading invalid CSV"""
        csv_content = "invalid,csv,format"
        
        files = {
            "file": ("bad.csv", csv_content, "text/csv")
        }
        
        response = test_client.post("/api/admin/bulk-upload", files=files)
        assert response.status_code == 400


class TestExportEndpoints:
    """Test data export endpoints"""
    
    def test_export_all_delegates(self, test_client):
        """Test exporting all delegates"""
        response = test_client.get("/api/export/all")
        assert response.status_code == 200
        # Should return CSV content
        
    def test_export_checked_in(self, test_client):
        """Test exporting checked-in delegates"""
        response = test_client.get("/api/export/checked-in")
        assert response.status_code == 200
        
    def test_export_pending(self, test_client):
        """Test exporting pending delegates"""
        response = test_client.get("/api/export/pending")
        assert response.status_code == 200


class TestReportGeneration:
    """Test report generation"""
    
    def test_generate_eb_report(self, test_client):
        """Test generating EB report"""
        response = test_client.get("/api/generate-eb-report/UNSC")
        assert response.status_code == 200
        # Should return text report


class TestErrorHandling:
    """Test error handling and edge cases"""
    
    def test_404_on_invalid_endpoint(self, test_client):
        """Test 404 on non-existent endpoint"""
        response = test_client.get("/api/nonexistent")
        assert response.status_code == 404
        
    def test_invalid_http_method(self, test_client):
        """Test invalid HTTP method"""
        response = test_client.put("/api/stats")  # Stats only supports GET
        assert response.status_code == 405  # Method not allowed


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
