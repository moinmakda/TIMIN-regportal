"""
Generate comprehensive sample data for MUN Attendance System
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from faker import Faker
import random
import csv

fake = Faker()

# Committee distribution
COMMITTEES = {
    'UNSC': 35,
    'UNGA': 50,
    'UNHRC': 30,
    'DISEC': 45,
    'ECOSOC': 40
}

# Sample countries per committee
COMMITTEE_COUNTRIES = {
    'UNSC': ['USA', 'UK', 'France', 'Russia', 'China', 'India', 'Brazil', 'South Africa', 
             'Germany', 'Japan', 'Italy', 'Spain', 'Canada', 'Australia', 'Mexico', 
             'Egypt', 'Turkey', 'Indonesia', 'Saudi Arabia', 'Netherlands'],
    'UNGA': ['Afghanistan', 'Albania', 'Algeria', 'Argentina', 'Austria', 'Bangladesh', 
             'Belgium', 'Chile', 'Colombia', 'Czech Republic', 'Denmark', 'Finland', 
             'Ghana', 'Greece', 'Hungary', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Kenya',
             'Malaysia', 'Morocco', 'Nigeria', 'Norway', 'Pakistan', 'Peru', 'Philippines',
             'Poland', 'Portugal', 'Qatar', 'Romania', 'Singapore', 'Sweden', 'Switzerland',
             'Thailand', 'UAE', 'Ukraine', 'Venezuela', 'Vietnam', 'Zimbabwe'],
    'UNHRC': ['USA', 'Germany', 'Japan', 'France', 'UK', 'India', 'Brazil', 'South Korea',
              'Canada', 'Mexico', 'Indonesia', 'Turkey', 'Saudi Arabia', 'Argentina',
              'Poland', 'Thailand', 'Egypt', 'South Africa', 'Colombia', 'Malaysia'],
    'DISEC': ['USA', 'Russia', 'China', 'UK', 'France', 'India', 'Pakistan', 'Israel',
              'Iran', 'North Korea', 'South Korea', 'Japan', 'Germany', 'Brazil', 'Turkey',
              'Saudi Arabia', 'Egypt', 'Indonesia', 'Nigeria', 'Australia', 'Canada',
              'Italy', 'Spain', 'Poland', 'Ukraine', 'Sweden', 'Norway', 'Finland',
              'Denmark', 'Netherlands', 'Belgium', 'Switzerland', 'Austria', 'Greece'],
    'ECOSOC': ['USA', 'China', 'Germany', 'Japan', 'UK', 'France', 'India', 'Brazil',
               'Canada', 'South Korea', 'Australia', 'Spain', 'Mexico', 'Indonesia',
               'Netherlands', 'Saudi Arabia', 'Turkey', 'Switzerland', 'Poland', 'Belgium',
               'Sweden', 'Norway', 'Austria', 'Ireland', 'Denmark', 'Finland', 'Singapore',
               'Malaysia', 'Thailand', 'Philippines', 'Vietnam', 'Egypt', 'South Africa',
               'Argentina', 'Chile', 'Colombia', 'Peru']
}

SCHOOLS = [
    'Delhi Public School',
    'St. Xavier\'s School',
    'Modern School',
    'The Doon School',
    'Mayo College',
    'Bishop Cotton School',
    'Woodstock School',
    'La Martiniere College',
    'Lawrence School',
    'Welham Boys School',
    'Welham Girls School',
    'The Scindia School',
    'Rishi Valley School',
    'Cathedral School',
    'Mount Abu Public School',
    'Rashtriya Indian Military College',
    'Army Public School',
    'Kendriya Vidyalaya',
    'DAV Public School',
    'Ryan International School'
]

def generate_delegate_data():
    """Generate realistic delegate data"""
    delegates = []
    
    for committee, count in COMMITTEES.items():
        countries = COMMITTEE_COUNTRIES[committee]
        
        for i in range(count):
            # Generate unique name with Indian names for variety
            if random.random() < 0.6:  # 60% Indian names
                if random.random() < 0.5:
                    first_name = random.choice(['Aarav', 'Arjun', 'Advait', 'Aditya', 'Ansh', 
                                                'Dhruv', 'Krishna', 'Kabir', 'Rohan', 'Shaurya',
                                                'Vihaan', 'Ayaan', 'Reyansh', 'Atharva', 'Pranav'])
                    last_name = random.choice(['Sharma', 'Gupta', 'Kumar', 'Singh', 'Verma', 
                                             'Patel', 'Reddy', 'Iyer', 'Rao', 'Joshi'])
                else:
                    first_name = random.choice(['Aadhya', 'Ananya', 'Diya', 'Kavya', 'Kiara',
                                               'Navya', 'Pari', 'Sara', 'Saanvi', 'Anika',
                                               'Myra', 'Ira', 'Riya', 'Aarohi', 'Shanaya'])
                    last_name = random.choice(['Sharma', 'Gupta', 'Kumar', 'Singh', 'Verma',
                                             'Patel', 'Reddy', 'Iyer', 'Rao', 'Joshi'])
                name = f"{first_name} {last_name}"
            else:
                name = fake.name()
            
            # Generate unique email
            email_prefix = name.lower().replace(' ', '.').replace("'", "")
            email_domain = random.choice(['gmail.com', 'yahoo.com', 'outlook.com', 'email.com'])
            email = f"{email_prefix}{random.randint(1, 999)}@{email_domain}"
            
            # Assign country
            country = countries[i % len(countries)]
            
            # Assign school
            school = random.choice(SCHOOLS)
            
            delegates.append({
                'name': name,
                'email': email,
                'committee': committee,
                'country': country,
                'school': school
            })
    
    return delegates


def save_to_csv(delegates, filename='sample_delegates_200.csv'):
    """Save delegates to CSV file"""
    filepath = os.path.join(os.path.dirname(__file__), '..', 'uploads', filename)
    
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['name', 'email', 'committee', 'country', 'school'])
        writer.writeheader()
        writer.writerows(delegates)
    
    print(f"✓ Generated {len(delegates)} delegates")
    print(f"✓ Saved to: {filepath}")
    
    # Print statistics
    print("\nCommittee Distribution:")
    for committee in COMMITTEES:
        count = len([d for d in delegates if d['committee'] == committee])
        print(f"  {committee}: {count} delegates")
    
    return filepath


def generate_additional_test_data():
    """Generate additional test CSV files for various scenarios"""
    
    # 1. Small test file (10 delegates)
    delegates_small = generate_delegate_data()[:10]
    save_to_csv(delegates_small, 'test_small_10.csv')
    
    # 2. Duplicate emails test
    delegates_dup = delegates_small.copy()
    delegates_dup[5]['email'] = delegates_dup[2]['email']  # Duplicate
    save_to_csv(delegates_dup, 'test_duplicate_emails.csv')
    
    # 3. Invalid committee test
    delegates_invalid = delegates_small.copy()
    delegates_invalid[3]['committee'] = 'INVALID_COMMITTEE'
    save_to_csv(delegates_invalid, 'test_invalid_committee.csv')
    
    # 4. Missing fields test
    delegates_missing = delegates_small.copy()
    delegates_missing[4]['email'] = ''  # Missing email
    save_to_csv(delegates_missing, 'test_missing_fields.csv')
    
    print("\n✓ Generated additional test files for edge cases")


if __name__ == "__main__":
    print("Generating MUN Sample Data...")
    print("=" * 60)
    
    # Generate main dataset
    delegates = generate_delegate_data()
    save_to_csv(delegates)
    
    print("\n" + "=" * 60)
    print("Generating test datasets for edge cases...")
    generate_additional_test_data()
    
    print("\n" + "=" * 60)
    print("✅ All sample data generated successfully!")
    print("\nFiles created in /uploads directory:")
    print("  - sample_delegates_200.csv (Main dataset)")
    print("  - test_small_10.csv (Small test)")
    print("  - test_duplicate_emails.csv (Duplicate test)")
    print("  - test_invalid_committee.csv (Invalid data test)")
    print("  - test_missing_fields.csv (Missing fields test)")
