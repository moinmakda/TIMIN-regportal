#!/usr/bin/env python3
"""
Simulate 100,000 delegates clicking their check-in links at the EXACT SAME MOMENT
This is the ultimate stress test - simulating a real conference scenario
"""

import asyncio
import aiohttp
import time
import sys
from typing import List, Dict
import json

BASE_URL = "http://localhost:8000"
TOTAL_DELEGATES = 100000
CONCURRENT_LIMIT = 10000  # Max concurrent connections

class CheckInSimulator:
    def __init__(self):
        self.results = {
            "success": 0,
            "failed": 0,
            "errors": []
        }
        self.start_time = None
        self.end_time = None
        
    async def check_in_delegate(self, session: aiohttp.ClientSession, reg_number: str, semaphore: asyncio.Semaphore) -> Dict:
        """Simulate a single delegate clicking their check-in link"""
        async with semaphore:
            try:
                # Step 1: Load the check-in page (like clicking the link)
                async with session.get(
                    f"{BASE_URL}/checkin/{reg_number}",
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status != 200:
                        return {
                            "reg_number": reg_number,
                            "success": False,
                            "error": f"Page load failed: {response.status}"
                        }
                
                # Step 2: Click "Check In Now" button (POST to geolocation endpoint)
                # Simulate with random location (like real delegates)
                import random
                latitude = 28.6139 + random.uniform(-0.5, 0.5)  # Delhi coordinates
                longitude = 77.2090 + random.uniform(-0.5, 0.5)
                
                checkin_data = {
                    "registration_number": reg_number,
                    "latitude": latitude,
                    "longitude": longitude
                }
                
                async with session.post(
                    f"{BASE_URL}/api/geolocation-checkin",
                    json=checkin_data,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        return {
                            "reg_number": reg_number,
                            "success": True
                        }
                    else:
                        error_text = await response.text()
                        return {
                            "reg_number": reg_number,
                            "success": False,
                            "error": f"Check-in failed: {response.status} - {error_text[:100]}"
                        }
                        
            except asyncio.TimeoutError:
                return {
                    "reg_number": reg_number,
                    "success": False,
                    "error": "Timeout after 30s"
                }
            except Exception as e:
                return {
                    "reg_number": reg_number,
                    "success": False,
                    "error": str(e)
                }
    
    async def simulate_concurrent_checkins(self):
        """Simulate all 100k delegates clicking at the EXACT same moment"""
        print("🚀 ULTIMATE STRESS TEST: 100,000 CONCURRENT CHECK-INS")
        print("=" * 70)
        print(f"📊 Total Delegates: {TOTAL_DELEGATES:,}")
        print(f"⚡ Concurrent Limit: {CONCURRENT_LIMIT:,}")
        print(f"🎯 Target: All clicking at the exact same moment")
        print("=" * 70)
        
        # Create semaphore to limit concurrent connections
        semaphore = asyncio.Semaphore(CONCURRENT_LIMIT)
        
        # Create connector with proper settings
        connector = aiohttp.TCPConnector(
            limit=CONCURRENT_LIMIT,
            limit_per_host=CONCURRENT_LIMIT,
            ttl_dns_cache=300,
            force_close=False,
            enable_cleanup_closed=True
        )
        
        # Create session
        timeout = aiohttp.ClientTimeout(total=60, connect=10, sock_read=30)
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            print("\n🔥 Launching all 100,000 check-ins simultaneously...")
            print("⏱️  Starting NOW!\n")
            
            self.start_time = time.time()
            
            # Create all tasks at once - simulating exact simultaneous clicks
            tasks = []
            for i in range(TOTAL_DELEGATES):
                reg_number = f"TIMUN{400286 + i:06d}"
                task = self.check_in_delegate(session, reg_number, semaphore)
                tasks.append(task)
            
            # Execute all tasks concurrently
            # This simulates all delegates clicking at the exact same moment
            results = []
            completed = 0
            
            # Process in chunks to show progress
            chunk_size = 10000
            for i in range(0, len(tasks), chunk_size):
                chunk = tasks[i:i + chunk_size]
                chunk_results = await asyncio.gather(*chunk, return_exceptions=True)
                
                for result in chunk_results:
                    if isinstance(result, Exception):
                        self.results["failed"] += 1
                        self.results["errors"].append(str(result))
                    elif result.get("success"):
                        self.results["success"] += 1
                    else:
                        self.results["failed"] += 1
                        self.results["errors"].append(result.get("error", "Unknown error"))
                
                completed += len(chunk)
                elapsed = time.time() - self.start_time
                rate = completed / elapsed if elapsed > 0 else 0
                
                print(f"📈 Progress: {completed:,}/{TOTAL_DELEGATES:,} ({completed/TOTAL_DELEGATES*100:.1f}%) "
                      f"| ⚡ {rate:.0f} req/s | ✅ {self.results['success']:,} | ❌ {self.results['failed']:,}")
            
            self.end_time = time.time()
    
    def print_results(self):
        """Print comprehensive test results"""
        duration = self.end_time - self.start_time
        success_rate = (self.results["success"] / TOTAL_DELEGATES) * 100
        avg_rate = TOTAL_DELEGATES / duration
        
        print("\n" + "=" * 70)
        print("🎯 STRESS TEST RESULTS")
        print("=" * 70)
        print(f"⏱️  Duration: {duration:.2f} seconds")
        print(f"⚡ Average Rate: {avg_rate:.2f} requests/second")
        print(f"📊 Total Requests: {TOTAL_DELEGATES:,}")
        print(f"✅ Successful: {self.results['success']:,}")
        print(f"❌ Failed: {self.results['failed']:,}")
        print(f"📈 Success Rate: {success_rate:.2f}%")
        print("=" * 70)
        
        if success_rate >= 99.99:
            print("🎉 EXCELLENT! Success rate >= 99.99%")
        elif success_rate >= 99:
            print("✅ GOOD! Success rate >= 99%")
        elif success_rate >= 95:
            print("⚠️  ACCEPTABLE! Success rate >= 95%")
        else:
            print("❌ NEEDS IMPROVEMENT! Success rate < 95%")
        
        # Show sample errors if any
        if self.results["errors"]:
            print(f"\n📋 Sample Errors (showing first 10):")
            unique_errors = {}
            for error in self.results["errors"]:
                error_type = error.split(":")[0] if ":" in error else error
                unique_errors[error_type] = unique_errors.get(error_type, 0) + 1
            
            for error_type, count in sorted(unique_errors.items(), key=lambda x: x[1], reverse=True)[:10]:
                print(f"  • {error_type}: {count} occurrences")
        
        print("\n" + "=" * 70)

async def main():
    """Main execution"""
    # Check if server is running
    print("🔍 Checking if server is running...")
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{BASE_URL}/health", timeout=aiohttp.ClientTimeout(total=5)) as response:
                if response.status == 200:
                    print("✅ Server is running!\n")
                else:
                    print(f"❌ Server returned status {response.status}")
                    sys.exit(1)
    except Exception as e:
        print(f"❌ Server is not running! Error: {e}")
        print("   Please start the server first: cd backend && uvicorn main:app --reload")
        sys.exit(1)
    
    # Run simulation
    simulator = CheckInSimulator()
    await simulator.simulate_concurrent_checkins()
    simulator.print_results()
    
    # Verify in database
    print("\n🔍 Verifying results in database...")
    import sqlite3
    conn = sqlite3.connect("database/mun_complete_system.db")
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM delegates WHERE attendance_marked = TRUE")
    marked_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM delegates WHERE registration_number != 'TIMUN400285'")
    total_count = cursor.fetchone()[0]
    
    conn.close()
    
    print(f"📊 Database shows {marked_count:,} / {total_count:,} delegates checked in")
    print(f"📈 Database success rate: {(marked_count / total_count * 100):.2f}%")
    
    print("\n✨ Test complete! Check the admin dashboard to see live updates:")
    print("   http://localhost:8000/admin")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user")
        sys.exit(1)
