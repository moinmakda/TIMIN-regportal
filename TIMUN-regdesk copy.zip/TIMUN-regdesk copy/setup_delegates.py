#!/usr/bin/env python3
"""
Setup TIMUN 2025 with 4 specific delegates and send emails
"""
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend.database import SessionLocal, Delegate, init_database
from backend.email_service import send_batch_emails
import csv

def clear_delegates():
    """Remove all existing delegates"""
    db = SessionLocal()
    try:
        count = db.query(Delegate).count()
        db.query(Delegate).delete()
        db.commit()
        print(f"✅ Cleared {count} existing delegates")
    finally:
        db.close()

def add_delegates():
    """Add the 4 TIMUN delegates"""
    delegates_data = [
        {
            'registration_number': 'TIMUN001',
            'name': 'moin1',
            'full_name': 'moin1',
            'email': 'moinmakda1@gmail.com',
            'committee': 'UNGA',
            'country': 'India',
            'payment_status': True,
            'attendance_marked': False,
            'email_sent': False
        },
        {
            'registration_number': 'TIMUN002',
            'name': 'moin2',
            'full_name': 'moin2',
            'email': 'imranbarakti@gmail.com',
            'committee': 'UNGA',
            'country': 'Pakistan',
            'payment_status': True,
            'attendance_marked': False,
            'email_sent': False
        },
        {
            'registration_number': 'TIMUN003',
            'name': 'moin3',
            'full_name': 'moin3',
            'email': 'moinshipyard@gmail.com',
            'committee': 'UNHRC',
            'country': 'USA',
            'payment_status': True,
            'attendance_marked': False,
            'email_sent': False
        },
        {
            'registration_number': 'TIMUN004',
            'name': 'moin4',
            'full_name': 'moin4',
            'email': 'moin.ug24@nsut.ac.in',
            'committee': 'JSP',
            'country': 'India',
            'payment_status': True,
            'attendance_marked': False,
            'email_sent': False
        }
    ]
    
    db = SessionLocal()
    try:
        for data in delegates_data:
            delegate = Delegate(**data)
            db.add(delegate)
        
        db.commit()
        print(f"✅ Added {len(delegates_data)} delegates:")
        for d in delegates_data:
            print(f"   - {d['name']} ({d['email']}) - {d['committee']}, {d['country']}")
    finally:
        db.close()

def send_emails_to_delegates():
    """Send emails to all 4 delegates"""
    db = SessionLocal()
    try:
        delegates = db.query(Delegate).filter(Delegate.email_sent == False).all()
        
        if not delegates:
            print("⚠️  No delegates need emails")
            return
        
        print(f"\n📧 Sending emails to {len(delegates)} delegates...")
        print("=" * 60)
        
        results = send_batch_emails(delegates, batch_size=10, delay=1)
        
        print("\n" + "=" * 60)
        print("📊 Email Summary:")
        print(f"   Total: {results['total']}")
        print(f"   ✅ Sent: {results['sent']}")
        print(f"   ❌ Failed: {results['failed']}")
        
        if results['failed_emails']:
            print("\n⚠️  Failed emails:")
            for email in results['failed_emails']:
                print(f"   - {email}")
        
        print("\n✅ Email sending complete!")
        
    finally:
        db.close()

def main():
    print("=" * 60)
    print("🎓 The Indraprastha MUN 2025 - Delegate Setup")
    print("=" * 60)
    print()
    
    # Initialize database
    print("📊 Initializing database...")
    init_database()
    
    # Clear existing delegates
    print("\n🗑️  Clearing existing delegates...")
    clear_delegates()
    
    # Add new delegates
    print("\n➕ Adding 4 TIMUN delegates...")
    add_delegates()
    
    # Ask before sending emails
    print("\n" + "=" * 60)
    response = input("📧 Send emails to these 4 delegates now? (yes/no): ").strip().lower()
    
    if response in ['yes', 'y']:
        send_emails_to_delegates()
    else:
        print("⏭️  Skipped email sending")
        print("   You can send emails later from the admin dashboard")
    
    print("\n" + "=" * 60)
    print("✅ Setup complete!")
    print("=" * 60)
    print()
    print("🌐 Next steps:")
    print("   1. Start backend: python -m uvicorn backend.main:app --reload")
    print("   2. Start frontend: cd frontend-react && npm run dev")
    print("   3. Login: http://localhost:5173")
    print("   4. Username: admin, Password: admin123")
    print()

if __name__ == "__main__":
    main()
