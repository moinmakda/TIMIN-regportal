/**
 * Format a date/time string to IST (Indian Standard Time)
 * @param dateString - ISO date string or timestamp
 * @returns Formatted date in IST timezone
 */
export function formatToIST(dateString: string | null | undefined): string {
  if (!dateString) return '-';
  
  const date = new Date(dateString);
  
  // Format: "DD MMM YYYY, HH:mm IST"
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  };
  
  const formatted = new Intl.DateTimeFormat('en-IN', options).format(date);
  return `${formatted} IST`;
}

/**
 * Format just the time in IST
 * @param dateString - ISO date string or timestamp
 * @returns Formatted time in IST timezone
 */
export function formatTimeIST(dateString: string | null | undefined): string {
  if (!dateString) return '-';
  
  const date = new Date(dateString);
  
  const options: Intl.DateTimeFormatOptions = {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  };
  
  const formatted = new Intl.DateTimeFormat('en-IN', options).format(date);
  return `${formatted} IST`;
}

/**
 * Get current date/time in IST for reports
 */
export function getCurrentIST(): string {
  return formatToIST(new Date().toISOString());
}
