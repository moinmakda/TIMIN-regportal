import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import type { Delegate } from '../types';

interface ManualCheckinModalProps {
  onClose: () => void;
  onCheckin: (registrationNumber: string) => Promise<{ success: boolean; message: string }>;
}

export default function ManualCheckinModal({ onClose, onCheckin }: ManualCheckinModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [committeeFilter, setCommitteeFilter] = useState('');
  const [delegates, setDelegates] = useState<Delegate[]>([]);
  const [filteredDelegates, setFilteredDelegates] = useState<Delegate[]>([]);
  const [committees, setCommittees] = useState<string[]>([]);
  const [selectedDelegate, setSelectedDelegate] = useState<Delegate | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    loadDelegates();
  }, []);

  const filterDelegates = useCallback(() => {
    let filtered = delegates;

    if (committeeFilter) {
      filtered = filtered.filter((d) => d.committee === committeeFilter);
    }

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (d) =>
          d.name.toLowerCase().includes(term) ||
          d.registration_number.toLowerCase().includes(term)
      );
    }

    setFilteredDelegates(filtered.slice(0, 10)); // Show max 10 suggestions
  }, [delegates, committeeFilter, searchTerm]);

  useEffect(() => {
    filterDelegates();
  }, [filterDelegates]);

  const loadDelegates = async () => {
    try {
      const data = await api.getDelegates();
      setDelegates(data);
      const uniqueCommittees = [...new Set(data.map(d => d.committee))].sort();
      setCommittees(uniqueCommittees);
    } catch (error) {
      console.error('Error loading delegates:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDelegate) return;

    setLoading(true);
    setResult(null);

    try {
      const response = await onCheckin(selectedDelegate.registration_number);
      setResult(response);
      
      if (response.success) {
        setTimeout(() => {
          setSearchTerm('');
          setSelectedDelegate(null);
          setResult(null);
        }, 2000);
      }
    } catch {
      setResult({ success: false, message: 'Error processing request' });
    } finally {
      setLoading(false);
    }
  };

  const selectDelegate = (delegate: Delegate) => {
    setSelectedDelegate(delegate);
    setSearchTerm(delegate.name);
    setFilteredDelegates([]);
  };

  return (
    <div className="modal active" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Manual Check-in</h2>
          <button className="close-modal" onClick={onClose}>×</button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="committee">Committee (Optional)</label>
            <select
              id="committee"
              className="form-control"
              value={committeeFilter}
              onChange={(e) => setCommitteeFilter(e.target.value)}
              disabled={loading}
            >
              <option value="">All Committees</option>
              {committees.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="delegateName">Delegate Name</label>
            <input
              id="delegateName"
              type="text"
              className="form-control"
              placeholder="Search by name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              autoFocus
              disabled={loading}
            />
            <small className="form-text">Type delegate name to see suggestions</small>
            
            {filteredDelegates.length > 0 && searchTerm && !selectedDelegate && (
              <div className="suggestions-list">
                {filteredDelegates.map(delegate => (
                  <div
                    key={delegate.registration_number}
                    className="suggestion-item"
                    onClick={() => selectDelegate(delegate)}
                  >
                    <div className="suggestion-name">{delegate.name}</div>
                    <div className="suggestion-details">
                      {delegate.committee} • {delegate.country} • {delegate.registration_number}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {selectedDelegate && (
            <div className="selected-delegate">
              <strong>{selectedDelegate.name}</strong>
              <p>{selectedDelegate.committee} - {selectedDelegate.country}</p>
              <p><small>{selectedDelegate.registration_number}</small></p>
            </div>
          )}

          {result && (
            <div className={`alert ${result.success ? 'alert-success' : 'alert-error'}`}>
              {result.success ? '✓' : '✗'} {result.message}
            </div>
          )}

          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || !selectedDelegate}
            >
              {loading ? 'Processing...' : 'Mark Present'}
            </button>
          </div>
        </form>

        <div className="manual-checkin-tips">
          <h4>Quick Tips:</h4>
          <ul>
            <li>Search by delegate name to find them quickly</li>
            <li>Filter by committee to narrow down results</li>
            <li>The system will prevent duplicate check-ins</li>
            <li>Changes are reflected immediately across all stations</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
