import { useState, useMemo } from 'react';
import type { Delegate } from '../types';
import { formatToIST, formatTimeIST, getCurrentIST } from '../utils/dateFormat';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

interface DelegateTableProps {
  delegates: Delegate[];
  onRefresh?: () => void;
}

export default function DelegateTable({ delegates }: DelegateTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [committeeFilter, setCommitteeFilter] = useState('');

  const committees = useMemo(() => {
    const unique = new Set(delegates.map((d) => d.committee));
    return Array.from(unique).sort();
  }, [delegates]);

  const filteredDelegates = useMemo(() => {
    return delegates.filter((delegate) => {
      const matchesSearch =
        delegate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        delegate.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        delegate.registration_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        delegate.committee.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCommittee = !committeeFilter || delegate.committee === committeeFilter;

      return matchesSearch && matchesCommittee;
    });
  }, [delegates, searchTerm, committeeFilter]);

  const downloadCSV = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('http://localhost:8000/api/export/all', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to download CSV');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `delegates_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading CSV:', error);
      alert('Failed to download CSV. Please try again.');
    }
  };

  const downloadPDF = () => {
    try {
      const doc = new jsPDF();

      const committeesToExport = committeeFilter
        ? [committeeFilter]
        : committees;

      for (const committee of committeesToExport) {
        const committeeDelegates = delegates.filter((d) => d.committee === committee);
        const present = committeeDelegates.filter((d) => d.attendance_marked).length;
        const total = committeeDelegates.length;
        const rate = total > 0 ? ((present / total) * 100).toFixed(1) : 0;

        doc.setFontSize(20);
        doc.setTextColor(107, 91, 149);
        doc.text('TIMUN 2025', 105, 20, { align: 'center' });

        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text(`${committee} - Attendance Report`, 105, 30, { align: 'center' });

      doc.setFontSize(10);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${getCurrentIST()}`, 105, 38, { align: 'center' });

      doc.setFontSize(12);
      doc.setTextColor(0, 0, 0);
      doc.text(`Total: ${total} | Present: ${present} | Absent: ${total - present} | Rate: ${rate}%`, 105, 48, { align: 'center' });

      const tableData = committeeDelegates.map((d, i) => [
        i + 1,
        d.name,
        d.country,
        d.registration_number,
        d.attendance_marked ? 'Present' : 'Absent',
        formatTimeIST(d.attendance_time),
      ]);

      autoTable(doc, {
        startY: 55,
        head: [['#', 'Name', 'Country', 'Registration', 'Status', 'Time']],
        body: tableData,
        theme: 'striped',
        headStyles: { fillColor: [139, 122, 184], textColor: 255, fontStyle: 'bold' },
        styles: { fontSize: 9 },
        columnStyles: { 0: { cellWidth: 10 }, 3: { cellWidth: 30 } },
      });

      if (committeesToExport.indexOf(committee) < committeesToExport.length - 1) {
        doc.addPage();
      }
    }

    doc.save(`TIMUN_Attendance_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  return (
    <div className="section">
      <div className="section-header">
        <h2 className="section-title">Delegate Management</h2>
        <p className="section-subtitle">View and manage all registered delegates ({filteredDelegates.length} of {delegates.length})</p>
      </div>

      <div className="action-bar">
        <input
          type="text"
          className="search-box"
          placeholder="Search by name, email, committee, or registration number..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div className="action-group">
          <select
            className="search-box"
            style={{ maxWidth: '200px' }}
            value={committeeFilter}
            onChange={(e) => setCommitteeFilter(e.target.value)}
          >
            <option value="">All Committees</option>
            {committees.map((committee) => (
              <option key={committee} value={committee}>
                {committee}
              </option>
            ))}
          </select>
          <button className="btn btn-primary" onClick={downloadPDF}>
            <svg className="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Download PDF
          </button>
          <button className="btn btn-secondary" onClick={downloadCSV}>
            <svg className="btn-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export CSV
          </button>
        </div>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Registration</th>
              <th>Name</th>
              <th>Email</th>
              <th>Committee</th>
              <th>Country</th>
              <th>Status</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {filteredDelegates.map((delegate) => (
              <tr key={delegate.registration_number}>
                <td><strong>{delegate.registration_number}</strong></td>
                <td>{delegate.name}</td>
                <td>{delegate.email}</td>
                <td>{delegate.committee}</td>
                <td>{delegate.country}</td>
                <td>
                  <span className={`badge ${delegate.attendance_marked ? 'badge-success' : 'badge-danger'}`}>
                    {delegate.attendance_marked ? 'Present' : 'Absent'}
                  </span>
                </td>
                <td>{formatToIST(delegate.attendance_time)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
