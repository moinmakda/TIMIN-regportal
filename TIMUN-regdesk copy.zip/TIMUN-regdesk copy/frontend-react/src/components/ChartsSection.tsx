import { Doughnut, Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import type { Stats, Delegate } from '../types';

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface ChartsSectionProps {
  stats: Stats;
  delegates: Delegate[];
}

export default function ChartsSection({ stats, delegates }: ChartsSectionProps) {
  const { overall, committees } = stats;

  // Attendance Overview
  const attendanceData = {
    labels: ['Present', 'Absent'],
    datasets: [
      {
        data: [overall.present, overall.absent],
        backgroundColor: ['#10B981', '#EF4444'],
        borderWidth: 0,
      },
    ],
  };

  // Committee Distribution
  const committeeData = {
    labels: committees.map((c) => c.committee),
    datasets: [
      {
        label: 'Total Delegates',
        data: committees.map((c) => c.total_registered),
        backgroundColor: '#8B7AB8',
      },
    ],
  };

  // Committee Attendance Rates
  const attendanceRatesData = {
    labels: committees.map((c) => c.committee),
    datasets: [
      {
        label: 'Attendance Rate (%)',
        data: committees.map((c) => c.attendance_rate),
        backgroundColor: committees.map((c) =>
          c.attendance_rate >= 75 ? '#10B981' :
          c.attendance_rate >= 50 ? '#F59E0B' : '#EF4444'
        ),
      },
    ],
  };

  // Check-in Methods
  const methodCounts: Record<string, number> = {};
  delegates.forEach((d) => {
    if (d.attendance_marked && d.attendance_method) {
      methodCounts[d.attendance_method] = (methodCounts[d.attendance_method] || 0) + 1;
    }
  });

  const methodsData = {
    labels: Object.keys(methodCounts).map((m) => m.replace(/_/g, ' ').toUpperCase()),
    datasets: [
      {
        data: Object.values(methodCounts),
        backgroundColor: ['#8B7AB8', '#10B981', '#F59E0B', '#EF4444', '#6B5B95'],
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
      },
    },
  };

  const barOptions = {
    ...chartOptions,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const horizontalBarOptions = {
    ...chartOptions,
    indexAxis: 'y' as const,
    scales: {
      x: {
        beginAtZero: true,
        max: 100,
      },
    },
  };

  return (
    <div className="charts-section">
      <div className="charts-grid">
        <div className="chart-card">
          <div className="chart-header">
            <div>
              <div className="chart-title">Attendance Overview</div>
              <div className="chart-subtitle">Present vs Absent distribution</div>
            </div>
          </div>
          <div className="chart-container">
            <Doughnut data={attendanceData} options={chartOptions} />
          </div>
        </div>

        <div className="chart-card">
          <div className="chart-header">
            <div>
              <div className="chart-title">Committee Distribution</div>
              <div className="chart-subtitle">Delegates per committee</div>
            </div>
          </div>
          <div className="chart-container">
            <Bar data={committeeData} options={{ ...barOptions, plugins: { legend: { display: false } } }} />
          </div>
        </div>

        <div className="chart-card">
          <div className="chart-header">
            <div>
              <div className="chart-title">Committee Attendance Rates</div>
              <div className="chart-subtitle">Attendance percentage by committee</div>
            </div>
          </div>
          <div className="chart-container">
            <Bar data={attendanceRatesData} options={{ ...horizontalBarOptions, plugins: { legend: { display: false } } }} />
          </div>
        </div>

        <div className="chart-card">
          <div className="chart-header">
            <div>
              <div className="chart-title">Check-in Methods</div>
              <div className="chart-subtitle">Distribution of attendance marking methods</div>
            </div>
          </div>
          <div className="chart-container">
            <Pie data={methodsData} options={chartOptions} />
          </div>
        </div>
      </div>
    </div>
  );
}
