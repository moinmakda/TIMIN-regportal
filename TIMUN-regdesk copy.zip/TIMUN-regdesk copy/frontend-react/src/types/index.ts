export interface Delegate {
  id?: number;
  registration_number: string;
  name: string;
  email: string;
  committee: string;
  country: string;
  school?: string;
  phone?: string;
  attendance_marked: boolean;
  attendance_time?: string;
  attendance_method?: string;
  check_in_link?: string;
}

export interface Stats {
  overall: {
    committee: string;
    total_registered: number;
    present: number;
    absent: number;
    attendance_rate: number;
    method_breakdown: {
      geolocation: number;
      qr_scan: number;
      manual: number;
      qr_scanner_admin: number;
    };
  };
  committees: CommitteeStats[];
}

export interface CommitteeStats {
  committee: string;
  total_registered: number;
  present: number;
  absent: number;
  attendance_rate: number;
  method_breakdown: {
    geolocation: number;
    qr_scan: number;
    manual: number;
    qr_scanner_admin: number;
  };
}

export interface WebSocketMessage {
  type: 'attendance_update' | 'stats_update' | 'delegate_registered';
  data?: unknown;
}

export interface ManualCheckin {
  registration_number: string;
}

export interface AttendanceResponse {
  success: boolean;
  message: string;
  delegate?: Delegate;
  committee?: string;
}

export interface AdminUser {
  id: number;
  username: string;
  email: string;
  full_name: string;
  created_at?: string;
}

export interface AuthSuccessResponse {
  success: true;
  access_token: string;
  token_type: string;
  admin: AdminUser;
}

export interface AuthErrorResponse {
  success: false;
  message?: string;
}

export type AuthResponse = AuthSuccessResponse | AuthErrorResponse;

export interface VerifyResponse {
  success: boolean;
  admin: AdminUser;
}
