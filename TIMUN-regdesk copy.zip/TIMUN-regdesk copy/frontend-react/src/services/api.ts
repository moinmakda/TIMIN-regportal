import type {
  Delegate,
  Stats,
  AttendanceResponse,
  WebSocketMessage,
  AuthResponse,
  VerifyResponse,
} from '../types';

const API_BASE = 'http://localhost:8000';

// Helper to build headers with optional JSON content type
interface HeaderOptions {
  includeJson?: boolean;
  includeAuth?: boolean;
}

const buildHeaders = ({ includeJson = false, includeAuth = true }: HeaderOptions = {}): HeadersInit => {
  const token = localStorage.getItem('auth_token');
  const headers: Record<string, string> = {};

  if (includeJson) {
    headers['Content-Type'] = 'application/json';
  }

  if (includeAuth && token) {
    headers.Authorization = `Bearer ${token}`;
  }

  return headers;
};

async function request<T>(path: string, init?: RequestInit, expectJson = true): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, init);

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Request failed with status ${response.status}`);
  }

  return expectJson ? ((await response.json()) as T) : (undefined as T);
}

export const api = {
  // Authentication
  async login(username: string, password: string): Promise<AuthResponse> {
    return request<AuthResponse>(
      '/api/auth/login',
      {
        method: 'POST',
        headers: buildHeaders({ includeJson: true, includeAuth: false }),
        body: JSON.stringify({ username, password }),
      }
    );
  },

  async verifyToken(): Promise<VerifyResponse> {
    return request<VerifyResponse>(
      '/api/auth/verify',
      {
        method: 'POST',
        headers: buildHeaders(),
      }
    );
  },

  // Get all delegates
  async getDelegates(): Promise<Delegate[]> {
    const data = await request<{ delegates?: Delegate[]; data?: Delegate[]; }>(
      '/api/delegates',
      {
        headers: buildHeaders(),
      }
    );
    return Array.isArray(data) ? data : data.delegates || [];
  },

  // Get statistics
  async getStats(): Promise<Stats> {
    const data = await request<{ overall: Stats['overall']; committees?: Stats['committees']; by_committee?: Stats['committees']; }>(
      '/api/stats',
      {
        headers: buildHeaders(),
      }
    );
    return {
      overall: data.overall,
      committees: data.committees || data.by_committee || []
    };
  },

  // Mark attendance manually
  async markAttendance(registrationNumber: string): Promise<AttendanceResponse> {
    return request<AttendanceResponse>(
      '/api/mark-attendance',
      {
        method: 'POST',
        headers: buildHeaders({ includeJson: true }),
        body: JSON.stringify({ registration_number: registrationNumber }),
      }
    );
  },

  // Mark attendance manually (alternative endpoint)
  async markAttendanceManual(registrationNumber: string): Promise<AttendanceResponse> {
    return request<AttendanceResponse>(
      '/api/mark-attendance-manual',
      {
        method: 'POST',
        headers: buildHeaders({ includeJson: true }),
        body: JSON.stringify({ registration_number: registrationNumber }),
      }
    );
  },

  // Export delegates CSV
  getExportUrl(): string {
    const token = localStorage.getItem('auth_token');
    return `${API_BASE}/api/export/all${token ? `?token=${encodeURIComponent(token)}` : ''}`;
  },

  // WebSocket connection
  connectWebSocket(onMessage: (data: WebSocketMessage) => void): WebSocket {
    const token = localStorage.getItem('auth_token');
    const wsUrl = token
      ? `ws://localhost:8000/ws/admin?token=${encodeURIComponent(token)}`
      : 'ws://localhost:8000/ws/admin';

    const ws = new WebSocket(wsUrl);
    
    ws.onmessage = (event) => {
      const data: WebSocketMessage = JSON.parse(event.data);
      onMessage(data);
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    ws.onclose = () => {
      console.log('WebSocket closed, reconnecting...');
      setTimeout(() => {
        api.connectWebSocket(onMessage);
      }, 3000);
    };

    return ws;
  }
};

