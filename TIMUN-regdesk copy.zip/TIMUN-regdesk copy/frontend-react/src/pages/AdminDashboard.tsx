import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { useAuth } from '../contexts/AuthContext';
import type { Delegate, Stats } from '../types';
import StatsCards from '../components/StatsCards';
import ChartsSection from '../components/ChartsSection';
import DelegateTable from '../components/DelegateTable';
import ManualCheckinModal from '../components/ManualCheckinModal';
import '../styles/AdminDashboard.css';

export default function AdminDashboard() {
  const [delegates, setDelegates] = useState<Delegate[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showManualCheckin, setShowManualCheckin] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const { logout, admin } = useAuth();
  const navigate = useNavigate();

  const loadData = async () => {
    try {
      const [delegatesData, statsData] = await Promise.all([
        api.getDelegates(),
        api.getStats(),
      ]);
      setDelegates(delegatesData);
      setStats(statsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Setup WebSocket
    wsRef.current = api.connectWebSocket((data) => {
      if (data.type === 'attendance_update' || data.type === 'stats_update') {
        loadData();
      }
    });

    // Auto-refresh every 30 seconds
    const interval = setInterval(loadData, 30000);

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      clearInterval(interval);
    };
  }, []);

  const handleManualCheckin = async (registrationNumber: string) => {
    try {
      const response = await api.markAttendanceManual(registrationNumber);
      if (response.success) {
        await loadData();
        return { success: true, message: response.message };
      } else {
        return { success: false, message: response.message };
      }
    } catch {
      return { success: false, message: 'Error marking attendance' };
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <div className="header-title">
            <img 
              src="/timun-logo.jpg" 
              alt="The Indraprastha MUN" 
              style={{ height: '50px', marginRight: '15px', borderRadius: '8px' }}
            />
            <div>
              <h1>The Indraprastha MUN 2025</h1>
              <p>Real-time Attendance Management System</p>
            </div>
          </div>
          <div className="header-actions">
            <div className="admin-info">
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <span>{admin?.full_name || admin?.username || 'Admin'}</span>
            </div>
            <button
              className="btn btn-primary"
              onClick={() => setShowManualCheckin(true)}
            >
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
              </svg>
              Manual Check-in
            </button>
            <button className="btn btn-secondary" onClick={loadData}>
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </button>
            <a href="/scanner" className="btn btn-success">
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
              </svg>
              Scanner Station
            </a>
            <button className="btn btn-logout" onClick={handleLogout}>
              <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="dashboard-container">
        {stats && <StatsCards stats={stats} />}
        
        {stats && <ChartsSection stats={stats} delegates={delegates} />}
        
        <DelegateTable delegates={delegates} onRefresh={loadData} />
      </div>

      {showManualCheckin && (
        <ManualCheckinModal
          onClose={() => setShowManualCheckin(false)}
          onCheckin={handleManualCheckin}
        />
      )}
    </div>
  );
}
