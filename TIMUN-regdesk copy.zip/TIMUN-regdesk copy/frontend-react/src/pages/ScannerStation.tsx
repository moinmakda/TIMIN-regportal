import { useState, useEffect, useRef, useCallback } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { api } from '../services/api';
import type { AttendanceResponse } from '../types';
import '../styles/ScannerStation.css';

export default function ScannerStation() {
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<AttendanceResponse | null>(null);
  const [stats, setStats] = useState({ scanned: 0, errors: 0 });
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const videoRef = useRef<HTMLDivElement>(null);

  const stopScanner = useCallback(async () => {
    if (scannerRef.current && scanning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current = null;
        setScanning(false);
      } catch (error) {
        console.error('Error stopping scanner:', error);
      }
    }
  }, [scanning]);

  const lastScannedRef = useRef<{ code: string; time: number } | null>(null);

  const handleScan = useCallback(async (registrationNumber: string) => {
    // Prevent duplicate scans within 3 seconds
    const now = Date.now();
    if (lastScannedRef.current && 
        lastScannedRef.current.code === registrationNumber && 
        now - lastScannedRef.current.time < 3000) {
      return; // Ignore duplicate scan
    }

    lastScannedRef.current = { code: registrationNumber, time: now };

    try {
      const response = await api.markAttendance(registrationNumber);
      
      setResult(response);
      
      if (response.success) {
        setStats(prev => ({ ...prev, scanned: prev.scanned + 1 }));
        // Auto-clear success message after 2 seconds
        setTimeout(() => setResult(null), 2000);
      } else {
        setStats(prev => ({ ...prev, errors: prev.errors + 1 }));
        // Auto-clear error message after 3 seconds
        setTimeout(() => setResult(null), 3000);
      }
    } catch {
      setResult({
        success: false,
        message: 'Network error. Please try again.',
      });
      setStats(prev => ({ ...prev, errors: prev.errors + 1 }));
      setTimeout(() => setResult(null), 3000);
    }
  }, []);

  const startScanner = useCallback(async () => {
    if (!videoRef.current || scanning) {
      return;
    }

    try {
      const scanner = new Html5Qrcode('qr-reader');
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 300, height: 300 },
        },
        async (decodedText) => {
          // Process the scanned QR code
          await handleScan(decodedText);
        },
        () => {
          // Ignore scanning errors (they happen continuously)
        }
      );

      setScanning(true);
    } catch (error) {
      console.error('Error starting scanner:', error);
      alert('Failed to start camera. Please check permissions.');
    }
  }, [handleScan, scanning]);

  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, [stopScanner]);

  return (
    <div className="scanner-station">
      <header className="scanner-header">
        <div className="header-content">
          <img 
            src="/timun-logo.jpg" 
            alt="The Indraprastha MUN" 
            style={{ height: '45px', marginRight: '12px', borderRadius: '8px' }}
          />
          <h1>The Indraprastha MUN 2025 - Check-in Scanner</h1>
          <div className="scanner-stats">
            <div className="stat-item success">
              <span className="stat-value">{stats.scanned}</span>
              <span className="stat-label">Scanned</span>
            </div>
            <div className="stat-item error">
              <span className="stat-value">{stats.errors}</span>
              <span className="stat-label">Errors</span>
            </div>
          </div>
        </div>
      </header>

      <div className="scanner-container">
        <div className="scanner-card">
          <div className="scanner-video" id="qr-reader" ref={videoRef}></div>
          
          <div className="scanner-controls">
            {!scanning ? (
              <button className="btn btn-large btn-success" onClick={startScanner}>
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Start Scanning
              </button>
            ) : (
              <button className="btn btn-large btn-danger" onClick={stopScanner}>
                <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                </svg>
                Stop Scanning
              </button>
            )}
          </div>

          {result && (
            <div className={`scan-result ${result.success ? 'success' : 'error'}`}>
              <div className="result-icon">
                {result.success ? (
                  <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ) : (
                  <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )}
              </div>
              <div className="result-content">
                <h3>{result.success ? 'Check-in Successful!' : 'Error'}</h3>
                <p>{result.message}</p>
                {result.delegate && (
                  <div className="delegate-info">
                    <p><strong>{result.delegate.name}</strong></p>
                    <p>{result.delegate.committee} - {result.delegate.country}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="scanner-instructions">
            <h3>Instructions</h3>
            <ol>
              <li>Click "Start Scanning" to activate the camera</li>
              <li>Point the camera at the delegate's QR code</li>
              <li>Wait for automatic detection and check-in</li>
              <li>The system will show success or error messages</li>
            </ol>
          </div>
        </div>

        <div className="quick-links">
          <a href="/" className="link-card">
            <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span>Admin Dashboard</span>
          </a>
        </div>
      </div>
    </div>
  );
}
