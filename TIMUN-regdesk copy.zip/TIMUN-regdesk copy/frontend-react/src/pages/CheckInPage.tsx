import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import '../styles/CheckInPage.css';

interface DelegateInfo {
  name: string;
  email: string;
  registration_number: string;
  committee: string;
  country: string;
  school: string | null;
  arrival_slot: string | null;
  attendance_marked: boolean;
  payment_status: boolean;
  qr_code: string;
}

interface PopupMessage {
  type: 'success' | 'error' | 'warning';
  title: string;
  message: string;
  distance?: number;
}

function CheckInPage() {
  const { token } = useParams<{ token: string }>();
  const [delegate, setDelegate] = useState<DelegateInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [checkedIn, setCheckedIn] = useState(false);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [popup, setPopup] = useState<PopupMessage | null>(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    fetchDelegateInfo();
    getLocation();
  }, [token]);

  const getLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  };

  const fetchDelegateInfo = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/delegate-by-link/${token}`);
      const data = await response.json();

      if (data.success) {
        setDelegate(data.delegate);
        if (data.delegate.attendance_marked) {
          setCheckedIn(true);
        }
      } else {
        setError('Invalid check-in link');
      }
    } catch (err) {
      setError('Failed to load delegate information');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

    const showPopup = (type: 'success' | 'error' | 'warning', title: string, message: string, distance?: number) => {
    setPopup({ type, title, message, distance });
    setTimeout(() => setPopup(null), 5000);
  };

  const handleCheckIn = async () => {
    if (!delegate || !location) {
      showPopup('warning', 'Location Required', 'Please enable location services to check in');
      return;
    }

    setChecking(true);
    try {
      const response = await fetch('http://localhost:8000/api/geolocation-checkin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          registration_number: delegate.registration_number,
          latitude: location.latitude,
          longitude: location.longitude,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setCheckedIn(true);
        showPopup('success', 'Check-in Successful!', `Welcome to The Indraprastha MUN, ${delegate.name}!`);
        fetchDelegateInfo();
      } else {
        if (data.location_invalid) {
          showPopup('error', 'Too Far From Campus', data.message, Math.round(data.distance_meters));
        } else if (data.payment_pending) {
          showPopup('warning', 'Payment Pending', data.message);
        } else if (data.already_marked) {
          showPopup('success', 'Already Checked In', data.message);
          setCheckedIn(true);
        } else {
          showPopup('error', 'Check-in Failed', data.message || 'Please try again');
        }
      }
    } catch (err) {
      showPopup('error', 'Connection Error', 'Unable to connect to server. Please try again.');
      console.error(err);
    } finally {
      setChecking(false);
    }
  };

  if (loading) {
    return (
      <div className="checkin-container">
        <div className="checkin-card loading">
          <div className="spinner"></div>
          <p>Loading your information...</p>
        </div>
      </div>
    );
  }

  if (error || !delegate) {
    return (
      <div className="checkin-container">
        <div className="checkin-card error">
          <div className="error-icon">⚠️</div>
          <h1>Invalid Check-in Link</h1>
          <p>This link is not valid. Please check your email or contact the organizing committee.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="checkin-container">
      {popup && (
        <div className="popup-overlay" onClick={() => setPopup(null)}>
          <div className={`popup-modal popup-${popup.type}`} onClick={(e) => e.stopPropagation()}>
            <button className="popup-close" onClick={() => setPopup(null)}>✕</button>
            <div className="popup-icon-large">
              {popup.type === 'success' && '✓'}
              {popup.type === 'error' && '✕'}
              {popup.type === 'warning' && '⚠'}
            </div>
            <h2 className="popup-title">{popup.title}</h2>
            <p className="popup-message">{popup.message}</p>
            {popup.distance && (
              <div className="popup-distance">
                <span className="distance-number">{popup.distance}m</span>
                <span className="distance-label">from campus</span>
              </div>
            )}
          </div>
        </div>
      )}
      <div className="checkin-card">
        <div className="checkin-header">
          <img 
            src="https://www.theindraprastha.com/images/logo.png" 
            alt="The Indraprastha MUN" 
            className="mun-logo"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
          />
          <h1>Delegate Check-In</h1>
        </div>

        {checkedIn ? (
          <div className="success-message">
            <div className="success-icon">✓</div>
            <h2>Already Checked In!</h2>
            <p>You have already completed your check-in.</p>
          </div>
        ) : (
          <>
            <div className="delegate-info">
              <div className="info-row">
                <span className="label">Name:</span>
                <span className="value">{delegate.name}</span>
              </div>
              <div className="info-row">
                <span className="label">Registration:</span>
                <span className="value">{delegate.registration_number}</span>
              </div>
              <div className="info-row">
                <span className="label">Committee:</span>
                <span className="value">{delegate.committee}</span>
              </div>
              <div className="info-row">
                <span className="label">Country:</span>
                <span className="value">{delegate.country}</span>
              </div>
              <div className="info-row">
                <span className="label">Email:</span>
                <span className="value">{delegate.email}</span>
              </div>
            </div>

            <div className="qr-code-section">
              <h3>Your QR Code</h3>
              <img src={delegate.qr_code} alt="QR Code" className="qr-code" />
              <p className="qr-info">Show this QR code at the registration desk</p>
            </div>

            {!location && (
              <div className="location-warning">
                <p>⚠️ Please enable location services to check in</p>
              </div>
            )}

            <button 
              className="checkin-button"
              onClick={handleCheckIn}
              disabled={!location || checking}
            >
              {checking ? 'Checking In...' : (location ? 'Complete Check-In' : 'Waiting for Location...')}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export default CheckInPage;
