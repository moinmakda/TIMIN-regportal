#!/usr/bin/env python3
"""
Generate 700 delegate registrations for TIMUN 2025
Creates realistic data with proper distribution across committees
"""

import psycopg2
import secrets
import sys
from pathlib import Path

# PostgreSQL connection
DB_URL = "postgresql://localhost/timun_attendance"

# Realistic MUN committees
COMMITTEES = [
    "UNGA", "UNSC", "ECOSOC", "UNHRC", "DISEC", 
    "SOCHUM", "SPECPOL", "WHO", "UNEP", "UNESCO",
    "G20", "EU", "NATO", "ASEAN", "AU"
]

# Top 50 countries for realistic distribution
COUNTRIES = [
    "USA", "CHINA", "INDIA", "RUSSIA", "UK", "FRANCE", "GERMANY", "JAPAN",
    "BRAZIL", "CANADA", "AUSTRALIA", "SOUTH KOREA", "SPAIN", "ITALY", "MEXICO",
    "INDONESIA", "NETHERLANDS", "SAUDI ARABIA", "TURKEY", "SWITZERLAND",
    "ARGENTINA", "SWEDEN", "POLAND", "BELGIUM", "THAILAND", "AUSTRIA",
    "NORWAY", "UAE", "NIGERIA", "ISRAEL", "SINGAPORE", "MALAYSIA", "IRELAND",
    "DENMARK", "PHILIPPINES", "PAKISTAN", "BANGLADESH", "VIETNAM", "EGYPT",
    "SOUTH AFRICA", "CHILE", "FINLAND", "PORTUGAL", "GREECE", "CZECH REPUBLIC",
    "NEW ZEALAND", "ROMANIA", "PERU", "HUNGARY", "UKRAINE"
]

# Common first names
FIRST_NAMES = [
    "Aarav", "Aditi", "Aiden", "Alex", "Amara", "Arjun", "Aria", "Benjamin",
    "Carlos", "Chen", "David", "Emma", "Ethan", "Fatima", "Hassan", "Isabella",
    "James", "Jasmine", "John", "Kai", "Liam", "Lucas", "Maria", "Michael",
    "Mohammed", "Noah", "Olivia", "Priya", "Ravi", "Ryan", "Sakura", "Samuel",
    "Sarah", "Sophia", "Yuki", "Zara", "Ahmed", "Ana", "Daniel", "Elena",
    "Gabriel", "Hannah", "Isaac", "Julia", "Kevin", "Laura", "Marco", "Nina",
    "Omar", "Paula"
]

# Common last names
LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
    "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill",
    "Flores", "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell",
    "Mitchell", "Carter"
]

SCHOOLS = [
    "Delhi Public School", "The Doon School", "Bishop Cotton School", "Mayo College",
    "Modern School", "Shri Ram School", "Sanskriti School", "Vasant Valley School",
    "Bangalore International School", "Cathedral School", "St. Xavier's School",
    "Campion School", "Greenwood High", "Inventure Academy", "National Public School",
    "Ryan International", "DPS International", "Oberoi International", "JBCN International",
    "Singapore International School"
]

def generate_delegates(count: int = 700):
    """Generate realistic delegate data"""
    print(f"🚀 Generating {count:,} delegate registrations...")
    
    conn = psycopg2.connect(DB_URL)
    cursor = conn.cursor()
    
    # Clear existing test data (keep only Moin)
    cursor.execute("DELETE FROM delegates WHERE registration_number != 'TIMUN400285'")
    conn.commit()
    
    delegates = []
    batch_size = 10000
    
    for i in range(count):
        reg_num = f"TIMUN{400286 + i:06d}"  # Start after Moin's number
        
        # Generate realistic name
        first_name = FIRST_NAMES[i % len(FIRST_NAMES)]
        last_name = LAST_NAMES[(i // len(FIRST_NAMES)) % len(LAST_NAMES)]
        name = f"{first_name} {last_name}"
        
        # Generate email
        email = f"{first_name.lower()}.{last_name.lower()}.{i}@timun2025.com"
        
        # Distribute across committees
        committee = COMMITTEES[i % len(COMMITTEES)]
        
        # Assign country
        country = COUNTRIES[i % len(COUNTRIES)]
        
        # Assign school
        school = SCHOOLS[i % len(SCHOOLS)]
        
        # Generate unique QR token
        qr_token = secrets.token_urlsafe(32)
        
        # Generate check-in link
        checkin_link = f"/checkin/{reg_num}"
        
        # Random arrival slot (morning/afternoon)
        arrival_slot = "Morning (9 AM - 12 PM)" if i % 2 == 0 else "Afternoon (1 PM - 5 PM)"
        
        delegates.append((
            reg_num, name, email, committee, country, school,
            qr_token, checkin_link, arrival_slot, "paid",
            False, False  # attendance_marked, kit_collected
        ))
        
        # Insert in batches
        if len(delegates) >= batch_size or i == count - 1:
            cursor.executemany("""
                INSERT INTO delegates (
                    registration_number, name, email, committee, country, school,
                    qr_code_token, unique_checkin_link, arrival_slot, payment_status,
                    attendance_marked, kit_collected
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, delegates)
            conn.commit()
            
            print(f"  ✅ Inserted {i + 1:,} / {count:,} delegates ({((i + 1) / count * 100):.1f}%)")
            delegates = []
    
    conn.close()
    print(f"🎉 Successfully created {count:,} delegate registrations!")
    
    # Print sample links
    print(f"\n📋 Sample Check-in Links:")
    for i in range(5):
        reg_num = f"TIMUN{400286 + i:06d}"
        print(f"  {i + 1}. http://localhost:8000/checkin/{reg_num}")
    print(f"  ...")
    print(f"  700. http://localhost:8000/checkin/TIMUN{400286 + 699:06d}")

if __name__ == "__main__":
    import time
    start = time.time()
    generate_delegates(700)
    elapsed = time.time() - start
    print(f"\n⏱️  Generation completed in {elapsed:.2f} seconds")
    print(f"📊 Rate: {700 / elapsed:.0f} delegates/second")
