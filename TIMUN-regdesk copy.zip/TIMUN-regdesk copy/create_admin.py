#!/usr/bin/env python3
"""
Initialize Admin User for TIMUN Attendance System
Creates default admin account if none exists
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database import SessionLocal, Admin, init_database
from backend.auth import get_password_hash


def create_default_admin():
    """Create default admin user"""
    init_database()
    db = SessionLocal()
    
    try:
        # Check if admin already exists
        existing_admin = db.query(Admin).filter(Admin.username == "admin").first()
        
        if existing_admin:
            print("⚠️  Admin user already exists!")
            print(f"   Username: admin")
            print("   Use the existing credentials or delete the admin from database.")
            return
        
        # Create default admin
        admin = Admin(
            username="admin",
            password_hash=get_password_hash("admin123"),
            email="admin@timun2025.com",
            full_name="TIMUN Administrator"
        )
        
        db.add(admin)
        db.commit()
        
        print("✅ Default admin user created successfully!")
        print("")
        print("=" * 60)
        print("   Username: admin")
        print("   Password: admin123")
        print("=" * 60)
        print("")
        print("⚠️  IMPORTANT: Change the password immediately in production!")
        print("")
        
    except Exception as e:
        print(f"❌ Error creating admin: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    create_default_admin()
