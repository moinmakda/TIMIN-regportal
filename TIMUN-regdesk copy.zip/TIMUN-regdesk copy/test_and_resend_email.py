#!/usr/bin/env python3
"""
Test email with QR code and resend if needed
"""
import sys
sys.path.insert(0, '.')

from backend.database import SessionLocal, Delegate
from backend.email_service import create_email_html, send_email

db = SessionLocal()

# Get one delegate to test
delegate = db.query(Delegate).filter(Delegate.email == 'moinmakda1@gmail.com').first()

if delegate:
    print(f"Testing email for: {delegate.name} ({delegate.email})")
    print(f"Registration: {delegate.registration_number}")
    print(f"Committee: {delegate.committee}")
    print(f"Country: {delegate.country}")
    print()
    
    # Generate email HTML
    html = create_email_html(delegate)
    
    # Check if QR code is in the HTML
    if 'data:image/png;base64' in html:
        print("✅ QR code is embedded in email!")
        qr_start = html.find('data:image/png;base64,')
        qr_sample = html[qr_start:qr_start+50]
        print(f"   QR code preview: {qr_sample}...")
    else:
        print("❌ QR code NOT found in email!")
    
    # Check if checkin link is in the HTML
    if '/checkin/' in html:
        print("✅ Check-in link is in email!")
    else:
        print("❌ Check-in link NOT found!")
    
    print()
    response = input("Do you want to resend email to all 4 delegates? (yes/no): ").strip().lower()
    
    if response in ['yes', 'y']:
        print("\n📧 Resending emails to all 4 delegates...")
        print("=" * 70)
        
        # Mark all as not sent
        delegates = db.query(Delegate).all()
        for d in delegates:
            d.email_sent = False
        db.commit()
        
        # Send emails
        from backend.email_service import send_batch_emails
        delegates = db.query(Delegate).filter(Delegate.email_sent == False).all()
        results = send_batch_emails(delegates, batch_size=10, delay=2)
        
        print("\n📊 Results:")
        print(f"   Total: {results['total']}")
        print(f"   Sent: {results['sent']}")
        print(f"   Failed: {results['failed']}")
        
        if results['sent'] == results['total']:
            print("\n✅ All emails resent successfully!")
        else:
            print(f"\n⚠️ Some emails failed to send")
    else:
        print("Skipped resending")

db.close()
