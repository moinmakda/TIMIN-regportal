"""
Email Service Module with QR Code Generation
"""
import smtplib
import qrcode
import io
import base64
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from typing import List, Dict
from datetime import datetime
from backend.database import Delegate, SessionLocal


# Email configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "announcement.indraprastha@gmail.com"
SENDER_PASSWORD = "vxqj rdrc zkit grhe"  # App password
BASE_URL = "http://localhost:5175"  # Frontend URL

# SMTP Configuration dictionary
SMTP_CONFIG = {
    "server": SMTP_SERVER,
    "port": SMTP_PORT,
    "email": SENDER_EMAIL,
    "password": SENDER_PASSWORD,
    "use_tls": True,
}

# Backup email accounts for load balancing
EMAIL_ACCOUNTS = [
    {
        "email": "announcement.indraprastha@gmail.com",
        "password": "vxqj rdrc zkit grhe",
        "name": "The Indraprastha MUN",
    },
    {
        "email": "indraprastha.announcement@gmail.com",
        "password": "kksw jjhc maey ureh",
        "name": "The Indraprastha MUN",
    },
]

# Base URL for check-in links (frontend URL used in emails)
# Keep a single authoritative BASE_URL. For local dev this points to the frontend dev server.
BASE_URL = "http://localhost:5175"  # Frontend URL (dev)


def generate_qr_code_image(delegate: Delegate) -> bytes:
    """
    Generate QR code image for a delegate

    Args:
        delegate: Delegate object

    Returns:
        QR code image as bytes
    """
    qr_data = {
        "qr_code": delegate.qr_token,
        "name": delegate.name,
        "committee": delegate.committee,
        "registration_number": delegate.registration_number,
        "timestamp": datetime.utcnow().isoformat(),
    }

    # Convert to JSON string
    qr_string = json.dumps(qr_data)

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(qr_string)
    qr.make(fit=True)

    # Create image
    img = qr.make_image(fill_color="black", back_color="white")

    # Convert to bytes
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format="PNG")
    img_byte_arr.seek(0)

    return img_byte_arr.getvalue()


def generate_qr_code_base64(delegate: Delegate) -> str:
    """
    Generate QR code as base64 string for embedding in email

    Args:
        delegate: Delegate object

    Returns:
        Base64 encoded QR code image
    """
    qr_bytes = generate_qr_code_image(delegate)
    return base64.b64encode(qr_bytes).decode("utf-8")


def create_email_html(delegate: Delegate) -> str:
    """
    Create HTML email template for delegate

    Args:
        delegate: Delegate object

    Returns:
        HTML email content
    """
    checkin_url = f"{BASE_URL}/checkin/{delegate.unique_token}"
    qr_base64 = generate_qr_code_base64(delegate)

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
            }}
            .container {{
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
            }}
            .header {{
                background-color: #1e40af;
                color: white;
                padding: 20px;
                text-align: center;
                border-radius: 8px 8px 0 0;
            }}
            .content {{
                padding: 20px;
                background-color: #f9fafb;
            }}
            .info-box {{
                background-color: white;
                padding: 15px;
                margin: 15px 0;
                border-left: 4px solid #1e40af;
            }}
            .button {{
                display: inline-block;
                padding: 12px 30px;
                background-color: #16a34a;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                margin: 10px 0;
            }}
            .qr-section {{
                text-align: center;
                padding: 20px;
                background-color: white;
                margin: 15px 0;
                border-radius: 8px;
            }}
            .instructions {{
                background-color: #fef3c7;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }}
            .footer {{
                text-align: center;
                color: #6b7280;
                font-size: 12px;
                padding: 15px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>MUN 2025 - Registration Confirmed</h1>
            </div>
            
            <div class="content">
                <h2>Dear {delegate.name},</h2>
                
                <div class="info-box">
                    <p><strong>Registration Number:</strong> {delegate.registration_number}</p>
                    <p><strong>Committee:</strong> {delegate.committee}</p>
                    {f'<p><strong>Country:</strong> {delegate.country}</p>' if delegate.country else ''}
                    <p><strong>Arrival Slot:</strong> {delegate.arrival_slot}</p>
                </div>
                
                <hr>
                
                <h3>📱 EVENT DAY CHECK-IN OPTIONS:</h3>
                
                <div class="info-box">
                    <h4>1. SMART CHECK-IN (Recommended)</h4>
                    <p>Click this button on your phone when you arrive at campus:</p>
                    <p style="text-align: center;">
                        <a href="{checkin_url}" class="button">CHECK-IN HERE</a>
                    </p>
                    <p style="font-size: 12px; color: #6b7280;">
                        Link: {checkin_url}
                    </p>
                </div>
                
                <div class="qr-section">
                    <h4>2. QR CODE (Backup)</h4>
                    <p>Show this QR code at the registration desk:</p>
                    <img src="data:image/png;base64,{qr_base64}" alt="QR Code" width="200" height="200">
                    <p style="font-size: 12px; color: #6b7280;">Registration: {delegate.registration_number}</p>
                </div>
                
                <div class="instructions">
                    <h4>📋 Instructions:</h4>
                    <ul>
                        <li>Arrive during your time slot: <strong>{delegate.arrival_slot}</strong></li>
                        <li>Click the check-in link when on campus</li>
                        <li>Allow location access when prompted</li>
                        <li>Attendance will be marked instantly!</li>
                        <li>If you face any issues, show your QR code at the desk</li>
                    </ul>
                </div>
                
                <div class="info-box">
                    <p><strong>📍 Location:</strong> Campus (28.658500, 77.212700)</p>
                    <p><strong>📅 Date:</strong> Event Day</p>
                    <p><strong>⏰ Registration Opens:</strong> 9:00 AM</p>
                </div>
                
                <p>We look forward to seeing you at MUN 2025!</p>
                
                <p>Best regards,<br>
                <strong>MUN 2025 Organizing Team</strong></p>
            </div>
            
            <div class="footer">
                <p>This is an automated email. Please do not reply.</p>
                <p>For queries, contact: mun@college.edu</p>
            </div>
        </div>
    </body>
    </html>
    """

    return html


def send_email(delegate: Delegate, smtp_config: Dict = None) -> bool:
    """
    Send email to a single delegate

    Args:
        delegate: Delegate object
        smtp_config: SMTP configuration (optional, uses default if not provided)

    Returns:
        True if successful, False otherwise
    """
    if smtp_config is None:
        smtp_config = SMTP_CONFIG

    try:
        # Create message
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"MUN 2025 - Your Check-in Credentials ({delegate.committee})"
        msg["From"] = smtp_config["email"]
        msg["To"] = delegate.email

        # Create HTML content
        html_content = create_email_html(delegate)
        html_part = MIMEText(html_content, "html")
        msg.attach(html_part)

        # Connect to SMTP server
        server = smtplib.SMTP(smtp_config["server"], smtp_config["port"])
        if smtp_config["use_tls"]:
            server.starttls()

        server.login(smtp_config["email"], smtp_config["password"])

        # Send email
        server.send_message(msg)
        server.quit()

        # Update database
        db = SessionLocal()
        try:
            db_delegate = db.query(Delegate).filter(Delegate.id == delegate.id).first()
            if db_delegate:
                db_delegate.email_sent = True
                db_delegate.email_sent_time = datetime.utcnow()
                db.commit()
        finally:
            db.close()

        return True

    except Exception as e:
        print(f"Failed to send email to {delegate.email}: {str(e)}")
        return False


def send_batch_emails(delegates: List[Delegate], batch_size: int = 10, delay: int = 2) -> Dict:
    """
    Send emails to multiple delegates in batches

    Args:
        delegates: List of Delegate objects
        batch_size: Number of emails to send per batch
        delay: Delay in seconds between batches

    Returns:
        Dictionary with results
    """
    import time

    results = {"total": len(delegates), "sent": 0, "failed": 0, "failed_emails": []}

    for i in range(0, len(delegates), batch_size):
        batch = delegates[i : i + batch_size]

        for delegate in batch:
            success = send_email(delegate)
            if success:
                results["sent"] += 1
            else:
                results["failed"] += 1
                results["failed_emails"].append({"email": delegate.email, "name": delegate.name})

        # Delay between batches (except for last batch)
        if i + batch_size < len(delegates):
            time.sleep(delay)

    return results


def get_email_queue_status() -> Dict:
    """
    Get status of email sending queue

    Returns:
        Dictionary with email sending statistics
    """
    db = SessionLocal()
    try:
        total = db.query(Delegate).count()
        sent = db.query(Delegate).filter(Delegate.email_sent == True).count()
        pending = total - sent

        return {
            "total": total,
            "sent": sent,
            "pending": pending,
            "percentage": round((sent / total * 100) if total > 0 else 0, 1),
        }
    finally:
        db.close()


def retry_failed_emails() -> Dict:
    """
    Retry sending emails that failed previously

    Returns:
        Dictionary with retry results
    """
    db = SessionLocal()
    try:
        # Get delegates where email was not sent
        failed_delegates = db.query(Delegate).filter(Delegate.email_sent == False).all()

        if not failed_delegates:
            return {"message": "No failed emails to retry", "retry_count": 0}

        results = send_batch_emails(failed_delegates)
        return results
    finally:
        db.close()


if __name__ == "__main__":
    print("Email Service Module")
    print("=" * 50)
    print("IMPORTANT: Update SMTP_CONFIG with your credentials before using!")
    print()
    print("SMTP Configuration:")
    print(f"  Server: {SMTP_CONFIG['server']}")
    print(f"  Port: {SMTP_CONFIG['port']}")
    print(f"  Email: {SMTP_CONFIG['email']}")
    print(f"  Password: {'*' * len(SMTP_CONFIG['password'])}")
