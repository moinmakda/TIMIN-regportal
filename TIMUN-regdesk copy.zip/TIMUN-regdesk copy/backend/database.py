"""
Database models and helper utilities used by tests.

This module provides a lightweight, test-friendly SQLAlchemy setup and model
definitions aligned with the test suite expectations (field names and defaults).
It creates the engine lazily in `init_database()` so tests can override
`DATABASE_URL` before initialization.
"""
from sqlalchemy import create_engine, Column, Integer, String, Boolean, Float, DateTime, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import Session as ORMSession
from sqlalchemy import event
from sqlalchemy.exc import IntegrityError
from datetime import datetime
import os
from functools import wraps
import time
from typing import Optional


# Default to a file-based SQLite DB in the project directory; tests can override
# DATABASE_URL before calling init_database().
_DEFAULT_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "database", "mun_complete_system.db")
DATABASE_URL = os.environ.get("DATABASE_URL") or f"sqlite:///{_DEFAULT_DB_PATH}"

# Engine and session will be created when init_database() is called so tests
# can set DATABASE_URL before initialization.
from sqlalchemy import create_engine as _create_engine

# Create a default engine/session at import time using DATABASE_URL. init_database
# will recreate them if DATABASE_URL is changed before initialization.
engine = _create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Delegate(Base):
    __tablename__ = "delegates"

    id = Column(Integer, primary_key=True, index=True)
    registration_number = Column(String, index=True, nullable=False)
    name = Column(String)
    full_name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String)
    committee = Column(String, nullable=False)
    country = Column(String)
    unique_token = Column(String)
    qr_token = Column(String)
    arrival_slot = Column(String)

    # Attendance and payment
    payment_status = Column(Boolean, default=False)
    attendance_marked = Column(Boolean, default=False)
    attendance_time = Column(DateTime)
    attendance_method = Column(String)
    email_sent = Column(Boolean, default=False)

    # Geolocation / distance
    checkin_latitude = Column(Float)
    checkin_longitude = Column(Float)
    distance_from_campus = Column(Float)

    # Kit collection
    kit_collected = Column(Boolean, default=False)
    kit_collected_time = Column(DateTime)

    created_at = Column(DateTime, default=datetime.utcnow)

    def __init__(self, **kwargs):
        # Mirror name/full_name fields for compatibility between legacy and tests
        if "name" not in kwargs and "full_name" in kwargs:
            kwargs["name"] = kwargs["full_name"]
        if "full_name" not in kwargs and "name" in kwargs:
            kwargs["full_name"] = kwargs["name"]
        super().__init__(**kwargs)

    def to_dict(self):
        return {
            "id": self.id,
            "registration_number": self.registration_number,
            "name": self.name,
            "full_name": self.full_name,
            "email": self.email,
            "phone": self.phone,
            "committee": self.committee,
            "country": self.country,
            "unique_token": self.unique_token,
            "qr_token": self.qr_token,
            "payment_status": self.payment_status,
            "attendance_marked": self.attendance_marked,
            "attendance_time": self.attendance_time.isoformat() if self.attendance_time else None,
            "attendance_method": self.attendance_method,
            "checkin_latitude": self.checkin_latitude,
            "checkin_longitude": self.checkin_longitude,
            "distance_from_campus": self.distance_from_campus,
            "kit_collected": self.kit_collected,
            "kit_collected_time": self.kit_collected_time.isoformat() if self.kit_collected_time else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Admin(Base):
    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="organizer")
    email = Column(String)
    full_name = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "role": self.role,
            "email": self.email,
            "full_name": self.full_name,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


@event.listens_for(ORMSession, "before_flush")
def _enforce_delegate_email_unique(session, flush_context, instances):
    """Ensure delegates cannot share the same email with different registration numbers in the same session."""
    email_registry = {}
    for instance in session.identity_map.values():
        if isinstance(instance, Delegate) and instance.email:
            email_registry.setdefault(instance.email, instance.registration_number)

    for obj in session.new:
        if isinstance(obj, Delegate) and obj.email:
            existing_reg = email_registry.get(obj.email)
            if existing_reg is not None and existing_reg != obj.registration_number:
                raise ValueError("Duplicate delegate email with different registration number is not allowed")
            email_registry[obj.email] = obj.registration_number


def get_db():
    """Dependency to get a database session (requires init_database to be called).

    Yields a SQLAlchemy session from SessionLocal.
    """
    global SessionLocal
    if SessionLocal is None:
        raise RuntimeError("Database not initialized. Call init_database() first.")
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_database():
    """Create the engine and initialize tables based on DATABASE_URL.

    This is intentionally lazy so tests can override DATABASE_URL before calling
    init_database().
    """
    global engine, SessionLocal, DATABASE_URL
    if engine is None:
        engine = create_engine(DATABASE_URL, echo=False)
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    
    # Enable WAL mode for SQLite to support concurrent writes (100+ users)
    if DATABASE_URL.startswith('sqlite'):
        with engine.connect() as conn:
            conn.execute(text("PRAGMA journal_mode=WAL"))
            conn.execute(text("PRAGMA synchronous=NORMAL"))
            conn.execute(text("PRAGMA cache_size=-64000"))  # 64MB cache
            conn.execute(text("PRAGMA temp_store=MEMORY"))
            conn.commit()

    # Note: Default admin creation removed from init_database()
    # Use create_admin.py script to set up admin with proper password hashing


def retry_on_db_lock(max_retries=3, base_delay=0.1):
    """Decorator to retry database operations on transient errors."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        time.sleep(delay)
                        continue
                    raise
            raise last_exception
        return wrapper
    return decorator
