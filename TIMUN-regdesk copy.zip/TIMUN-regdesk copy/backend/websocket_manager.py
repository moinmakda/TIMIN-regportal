"""
WebSocket Manager for Real-Time Updates
Handles broadcasting attendance updates to all connected clients
"""
from fastapi import WebSocket
from typing import Set, Dict
import asyncio
import json
from datetime import datetime


class ConnectionManager:
    """Manages WebSocket connections and broadcasts updates"""
    
    def __init__(self):
        # Store active connections by type
        self.active_connections: Dict[str, Set[WebSocket]] = {
            "admin": set(),      # Admin dashboards
            "delegate": set(),   # Individual delegate check-in pages
        }
        self.delegate_connections: Dict[str, WebSocket] = {}  # Map registration_number -> websocket
    
    async def connect(self, websocket: WebSocket, client_type: str = "admin", delegate_id: str = None):
        """Accept new WebSocket connection"""
        await websocket.accept()
        self.active_connections[client_type].add(websocket)
        
        if client_type == "delegate" and delegate_id:
            self.delegate_connections[delegate_id] = websocket
        
        print(f"✓ WebSocket connected - Type: {client_type}, Total connections: {self.get_connection_count()}")
    
    def disconnect(self, websocket: WebSocket, client_type: str = "admin", delegate_id: str = None):
        """Remove WebSocket connection"""
        if websocket in self.active_connections[client_type]:
            self.active_connections[client_type].remove(websocket)
        
        if client_type == "delegate" and delegate_id and delegate_id in self.delegate_connections:
            del self.delegate_connections[delegate_id]
        
        print(f"✗ WebSocket disconnected - Type: {client_type}, Remaining: {self.get_connection_count()}")
    
    async def broadcast_to_admins(self, message: dict):
        """Broadcast message to all admin dashboards"""
        dead_connections = set()
        
        for connection in self.active_connections["admin"]:
            try:
                await connection.send_json(message)
            except Exception as e:
                print(f"Error broadcasting to admin: {e}")
                dead_connections.add(connection)
        
        # Clean up dead connections
        for conn in dead_connections:
            self.active_connections["admin"].discard(conn)
    
    async def send_to_delegate(self, registration_number: str, message: dict):
        """Send message to specific delegate"""
        if registration_number in self.delegate_connections:
            try:
                await self.delegate_connections[registration_number].send_json(message)
            except Exception as e:
                print(f"Error sending to delegate {registration_number}: {e}")
                del self.delegate_connections[registration_number]
    
    async def broadcast_attendance_update(self, delegate_data: dict, method: str):
        """Broadcast attendance mark event"""
        message = {
            "type": "attendance_marked",
            "timestamp": datetime.utcnow().isoformat(),
            "data": {
                "name": delegate_data.get("name"),
                "registration_number": delegate_data.get("registration_number"),
                "committee": delegate_data.get("committee"),
                "method": method,
                "attendance_time": delegate_data.get("attendance_time"),
            }
        }
        await self.broadcast_to_admins(message)
        
        # Also notify the delegate
        await self.send_to_delegate(
            delegate_data.get("registration_number"),
            {
                "type": "attendance_confirmed",
                "message": f"✓ Attendance marked successfully via {method}!",
                "data": delegate_data
            }
        )
    
    async def broadcast_kit_collection(self, delegate_data: dict):
        """Broadcast kit collection event"""
        message = {
            "type": "kit_collected",
            "timestamp": datetime.utcnow().isoformat(),
            "data": {
                "name": delegate_data.get("name"),
                "registration_number": delegate_data.get("registration_number"),
                "committee": delegate_data.get("committee"),
                "collection_time": delegate_data.get("kit_collection_time"),
            }
        }
        await self.broadcast_to_admins(message)
        
        # Notify delegate
        await self.send_to_delegate(
            delegate_data.get("registration_number"),
            {
                "type": "kit_confirmed",
                "message": "✓ Kit collected successfully!",
                "data": delegate_data
            }
        )
    
    async def broadcast_stats_update(self, stats: dict):
        """Broadcast updated statistics"""
        message = {
            "type": "stats_update",
            "timestamp": datetime.utcnow().isoformat(),
            "data": stats
        }
        await self.broadcast_to_admins(message)
    
    def get_connection_count(self) -> int:
        """Get total number of active connections"""
        return sum(len(connections) for connections in self.active_connections.values())
    
    def get_admin_count(self) -> int:
        """Get number of admin connections"""
        return len(self.active_connections["admin"])
    
    def get_delegate_count(self) -> int:
        """Get number of delegate connections"""
        return len(self.delegate_connections)


# Global WebSocket manager instance
ws_manager = ConnectionManager()
