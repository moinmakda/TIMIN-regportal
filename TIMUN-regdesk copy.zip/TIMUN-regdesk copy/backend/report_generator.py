"""
Report Generation Module for EB Reports and Data Exports
"""
from typing import List, Dict
import csv
import io
from datetime import datetime
from backend.database import Delegate, SessionLocal
from sqlalchemy import func


def generate_committee_stats(committee: str = None) -> Dict:
    """
    Generate statistics for a committee or overall

    Args:
        committee: Committee name (None for overall stats)

    Returns:
        Dictionary with statistics
    """
    db = SessionLocal()
    try:
        query = db.query(Delegate)

        if committee:
            query = query.filter(Delegate.committee == committee.upper())

        total = query.count()
        present = query.filter(Delegate.attendance_marked == True).count()
        absent = total - present
        kits_collected = query.filter(Delegate.kit_collected == True).count()

        # Get method breakdown
        geo_count = query.filter(Delegate.attendance_method == "geolocation").count()
        qr_count = query.filter(Delegate.attendance_method == "qr_scan").count()
        manual_count = query.filter(Delegate.attendance_method == "manual").count()

        attendance_rate = round((present / total * 100) if total > 0 else 0, 1)
        kit_collection_rate = round((kits_collected / present * 100) if present > 0 else 0, 1)

        return {
            "committee": committee if committee else "Overall",
            "total_registered": total,
            "present": present,
            "absent": absent,
            "attendance_rate": attendance_rate,
            "kits_collected": kits_collected,
            "kits_pending": present - kits_collected,
            "kit_collection_rate": kit_collection_rate,
            "method_breakdown": {
                "geolocation": geo_count,
                "qr_scan": qr_count,
                "manual": manual_count,
            },
        }
    finally:
        db.close()


def generate_eb_report_text(committee: str) -> str:
    """
    Generate text-based EB report for a committee

    Args:
        committee: Committee name

    Returns:
        Formatted text report
    """
    db = SessionLocal()
    try:
        delegates = (
            db.query(Delegate)
            .filter(Delegate.committee == committee.upper())
            .order_by(Delegate.name)
            .all()
        )

        if not delegates:
            return f"No delegates found for committee: {committee}"

        stats = generate_committee_stats(committee)

        report = f"""
{'=' * 80}
              {committee.upper()} - ATTENDANCE REPORT
                    Date: {datetime.now().strftime('%Y-%m-%d')}
{'=' * 80}

SUMMARY:
{'=' * 80}
Total Registered:      {stats['total_registered']} delegates
Present:               {stats['present']} delegates ({stats['attendance_rate']}%)
Absent:                {stats['absent']} delegates ({100 - stats['attendance_rate']}%)
Kits Collected:        {stats['kits_collected']} ({stats['kit_collection_rate']}% of present)
Kits Pending:          {stats['kits_pending']} ({100 - stats['kit_collection_rate']}% of present)

Report Generated: {datetime.now().strftime('%I:%M %p')}
{'=' * 80}

DELEGATE LIST:
{'=' * 80}
{'Name':<30} {'Country':<15} {'Status':<10} {'Time':<10} {'Kit':<5}
{'-' * 80}
"""

        for delegate in delegates:
            status = "✓ Present" if delegate.attendance_marked else "✗ Absent"
            time_str = (
                delegate.attendance_time.strftime("%H:%M") if delegate.attendance_time else "-"
            )
            kit_str = "✓" if delegate.kit_collected else "✗"
            country = delegate.country if delegate.country else "-"

            report += (
                f"{delegate.name:<30} {country:<15} {status:<10} {time_str:<10} {kit_str:<5}\n"
            )

        report += f"\n{'=' * 80}\n"

        # Absent delegates section
        absent_delegates = [d for d in delegates if not d.attendance_marked]
        if absent_delegates:
            report += "\nABSENT DELEGATES:\n"
            report += "=" * 80 + "\n"
            for delegate in absent_delegates:
                country = delegate.country if delegate.country else "-"
                report += f"• {delegate.name} ({country})\n"
            report += "\n"

        report += f"""{'=' * 80}
This report can be regenerated at any time from
the Admin Dashboard → Committee Reports section
{'=' * 80}
"""

        return report
    finally:
        db.close()


def export_delegates_csv(filters: Dict = None) -> str:
    """
    Export delegates data to CSV format

    Args:
        filters: Dictionary with filter criteria (committee, attendance_marked, etc.)

    Returns:
        CSV content as string
    """
    db = SessionLocal()
    try:
        query = db.query(Delegate)

        # Apply filters
        if filters:
            if "committee" in filters and filters["committee"]:
                query = query.filter(Delegate.committee == filters["committee"].upper())

            if "attendance_marked" in filters:
                query = query.filter(Delegate.attendance_marked == filters["attendance_marked"])

            if "kit_collected" in filters:
                query = query.filter(Delegate.kit_collected == filters["kit_collected"])

            if "payment_status" in filters:
                query = query.filter(Delegate.payment_status == filters["payment_status"])

        delegates = query.order_by(Delegate.name).all()

        # Create CSV
        output = io.StringIO()
        writer = csv.writer(output)

        # Write header
        writer.writerow(
            [
                "Name",
                "Email",
                "Phone",
                "Committee",
                "Country",
                "Registration Number",
                "Arrival Slot",
                "Payment Status",
                "Attendance Marked",
                "Attendance Time",
                "Attendance Method",
                "Kit Collected",
                "Kit Collection Time",
                "Check-in Latitude",
                "Check-in Longitude",
                "Distance from Campus (m)",
            ]
        )

        # Write data
        for delegate in delegates:
            writer.writerow(
                [
                    delegate.name,
                    delegate.email,
                    delegate.phone or "",
                    delegate.committee,
                    delegate.country or "",
                    delegate.registration_number,
                    delegate.arrival_slot or "",
                    "Yes" if delegate.payment_status else "No",
                    "Yes" if delegate.attendance_marked else "No",
                    delegate.attendance_time.strftime("%Y-%m-%d %H:%M:%S")
                    if delegate.attendance_time
                    else "",
                    delegate.attendance_method or "",
                    "Yes" if delegate.kit_collected else "No",
                    delegate.kit_collected_time.strftime("%Y-%m-%d %H:%M:%S")
                    if delegate.kit_collected_time
                    else "",
                    delegate.checkin_latitude or "",
                    delegate.checkin_longitude or "",
                    f"{delegate.distance_from_campus:.0f}" if delegate.distance_from_campus else "",
                ]
            )

        return output.getvalue()
    finally:
        db.close()


def export_present_delegates_csv() -> str:
    """
    Export only present delegates to CSV

    Returns:
        CSV content as string
    """
    return export_delegates_csv({"attendance_marked": True})


def export_absent_delegates_csv() -> str:
    """
    Export only absent delegates to CSV

    Returns:
        CSV content as string
    """
    return export_delegates_csv({"attendance_marked": False})


def export_committee_csv(committee: str) -> str:
    """
    Export delegates for a specific committee

    Args:
        committee: Committee name

    Returns:
        CSV content as string
    """
    return export_delegates_csv({"committee": committee})


def get_all_committee_stats() -> List[Dict]:
    """
    Get statistics for all committees

    Returns:
        List of dictionaries with committee statistics
    """
    db = SessionLocal()
    try:
        committees = db.query(Delegate.committee).distinct().all()
        committees = [c[0] for c in committees]

        stats = []
        for committee in committees:
            stats.append(generate_committee_stats(committee))

        return stats
    finally:
        db.close()


def get_timeline_data() -> List[Dict]:
    """
    Get check-in timeline data for analysis

    Returns:
        List of dictionaries with timeline data
    """
    db = SessionLocal()
    try:
        delegates = (
            db.query(Delegate)
            .filter(Delegate.attendance_marked == True)
            .order_by(Delegate.attendance_time)
            .all()
        )

        timeline = []
        for delegate in delegates:
            timeline.append(
                {
                    "name": delegate.name,
                    "committee": delegate.committee,
                    "attendance_time": delegate.attendance_time.isoformat()
                    if delegate.attendance_time
                    else None,
                    "method": delegate.attendance_method,
                    "arrival_slot": delegate.arrival_slot,
                }
            )

        return timeline
    finally:
        db.close()


def generate_summary_report() -> Dict:
    """
    Generate overall summary report

    Returns:
        Dictionary with comprehensive statistics
    """
    overall_stats = generate_committee_stats()
    committee_stats = get_all_committee_stats()

    db = SessionLocal()
    try:
        # Get email statistics
        total_delegates = db.query(Delegate).count()
        emails_sent = db.query(Delegate).filter(Delegate.email_sent == True).count()

        # Get time slot performance
        slots = (
            db.query(Delegate.arrival_slot, func.count(Delegate.id))
            .group_by(Delegate.arrival_slot)
            .all()
        )

        slot_stats = {}
        for slot, count in slots:
            on_time = (
                db.query(Delegate)
                .filter(Delegate.arrival_slot == slot, Delegate.attendance_marked == True)
                .count()
            )
            slot_stats[slot] = {
                "total": count,
                "checked_in": on_time,
                "rate": round((on_time / count * 100) if count > 0 else 0, 1),
            }

        return {
            "total_registered": overall_stats["total_registered"],
            "total_checked_in": overall_stats["present"],
            "pending_checkin": overall_stats["absent"],
            "kit_collected": overall_stats.get("kits_collected", 0),
            "emails_sent": emails_sent,
            "emails_pending": total_delegates - emails_sent,
            "committees": committee_stats,
            "overall": overall_stats,
            "arrival_slots": slot_stats,
            "generated_at": datetime.utcnow().isoformat(),
        }
    finally:
        db.close()


if __name__ == "__main__":
    print("Report Generator Module")
    print("=" * 50)
    print("Available functions:")
    print("  - generate_committee_stats(committee)")
    print("  - generate_eb_report_text(committee)")
    print("  - export_delegates_csv(filters)")
    print("  - export_present_delegates_csv()")
    print("  - export_absent_delegates_csv()")
    print("  - get_all_committee_stats()")
    print("  - generate_summary_report()")
