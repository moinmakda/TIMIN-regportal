"""
Geolocation utilities for campus boundary checking
"""
from math import radians, sin, cos, sqrt, atan2
import secrets
import string
from datetime import datetime

# Campus configuration
CAMPUS_CENTER_LAT = 28.658500
CAMPUS_CENTER_LON = 77.212700
GEOFENCE_RADIUS = 500  # meters

# Allowed committees
ALLOWED_COMMITTEES = ["UNSC", "UNGA", "UNHRC", "DISEC", "ECOSOC", "OTHER"]


def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two GPS points using Haversine formula

    Args:
        lat1: Latitude of first point
        lon1: Longitude of first point
        lat2: Latitude of second point
        lon2: Longitude of second point

    Returns:
        Distance in meters
    """
    R = 6371000  # Earth radius in meters

    φ1 = radians(lat1)
    φ2 = radians(lat2)
    Δφ = radians(lat2 - lat1)
    Δλ = radians(lon2 - lon1)

    a = sin(Δφ / 2) ** 2 + cos(φ1) * cos(φ2) * sin(Δλ / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    distance = R * c
    return distance


def is_on_campus(delegate_lat, delegate_lon):
    """
    Check if delegate is within campus boundary

    Args:
        delegate_lat: Delegate's latitude
        delegate_lon: Delegate's longitude

    Returns:
        Tuple (is_inside: bool, distance: float)
    """
    distance = calculate_distance(delegate_lat, delegate_lon, CAMPUS_CENTER_LAT, CAMPUS_CENTER_LON)

    is_inside = distance <= GEOFENCE_RADIUS
    return is_inside, round(distance, 2)


def assign_arrival_slot(committee):
    """
    Assign arrival time slot based on committee

    Args:
        committee: Committee name

    Returns:
        Time slot string
    """
    slots = {
        "UNSC": "09:00-09:15",
        "UNGA": "09:15-09:30",
        "UNHRC": "09:30-09:45",
        "DISEC": "09:45-10:00",
        "ECOSOC": "10:00-10:15",
        "OTHER": "10:15-10:30",
    }
    return slots.get(committee.upper(), "10:15-10:30")


def generate_registration_number():
    """
    Generate unique registration number
    Format: MUN2025XXXXXXXX (where X is alphanumeric)

    Returns:
        Registration number string
    """
    random_part = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
    return f"MUN2025{random_part}"


def generate_qr_token():
    """
    Generate unique QR code token

    Returns:
        QR token string (32 characters)
    """
    return secrets.token_urlsafe(32)


def generate_checkin_link_token():
    """
    Generate unique check-in link token

    Returns:
        Check-in link token (48 characters)
    """
    return secrets.token_urlsafe(48)


def get_lane_assignment(name):
    """
    Assign kit collection lane based on first letter of name

    Args:
        name: Delegate name

    Returns:
        Lane assignment string
    """
    if not name:
        return "T-Z"

    first_letter = name[0].upper()

    if first_letter <= "F":
        return "A-F"
    elif first_letter <= "M":
        return "G-M"
    elif first_letter <= "S":
        return "N-S"
    else:
        return "T-Z"


def validate_committee(committee):
    """
    Check if committee name is valid

    Args:
        committee: Committee name to validate

    Returns:
        Boolean
    """
    return committee.upper() in ALLOWED_COMMITTEES


def validate_email(email):
    """
    Basic email validation

    Args:
        email: Email address to validate

    Returns:
        Boolean
    """
    import re

    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(pattern, email) is not None


def format_time_ago(dt):
    """
    Format datetime as "X minutes ago" or "X hours ago"

    Args:
        dt: datetime object

    Returns:
        Formatted string
    """
    if not dt:
        return "Never"

    now = datetime.utcnow()
    diff = now - dt

    seconds = diff.total_seconds()

    if seconds < 60:
        return "Just now"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    else:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"


def get_committee_color(committee):
    """
    Get color code for committee badges

    Args:
        committee: Committee name

    Returns:
        Hex color code
    """
    colors = {
        "UNSC": "#1e40af",  # Blue
        "UNGA": "#16a34a",  # Green
        "UNHRC": "#dc2626",  # Red
        "DISEC": "#ea580c",  # Orange
        "ECOSOC": "#9333ea",  # Purple
        "OTHER": "#6b7280",  # Gray
    }
    return colors.get(committee.upper(), "#6b7280")


if __name__ == "__main__":
    # Test geolocation functions
    print("Testing Geolocation Functions:")
    print("=" * 50)

    # Test on campus location
    is_inside, distance = is_on_campus(28.658234, 77.212456)
    print(f"Test 1 - Main Gate (28.658234, 77.212456):")
    print(f"  Inside campus: {is_inside}")
    print(f"  Distance: {distance}m")
    print()

    # Test outside campus location
    is_inside, distance = is_on_campus(28.659876, 77.215432)
    print(f"Test 2 - Nearby Cafe (28.659876, 77.215432):")
    print(f"  Inside campus: {is_inside}")
    print(f"  Distance: {distance}m")
    print()

    # Test token generation
    print("Token Generation Tests:")
    print(f"  Registration Number: {generate_registration_number()}")
    print(f"  QR Token: {generate_qr_token()}")
    print(f"  Check-in Link Token: {generate_checkin_link_token()}")
    print()

    # Test lane assignment
    print("Lane Assignment Tests:")
    print(f"  'Alex Kumar' → {get_lane_assignment('Alex Kumar')}")
    print(f"  'John Doe' → {get_lane_assignment('John Doe')}")
    print(f"  'Sarah Wilson' → {get_lane_assignment('Sarah Wilson')}")
    print(f"  'Zara Ahmed' → {get_lane_assignment('Zara Ahmed')}")
