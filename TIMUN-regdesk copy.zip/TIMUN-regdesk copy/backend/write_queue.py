"""
Async write queue for batching database writes
This solves the SQLite single-writer bottleneck for 100K+ concurrent users
"""
import asyncio
from typing import List, Tuple, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class DatabaseWriteQueue:
    """
    Batches database writes to handle massive concurrency
    Instead of 100K individual writes, we batch them into groups
    """
    def __init__(self, batch_size: int = 1000, flush_interval: float = 0.5):
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.queue: asyncio.Queue = asyncio.Queue()
        self.worker_task = None
        self.pending_futures = {}
        
    async def start(self):
        """Start the background worker"""
        if self.worker_task is None or self.worker_task.done():
            self.worker_task = asyncio.create_task(self._worker())
            logger.info(f"✓ Write queue worker started (batch_size={self.batch_size})")
    
    async def stop(self):
        """Stop the background worker"""
        if self.worker_task:
            self.worker_task.cancel()
            try:
                await self.worker_task
            except asyncio.CancelledError:
                pass
            logger.info("✗ Write queue worker stopped")
    
    async def enqueue_checkin(self, db_session, registration_number: str, 
                              latitude: float = None, longitude: float = None) -> bool:
        """
        Enqueue a check-in write operation
        Returns True if successful, False otherwise
        """
        future = asyncio.Future()
        await self.queue.put((db_session, registration_number, latitude, longitude, future))
        return await future
    
    async def _worker(self):
        """Background worker that batches and executes writes"""
        batch = []
        last_flush = asyncio.get_event_loop().time()
        
        while True:
            try:
                # Collect items for batch
                timeout = self.flush_interval - (asyncio.get_event_loop().time() - last_flush)
                timeout = max(0.01, timeout)
                
                try:
                    item = await asyncio.wait_for(self.queue.get(), timeout=timeout)
                    batch.append(item)
                except asyncio.TimeoutError:
                    pass
                
                # Flush if batch is full or time interval passed
                should_flush = (
                    len(batch) >= self.batch_size or
                    (len(batch) > 0 and asyncio.get_event_loop().time() - last_flush >= self.flush_interval)
                )
                
                if should_flush:
                    await self._flush_batch(batch)
                    batch = []
                    last_flush = asyncio.get_event_loop().time()
                    
            except asyncio.CancelledError:
                # Flush remaining items before stopping
                if batch:
                    await self._flush_batch(batch)
                break
            except Exception as e:
                logger.error(f"Write queue worker error: {e}")
                await asyncio.sleep(0.1)
    
    async def _flush_batch(self, batch: List[Tuple]):
        """Execute a batch of writes in a single transaction"""
        if not batch:
            return
        
        logger.info(f"📦 Flushing batch of {len(batch)} check-ins")
        
        # Group by database session
        sessions = {}
        for db_session, reg_num, lat, lon, future in batch:
            if db_session not in sessions:
                sessions[db_session] = []
            sessions[db_session].append((reg_num, lat, lon, future))
        
        # Execute all updates in batches per session
        for db_session, items in sessions.items():
            try:
                # Execute batch update using raw SQL for speed
                from sqlalchemy import text
                
                # Build batch UPDATE
                updates = []
                for reg_num, lat, lon, _ in items:
                    updates.append({
                        'reg_num': reg_num,
                        'lat': lat,
                        'lon': lon,
                        'now': datetime.utcnow()
                    })
                
                # Execute as a single transaction
                result = db_session.execute(
                    text("""
                        UPDATE delegates 
                        SET attendance_marked = 1,
                            attendance_time = :now,
                            checkin_latitude = :lat,
                            checkin_longitude = :lon
                        WHERE registration_number = :reg_num
                    """),
                    updates
                )
                db_session.commit()
                
                # Resolve all futures as successful
                for _, _, _, future in items:
                    if not future.done():
                        future.set_result(True)
                
                logger.info(f"✓ Batch committed: {len(items)} check-ins")
                
            except Exception as e:
                logger.error(f"Batch write failed: {e}")
                db_session.rollback()
                
                # Resolve futures as failed
                for _, _, _, future in items:
                    if not future.done():
                        future.set_result(False)

# Global write queue instance
write_queue = DatabaseWriteQueue(batch_size=500, flush_interval=0.1)
