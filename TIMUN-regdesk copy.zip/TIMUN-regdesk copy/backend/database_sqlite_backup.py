"""
Database models and configuration for MUN Attendance System
"""
from sqlalchemy import create_engine, Column, Integer, String, Boolean, Float, DateTime, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from datetime import datetime
import os
import time
import asyncio
from functools import wraps

# Database configuration
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_PATH = os.path.join(BASE_DIR, "database", "mun_complete_system.db")
DATABASE_URL = f"sqlite:///{DATABASE_PATH}"

# Create engine with SQLite-optimized settings for high concurrency
engine = create_engine(
    DATABASE_URL,
    echo=False,
    # Use StaticPool to maintain a single connection pool for SQLite
    poolclass=StaticPool,
    connect_args={
        "check_same_thread": False,
        "timeout": 300.0,  # 5 minutes timeout for extreme load
        "isolation_level": None,  # Autocommit mode for better concurrency
    },
)

# Enable WAL mode for concurrent reads during writes
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_conn, connection_record):
    """Set SQLite pragmas for optimal concurrency"""
    cursor = dbapi_conn.cursor()
    # WAL mode allows concurrent reads during writes
    cursor.execute("PRAGMA journal_mode=WAL")
    # Increase busy timeout to 5 minutes for extreme concurrency
    cursor.execute("PRAGMA busy_timeout=300000")
    # Synchronous mode NORMAL for better performance with WAL
    cursor.execute("PRAGMA synchronous=NORMAL")
    # Increase cache size to 64MB
    cursor.execute("PRAGMA cache_size=-64000")
    # Enable memory-mapped I/O for better performance
    cursor.execute("PRAGMA mmap_size=268435456")
    cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# Retry decorator for database operations
def retry_on_db_lock(max_retries=5, base_delay=0.1):
    """Decorator to retry database operations on lock"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    error_msg = str(e).lower()
                    # Check if it's a database lock error
                    if "locked" in error_msg or "busy" in error_msg:
                        if attempt < max_retries - 1:
                            # Exponential backoff with jitter
                            delay = base_delay * (2 ** attempt) * (0.5 + 0.5 * time.time() % 1)
                            time.sleep(delay)
                            continue
                    # If not a lock error or max retries reached, raise
                    raise
            raise last_exception
        return wrapper
    return decorator


class Delegate(Base):
    """
    Delegate model with all required fields for MUN attendance system
    """

    __tablename__ = "delegates"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    committee = Column(String, nullable=False, index=True)
    country = Column(String, nullable=True)
    school = Column(String, nullable=True)

    # Unique identifiers
    registration_number = Column(String, unique=True, nullable=False, index=True)
    qr_code_token = Column(String, unique=True, nullable=False, index=True)
    unique_checkin_link = Column(String, unique=True, nullable=False, index=True)

    # Scheduling
    arrival_slot = Column(String, nullable=False)

    # Payment and status
    payment_status = Column(Boolean, default=False)

    # Pre check-in (optional feature)
    pre_checkin_done = Column(Boolean, default=False)
    pre_checkin_time = Column(DateTime, nullable=True)

    # Attendance tracking
    attendance_marked = Column(Boolean, default=False, index=True)
    attendance_time = Column(DateTime, nullable=True)
    attendance_method = Column(String, nullable=True)  # 'geolocation', 'qr_scan', 'manual'

    # Geolocation data
    checkin_latitude = Column(Float, nullable=True)
    checkin_longitude = Column(Float, nullable=True)

    # Kit collection
    kit_collected = Column(Boolean, default=False)
    kit_collection_time = Column(DateTime, nullable=True)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Email tracking
    email_sent = Column(Boolean, default=False)
    email_sent_time = Column(DateTime, nullable=True)

    def to_dict(self):
        """Convert delegate object to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "committee": self.committee,
            "country": self.country,
            "school": self.school,
            "registration_number": self.registration_number,
            "qr_code_token": self.qr_code_token,
            "unique_checkin_link": self.unique_checkin_link,
            "arrival_slot": self.arrival_slot,
            "payment_status": self.payment_status,
            "pre_checkin_done": self.pre_checkin_done,
            "pre_checkin_time": self.pre_checkin_time.isoformat()
            if self.pre_checkin_time
            else None,
            "attendance_marked": self.attendance_marked,
            "attendance_time": self.attendance_time.isoformat() if self.attendance_time else None,
            "attendance_method": self.attendance_method,
            "checkin_latitude": self.checkin_latitude,
            "checkin_longitude": self.checkin_longitude,
            "kit_collected": self.kit_collected,
            "kit_collection_time": self.kit_collection_time.isoformat()
            if self.kit_collection_time
            else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "email_sent": self.email_sent,
            "email_sent_time": self.email_sent_time.isoformat() if self.email_sent_time else None,
        }


class Admin(Base):
    """
    Admin user model for authentication
    """

    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="organizer")  # 'super_admin', 'organizer', 'volunteer'
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        """Convert admin object to dictionary"""
        return {
            "id": self.id,
            "username": self.username,
            "role": self.role,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


def init_database():
    """
    Initialize database and create tables
    """
    # Ensure database directory exists
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)

    # Create all tables
    Base.metadata.create_all(bind=engine)
    print(f"✓ Database initialized at: {DATABASE_PATH}")

    # Create default admin if not exists
    db = SessionLocal()
    try:
        admin_exists = db.query(Admin).filter(Admin.username == "admin").first()
        if not admin_exists:
            from passlib.hash import bcrypt

            default_admin = Admin(
                username="admin", password_hash=bcrypt.hash("mun2025admin"), role="super_admin"
            )
            db.add(default_admin)
            db.commit()
            print("✓ Default admin created (username: admin, password: mun2025admin)")
    finally:
        db.close()


def get_db():
    """
    Dependency for getting database session with retry logic
    """
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()


# Context manager for database operations with automatic retry
class DatabaseSession:
    """Context manager for database sessions with retry logic"""
    
    def __init__(self, max_retries=5):
        self.max_retries = max_retries
        self.db = None
    
    def __enter__(self):
        self.db = SessionLocal()
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if exc_type is not None:
                error_msg = str(exc_val).lower() if exc_val else ""
                if "locked" in error_msg or "busy" in error_msg:
                    self.db.rollback()
                else:
                    self.db.rollback()
            else:
                try:
                    self.db.commit()
                except Exception as e:
                    self.db.rollback()
                    raise
        finally:
            self.db.close()
        return False  # Don't suppress exceptions


if __name__ == "__main__":
    init_database()
