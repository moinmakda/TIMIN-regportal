#!/bin/bash
# Production Server Startup Script for MUN Attendance System
# Optimized for handling 100,000+ concurrent delegates

echo "=========================================="
echo "🚀 MUN Attendance System - Production Mode"
echo "=========================================="
echo ""

# Configuration
HOST="0.0.0.0"
PORT="8000"
WORKERS=4  # 4 workers for multi-core processing
TIMEOUT_KEEP_ALIVE=75
BACKLOG=10000  # Large backlog for handling burst traffic
LOG_LEVEL="info"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Activate virtual environment
echo -e "${BLUE}📦 Activating virtual environment...${NC}"
source ../venv/bin/activate

# Check if database exists and is WAL mode
echo -e "${BLUE}🗄️  Checking database configuration...${NC}"
WAL_MODE=$(sqlite3 ../database/mun_complete_system.db "PRAGMA journal_mode;" 2>/dev/null)
if [ "$WAL_MODE" = "wal" ]; then
    echo -e "${GREEN}✓ Database in WAL mode (optimal for concurrency)${NC}"
else
    echo -e "${YELLOW}⚠ Database not in WAL mode. Running initialization...${NC}"
    python3 database.py
fi

# Check Python version
echo -e "${BLUE}🐍 Python version:${NC}"
python3 --version

# Check installed packages
echo -e "${BLUE}📚 Verifying required packages...${NC}"
python3 -c "import fastapi, uvicorn, sqlalchemy, passlib" 2>/dev/null
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ All required packages installed${NC}"
else
    echo -e "${YELLOW}⚠ Some packages missing. Installing...${NC}"
    pip install -r requirements.txt
fi

# Stop any existing server
echo -e "${BLUE}🛑 Stopping any existing server...${NC}"
pkill -f "uvicorn main:app" 2>/dev/null && echo -e "${GREEN}✓ Stopped existing server${NC}" || echo -e "${YELLOW}No server was running${NC}"

# Wait a moment for ports to be freed
sleep 2

echo ""
echo "=========================================="
echo "🎯 Server Configuration:"
echo "=========================================="
echo "  Host: $HOST"
echo "  Port: $PORT"
echo "  Workers: $WORKERS (multi-process)"
echo "  Backlog: $BACKLOG connections"
echo "  Keep-Alive Timeout: ${TIMEOUT_KEEP_ALIVE}s"
echo "  WAL Mode: Enabled (concurrent reads)"
echo "  WebSocket: Enabled (real-time updates)"
echo "  Write Semaphore: 10 concurrent writes max"
echo "  Expected Capacity: 100,000+ concurrent users"
echo "=========================================="
echo ""

# Start the server
echo -e "${GREEN}🚀 Starting production server...${NC}"
echo ""

python3 -m uvicorn main:app \
    --host $HOST \
    --port $PORT \
    --workers $WORKERS \
    --timeout-keep-alive $TIMEOUT_KEEP_ALIVE \
    --backlog $BACKLOG \
    --log-level $LOG_LEVEL \
    --access-log

# Note: Removed --limit-concurrency to allow unlimited connections
# SQLite WAL mode + write semaphore handles the actual concurrency control
