"""
CSV Upload and Bulk Processing Module
"""
import csv
import io
from typing import List, Dict, Tuple
from backend.database import Delegate, SessionLocal
from backend.geolocation import (
    generate_registration_number,
    generate_qr_token,
    generate_checkin_link_token,
    assign_arrival_slot,
    validate_committee,
    validate_email,
)


class CSVProcessorResult:
    """Result object for CSV processing"""

    def __init__(self):
        self.success = False
        self.delegates_processed = 0
        self.delegates_data = []
        self.errors = []
        self.warnings = []


def validate_csv_structure(csv_content: str) -> Tuple[bool, List[str]]:
    """
    Validate CSV file structure and required columns

    Args:
        csv_content: CSV file content as string

    Returns:
        Tuple (is_valid: bool, errors: List[str])
    """
    errors = []
    required_columns = ["name", "email", "committee"]

    try:
        csv_file = io.StringIO(csv_content)
        reader = csv.DictReader(csv_file)

        # Check if required columns exist
        if not reader.fieldnames:
            errors.append("CSV file is empty or invalid")
            return False, errors

        headers = [h.strip().lower() for h in reader.fieldnames]

        for col in required_columns:
            if col not in headers:
                errors.append(f"Missing required column: {col}")

        if errors:
            return False, errors

        return True, []

    except Exception as e:
        errors.append(f"Failed to parse CSV: {str(e)}")
        return False, errors


def validate_csv_data(csv_content: str) -> CSVProcessorResult:
    """
    Validate CSV data and check for issues

    Args:
        csv_content: CSV file content as string

    Returns:
        CSVProcessorResult object with validation results
    """
    result = CSVProcessorResult()

    # First check structure
    is_valid, errors = validate_csv_structure(csv_content)
    if not is_valid:
        result.errors.extend(errors)
        return result

    csv_file = io.StringIO(csv_content)
    reader = csv.DictReader(csv_file)

    # Normalize headers
    headers = [h.strip().lower() for h in reader.fieldnames]

    row_num = 1
    emails_seen = set()
    db = SessionLocal()

    try:
        for row in reader:
            row_num += 1

            # Normalize row keys
            normalized_row = {k.strip().lower(): v.strip() if v else "" for k, v in row.items()}

            name = normalized_row.get("name", "")
            email = normalized_row.get("email", "")
            committee = normalized_row.get("committee", "")

            # Validate name
            if not name:
                result.errors.append(f"Row {row_num}: Name is required")
                continue

            # Validate email
            if not email:
                result.errors.append(f"Row {row_num}: Email is required for {name}")
                continue

            if not validate_email(email):
                result.errors.append(f"Row {row_num}: Invalid email format for {name}: {email}")
                continue

            # Check for duplicate emails in CSV
            if email.lower() in emails_seen:
                result.errors.append(f"Row {row_num}: Duplicate email in CSV: {email}")
                continue

            # Check if email already exists in database
            existing = db.query(Delegate).filter(Delegate.email == email).first()
            if existing:
                result.warnings.append(f"Row {row_num}: Email already exists in system: {email}")
                continue

            emails_seen.add(email.lower())

            # Validate committee
            if not committee:
                result.errors.append(f"Row {row_num}: Committee is required for {name}")
                continue

            if not validate_committee(committee):
                result.errors.append(
                    f"Row {row_num}: Invalid committee '{committee}' for {name}. "
                    f"Allowed: UNSC, UNGA, UNHRC, DISEC, ECOSOC, OTHER"
                )
                continue

            # Add to valid delegates
            result.delegates_data.append(
                {
                    "name": name,
                    "email": email,
                    "committee": committee.upper(),
                    "country": normalized_row.get("country", ""),
                    "school": normalized_row.get("school", ""),
                }
            )

        result.delegates_processed = len(result.delegates_data)

        if result.delegates_processed > 0 and not result.errors:
            result.success = True

        return result

    finally:
        db.close()


def process_and_generate_delegates(
    csv_content: str, auto_payment_confirm: bool = False
) -> CSVProcessorResult:
    """
    Process CSV and create delegate records with generated tokens

    Args:
        csv_content: CSV file content as string
        auto_payment_confirm: Whether to automatically confirm payment status

    Returns:
        CSVProcessorResult object with processing results
    """
    # First validate the data
    result = validate_csv_data(csv_content)

    if not result.success:
        return result

    db = SessionLocal()
    created_delegates = []

    try:
        for delegate_data in result.delegates_data:
            # Generate unique identifiers
            reg_number = generate_registration_number()
            qr_token = generate_qr_token()
            checkin_token = generate_checkin_link_token()
            arrival_slot = assign_arrival_slot(delegate_data["committee"])

            # Ensure unique registration numbers (very unlikely collision, but check anyway)
            while db.query(Delegate).filter(Delegate.registration_number == reg_number).first():
                reg_number = generate_registration_number()

            # Create delegate record
            delegate = Delegate(
                name=delegate_data["name"],
                email=delegate_data["email"],
                committee=delegate_data["committee"],
                country=delegate_data.get("country"),
                school=delegate_data.get("school"),
                registration_number=reg_number,
                qr_code_token=qr_token,
                unique_checkin_link=checkin_token,
                arrival_slot=arrival_slot,
                payment_status=auto_payment_confirm,
            )

            db.add(delegate)
            created_delegates.append(delegate)

        # Commit all at once
        db.commit()

        # Refresh to get IDs
        for delegate in created_delegates:
            db.refresh(delegate)

        result.success = True
        result.delegates_processed = len(created_delegates)
        result.delegates_data = [d.to_dict() for d in created_delegates]

        return result

    except Exception as e:
        db.rollback()
        result.success = False
        result.errors.append(f"Database error: {str(e)}")
        return result

    finally:
        db.close()


def get_preview_data(csv_content: str, max_rows: int = 200) -> List[Dict]:
    """
    Get preview of CSV data for display

    Args:
        csv_content: CSV file content as string
        max_rows: Maximum number of rows to return

    Returns:
        List of dictionaries with preview data
    """
    preview_data = []

    try:
        csv_file = io.StringIO(csv_content)
        reader = csv.DictReader(csv_file)

        for i, row in enumerate(reader):
            if i >= max_rows:
                break

            normalized_row = {k.strip().lower(): v.strip() if v else "" for k, v in row.items()}
            preview_data.append(
                {
                    "name": normalized_row.get("name", ""),
                    "email": normalized_row.get("email", ""),
                    "committee": normalized_row.get("committee", "").upper(),
                    "country": normalized_row.get("country", ""),
                    "school": normalized_row.get("school", ""),
                }
            )

        return preview_data

    except Exception as e:
        return []


if __name__ == "__main__":
    # Test CSV processing
    test_csv = """name,email,committee,country
John Doe,john@email.com,UNSC,USA
Jane Smith,jane@email.com,UNGA,UK
Alex Kumar,alex@email.com,UNHRC,India
"""

    print("Testing CSV Processor:")
    print("=" * 50)

    result = validate_csv_data(test_csv)
    print(f"Validation Success: {result.success}")
    print(f"Delegates Found: {result.delegates_processed}")
    print(f"Errors: {len(result.errors)}")
    print(f"Warnings: {len(result.warnings)}")

    if result.errors:
        print("\nErrors:")
        for error in result.errors:
            print(f"  - {error}")

    if result.warnings:
        print("\nWarnings:")
        for warning in result.warnings:
            print(f"  - {warning}")
