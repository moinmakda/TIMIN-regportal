#!/usr/bin/env python3
"""
Register Moin Makda and send personalized check-in link via email
"""

import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import json

# API Base URL
BASE_URL = "http://localhost:8000"

# Delegate Information
delegate_data = {
    "name": "Moin Makda",
    "email": "moinmakda1@gmail.com",
    "phone": "+91-9876543210",  # Add a phone number
    "institution": "TIMUN Conference",
    "committee": "UNGA",
    "portfolio": "INDIA"
}

def register_delegate():
    """Register the delegate via API"""
    print("🔄 Registering delegate...")
    
    response = requests.post(
        f"{BASE_URL}/api/register-single",
        json=delegate_data,
        headers={"Content-Type": "application/json"}
    )
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ Registration successful!")
        print(f"📋 Registration Number: {result['registration_number']}")
        return result
    else:
        print(f"❌ Registration failed: {response.text}")
        return None

def generate_qr_code(reg_number):
    """Generate QR code for the delegate"""
    print(f"\n🔄 Generating QR code for {reg_number}...")
    
    response = requests.get(f"{BASE_URL}/api/generate-qr/{reg_number}")
    
    if response.status_code == 200:
        result = response.json()
        print(f"✅ QR code generated!")
        return result
    else:
        print(f"❌ QR generation failed: {response.text}")
        return None

def send_email(delegate_info, qr_info):
    """Send personalized check-in link via email"""
    
    reg_number = delegate_info['registration_number']
    name = delegate_info['name']
    committee = delegate_info['committee']
    portfolio = delegate_info['portfolio']
    email = delegate_info['email']
    
    # Personalized check-in link
    checkin_link = f"http://localhost:8000/checkin/{reg_number}"
    
    # Create email content
    subject = f"TIMUN 2025 - Your Personalized Check-in Link | {committee} - {portfolio}"
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
            .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
            .button {{ display: inline-block; background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }}
            .info-box {{ background: white; padding: 20px; border-left: 4px solid #667eea; margin: 20px 0; }}
            .qr-section {{ text-align: center; margin: 30px 0; padding: 20px; background: white; border-radius: 10px; }}
            .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🌍 Welcome to TIMUN 2025!</h1>
            </div>
            <div class="content">
                <h2>Dear {name},</h2>
                
                <p>Congratulations on your registration for <strong>TIMUN 2025</strong>!</p>
                
                <div class="info-box">
                    <h3>📋 Your Delegate Information</h3>
                    <p><strong>Registration Number:</strong> {reg_number}</p>
                    <p><strong>Committee:</strong> {committee}</p>
                    <p><strong>Portfolio:</strong> {portfolio}</p>
                    <p><strong>Email:</strong> {email}</p>
                </div>
                
                <h3>✅ Check-in Instructions</h3>
                <p>Click the button below to mark your attendance when you arrive at the venue:</p>
                
                <center>
                    <a href="{checkin_link}" class="button">
                        📍 CHECK IN NOW
                    </a>
                </center>
                
                <p style="font-size: 14px; color: #666;">
                    Or copy this link: <br>
                    <code style="background: #e0e0e0; padding: 5px 10px; border-radius: 3px;">{checkin_link}</code>
                </p>
                
                <div class="qr-section">
                    <h3>📱 Your QR Code</h3>
                    <p>You can also use this QR code for quick check-in:</p>
                    <p><strong>Registration Number:</strong> {reg_number}</p>
                    <p style="font-size: 12px; color: #666;">Show this at the registration desk</p>
                </div>
                
                <h3>🎯 What happens when you check in?</h3>
                <ul>
                    <li>Your attendance will be marked instantly</li>
                    <li>You'll see confirmation on your screen</li>
                    <li>Admin dashboard will update in real-time</li>
                    <li>You can collect your delegate kit</li>
                </ul>
                
                <div class="info-box">
                    <h3>ℹ️ Important Notes</h3>
                    <ul>
                        <li>Keep this email safe - you'll need the link to check in</li>
                        <li>Check-in opens 1 hour before the conference</li>
                        <li>Collect your delegate kit after checking in</li>
                        <li>Contact the organizing team if you face any issues</li>
                    </ul>
                </div>
                
                <p>We look forward to seeing you at <strong>TIMUN 2025</strong>!</p>
                
                <p>Best regards,<br>
                <strong>TIMUN Organizing Committee</strong></p>
            </div>
            
            <div class="footer">
                <p>This is an automated email from the MUN Attendance System</p>
                <p>Powered by FastAPI + SQLite + WebSocket | Version 2.0.0</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Plain text version
    text_content = f"""
    Welcome to TIMUN 2025!
    
    Dear {name},
    
    Congratulations on your registration!
    
    YOUR DELEGATE INFORMATION:
    - Registration Number: {reg_number}
    - Committee: {committee}
    - Portfolio: {portfolio}
    - Email: {email}
    
    CHECK-IN LINK:
    {checkin_link}
    
    Click the link above when you arrive at the venue to mark your attendance.
    
    The system will:
    - Mark your attendance instantly
    - Show confirmation on your screen
    - Update the admin dashboard in real-time
    - Allow you to collect your delegate kit
    
    Best regards,
    TIMUN Organizing Committee
    """
    
    print(f"\n" + "="*70)
    print("📧 EMAIL CONTENT PREVIEW")
    print("="*70)
    print(f"To: {email}")
    print(f"Subject: {subject}")
    print("="*70)
    print(text_content)
    print("="*70)
    
    # For demonstration, we'll save the email to a file
    # In production, you would use an actual SMTP server
    
    email_file = "delegate_email_moin.html"
    with open(email_file, 'w') as f:
        f.write(html_content)
    
    print(f"\n✅ Email content saved to: {email_file}")
    print(f"📧 In production, this would be sent to: {email}")
    
    return checkin_link

def main():
    print("\n" + "="*70)
    print("🎯 TIMUN 2025 - Delegate Registration & Email System")
    print("="*70)
    
    # Step 1: Register delegate
    result = register_delegate()
    if not result:
        print("❌ Failed to register delegate. Exiting...")
        return
    
    # Step 2: Generate QR code
    qr_result = generate_qr_code(result['registration_number'])
    
    # Step 3: Send email
    checkin_link = send_email(result, qr_result)
    
    # Step 4: Show admin portal information
    print("\n" + "="*70)
    print("🔐 ADMIN PORTAL ACCESS INFORMATION")
    print("="*70)
    print(f"\n📊 ADMIN DASHBOARD:")
    print(f"   URL: http://localhost:8000/admin")
    print(f"   Description: Real-time dashboard showing all delegates and statistics")
    
    print(f"\n📈 STATISTICS ENDPOINT:")
    print(f"   URL: http://localhost:8000/api/stats")
    print(f"   Description: JSON endpoint with real-time statistics")
    
    print(f"\n👥 ALL DELEGATES:")
    print(f"   URL: http://localhost:8000/api/delegates")
    print(f"   Description: List of all registered delegates")
    
    print(f"\n🔍 SPECIFIC DELEGATE:")
    print(f"   URL: http://localhost:8000/api/delegates/{result['registration_number']}")
    print(f"   Description: View Moin's details")
    
    print(f"\n📥 DOWNLOAD CSV EXPORTS:")
    print(f"   All Delegates: http://localhost:8000/api/export/delegates")
    print(f"   Attendance: http://localhost:8000/api/export/attendance")
    print(f"   Kit Status: http://localhost:8000/api/export/kits")
    
    print(f"\n🔌 WEBSOCKET FOR REAL-TIME UPDATES:")
    print(f"   Admin WebSocket: ws://localhost:8000/ws/admin")
    print(f"   Delegate WebSocket: ws://localhost:8000/ws/delegate/{result['registration_number']}")
    print(f"   Stats WebSocket: ws://localhost:8000/ws/stats")
    
    print(f"\n✅ MOIN'S PERSONALIZED CHECK-IN LINK:")
    print(f"   {checkin_link}")
    print(f"\n💡 When Moin clicks this link:")
    print(f"   1. His attendance will be marked")
    print(f"   2. Geolocation will be captured (if permitted)")
    print(f"   3. Admin dashboard will update in real-time")
    print(f"   4. He'll see confirmation on his screen")
    
    print("\n" + "="*70)
    print("✨ Registration and email preparation complete!")
    print("="*70)

if __name__ == "__main__":
    main()
