#!/usr/bin/env python3
"""
Pre-flight check before running 100K stress test
"""

import requests
import sqlite3
import sys

def check_server():
    """Check if server is running"""
    print("🔍 Checking server status...")
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        if response.status_code == 200:
            print("  ✅ Server is running")
            return True
        else:
            print(f"  ❌ Server returned status {response.status_code}")
            return False
    except Exception as e:
        print(f"  ❌ Server is not accessible: {e}")
        return False

def check_database():
    """Check database status"""
    print("\n📊 Checking database...")
    try:
        conn = sqlite3.connect("database/mun_complete_system.db")
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM delegates")
        total = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM delegates WHERE attendance_marked = 1")
        checked_in = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT committee) FROM delegates")
        committees = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"  ✅ Total delegates: {total:,}")
        print(f"  ✅ Already checked in: {checked_in:,}")
        print(f"  ✅ Committees: {committees}")
        
        if total < 100000:
            print(f"  ⚠️  WARNING: Expected 100,000+ delegates, found {total:,}")
            return False
        
        return True
        
    except Exception as e:
        print(f"  ❌ Database error: {e}")
        return False

def check_system_resources():
    """Check system can handle the load"""
    print("\n💻 Checking system resources...")
    try:
        import psutil
        
        cpu_count = psutil.cpu_count()
        memory = psutil.virtual_memory()
        
        print(f"  ✅ CPU cores: {cpu_count}")
        print(f"  ✅ Available RAM: {memory.available / (1024**3):.2f} GB / {memory.total / (1024**3):.2f} GB")
        print(f"  ✅ RAM usage: {memory.percent}%")
        
        if memory.percent > 90:
            print("  ⚠️  WARNING: RAM usage is high")
        
        return True
        
    except ImportError:
        print("  ⚠️  psutil not installed, skipping resource check")
        return True

def main():
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("🚀 PRE-FLIGHT CHECK FOR 100K STRESS TEST")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    checks = [
        check_server(),
        check_database(),
        check_system_resources()
    ]
    
    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    if all(checks):
        print("✅ ALL CHECKS PASSED!")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("\n🎯 System is ready for 100,000 concurrent check-ins!")
        print("\n📝 Recommendations:")
        print("  1. Open admin dashboard: http://localhost:8000/admin")
        print("  2. Monitor server logs in a separate terminal")
        print("  3. Ensure no other heavy processes are running")
        print("\n🔥 Ready to launch stress test!")
        return 0
    else:
        print("❌ SOME CHECKS FAILED!")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("\n⚠️  Please fix the issues above before running the stress test")
        return 1

if __name__ == "__main__":
    sys.exit(main())
