#!/usr/bin/env python3
"""
Test concurrent check-ins with the new 1000 delegate database
"""

import asyncio
import aiohttp
import time
from datetime import datetime

# Campus coordinates (within 500m radius)
CAMPUS_LAT = 28.658500
CAMPUS_LON = 77.212700

async def checkin_delegate(session, reg_number, index):
    """Simulate a single check-in"""
    url = f"http://localhost:8000/api/geolocation-checkin"
    
    # Slightly vary coordinates to simulate different positions on campus
    lat = CAMPUS_LAT + (index % 10) * 0.0001  # ~11m variations
    lon = CAMPUS_LON + (index % 10) * 0.0001
    
    payload = {
        "registration_number": reg_number,
        "latitude": lat,
        "longitude": lon
    }
    
    try:
        async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as response:
            data = await response.json()
            return {
                "reg_number": reg_number,
                "success": data.get("success", False),
                "status_code": response.status,
                "response": data
            }
    except Exception as e:
        return {
            "reg_number": reg_number,
            "success": False,
            "error": str(e)
        }

async def test_concurrent_checkins(num_requests=100):
    """Test concurrent check-ins"""
    print(f"🧪 Testing {num_requests} concurrent check-ins...")
    print(f"📍 Campus location: {CAMPUS_LAT}, {CAMPUS_LON}")
    print(f"⏰ Started at: {datetime.now().strftime('%H:%M:%S')}\n")
    
    # Get registration numbers
    reg_numbers = [f"TIMUN{400286 + i:06d}" for i in range(num_requests)]
    
    start_time = time.time()
    
    async with aiohttp.ClientSession() as session:
        tasks = [checkin_delegate(session, reg_num, i) for i, reg_num in enumerate(reg_numbers)]
        results = await asyncio.gather(*tasks)
    
    elapsed = time.time() - start_time
    
    # Analyze results
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    
    print(f"✅ Results:")
    print(f"  • Total requests: {len(results)}")
    print(f"  • Successful: {successful} ({successful/len(results)*100:.1f}%)")
    print(f"  • Failed: {failed} ({failed/len(results)*100:.1f}%)")
    print(f"  • Time taken: {elapsed:.2f} seconds")
    print(f"  • Rate: {len(results)/elapsed:.1f} requests/second\n")
    
    # Show sample responses
    print("📋 Sample responses:")
    for i, result in enumerate(results[:3]):
        status = "✅" if result.get("success") else "❌"
        print(f"  {status} {result['reg_number']}: {result.get('response', result.get('error'))}")
    
    # Show errors if any
    errors = [r for r in results if not r.get("success")]
    if errors and len(errors) <= 10:
        print(f"\n❌ Failed check-ins:")
        for error in errors[:10]:
            print(f"  • {error['reg_number']}: {error.get('response', error.get('error'))}")
    
    return successful, failed, elapsed

if __name__ == "__main__":
    print("=" * 60)
    print("🎯 TIMUN Attendance System - Concurrent Check-in Test")
    print("=" * 60 + "\n")
    
    # Test with 100 concurrent requests
    asyncio.run(test_concurrent_checkins(100))
    
    print("\n" + "=" * 60)
    print("✨ Test complete!")
    print("=" * 60)
