# MUN Attendance System - Complete Build Plan

## 🎯 Project Overview

**Starting Point:** CSV file with delegate data (Name, Email, Committee)  
**Campus Location:** 28.658500, 77.212700 (500m geofence radius)  
**Goal:** Zero-queue automated attendance system with multiple check-in methods

---

## 📋 Phase 2: Detailed Build Plan

### **STEP 1: CSV Upload & Bulk Processing**

#### What We're Building:
Admin uploads CSV → System processes all delegates → Generates unique links → Sends emails

#### Database Schema:
```
delegates table:
├─ id (primary key)
├─ name (string, required)
├─ email (string, unique, required)
├─ committee (string, required) [UNSC, UNGA, UNHRC, DISEC, ECOSOC]
├─ country (string, optional) - can be added later
├─ school (string, optional)
├─ registration_number (unique) - MUN2025XXXXXXXX
├─ qr_code_token (unique) - for QR backup
├─ unique_checkin_link (unique) - for geolocation
├─ arrival_slot (string) - auto-assigned based on committee
├─ payment_status (boolean, default: false)
├─ pre_checkin_done (boolean, default: false)
├─ pre_checkin_time (datetime, nullable)
├─ attendance_marked (boolean, default: false)
├─ attendance_time (datetime, nullable)
├─ attendance_method (string) - 'geolocation', 'qr_scan', 'manual'
├─ checkin_latitude (float, nullable)
├─ checkin_longitude (float, nullable)
├─ kit_collected (boolean, default: false)
├─ kit_collection_time (datetime, nullable)
├─ created_at (datetime)
├─ updated_at (datetime)
```

#### CSV Processing Flow:
```
1. Admin logs into dashboard
2. Goes to "Bulk Upload" section
3. Uploads CSV file (name, email, committee)
4. System validates:
   ✓ Required columns present
   ✓ Email format valid
   ✓ Committee names match allowed list
   ✓ No duplicate emails
5. Shows preview of 200 delegates
6. Admin clicks "Process & Generate Links"
7. System runs batch process:
   For each delegate:
   ├─ Generate registration_number
   ├─ Generate qr_code_token
   ├─ Generate unique_checkin_link (48 char token)
   ├─ Assign arrival_slot based on committee
   └─ Insert into database
8. System generates email queue
9. Shows confirmation: "200 delegates processed"
```

#### Time Slot Assignment Logic:
```
UNSC → 09:00-09:15
UNGA → 09:15-09:30
UNHRC → 09:30-09:45
DISEC → 09:45-10:00
ECOSOC → 10:00-10:15
Others → 10:15-10:30
```

---

### **STEP 2: Email Generation System**

#### What We're Building:
Automated email sender with QR code + unique link for each delegate

#### Email Template Structure:
```html
Subject: MUN 2025 - Your Check-in Credentials

Body:
┌─────────────────────────────────────────┐
│ MUN 2025 - Registration Confirmed       │
├─────────────────────────────────────────┤
│ Dear [NAME],                            │
│                                         │
│ Registration Number: MUN2025XXXX        │
│ Committee: [COMMITTEE]                  │
│ Arrival Slot: [TIME SLOT]              │
│                                         │
│ ─────────────────────────────────────   │
│                                         │
│ EVENT DAY CHECK-IN OPTIONS:             │
│                                         │
│ 1. SMART CHECK-IN (Recommended)         │
│    Click this link on your phone:       │
│    [BUTTON: Check-in Here]              │
│    https://mun.com/checkin/[TOKEN]      │
│                                         │
│ 2. QR CODE (Backup)                     │
│    [QR CODE IMAGE EMBEDDED]             │
│    Show this at registration desk       │
│                                         │
│ ─────────────────────────────────────   │
│                                         │
│ Instructions:                           │
│ • Arrive during your time slot          │
│ • Click the link when on campus         │
│ • Allow location access                 │
│ • Attendance will be marked instantly   │
│                                         │
│ Location: [Campus Address]              │
│ Date: [Event Date]                      │
│                                         │
└─────────────────────────────────────────┘
```

#### Email Sending Flow:
```
1. System picks batch of 50 emails from queue
2. For each delegate:
   ├─ Generate QR code image with data:
   │  {
   │    "qr_code": "token_xyz",
   │    "name": "John Doe",
   │    "committee": "UNSC",
   │    "registration_number": "MUN2025XXXX"
   │  }
   ├─ Embed QR as image
   ├─ Insert unique link in button
   ├─ Send via SMTP
   └─ Mark as email_sent in database
3. Show progress in admin dashboard
4. Handle failures and retry
```

---

### **STEP 3: Geolocation Check-in Page**

#### What We're Building:
Web page that opens when delegate clicks unique link

#### URL Structure:
```
https://yourdomain.com/checkin/[48-char-unique-token]
```

#### Page Flow:
```
Delegate clicks link
    ↓
Browser opens page
    ↓
Page shows:
┌─────────────────────────────────────┐
│ MUN 2025 Check-in                   │
├─────────────────────────────────────┤
│ Welcome, John Doe!                  │
│                                     │
│ Committee: UNSC                     │
│ Arrival Slot: 09:00-09:15          │
│                                     │
│ [Button: Mark My Attendance]        │
│                                     │
│ Status: Not checked in              │
└─────────────────────────────────────┘
    ↓
Delegate clicks button
    ↓
JavaScript executes:
1. Request location permission
2. Get GPS coordinates (lat, lon)
3. Send to backend API:
   POST /api/geolocation-checkin
   {
     "unique_link": "token",
     "latitude": 28.658234,
     "longitude": 77.212890
   }
    ↓
Backend validates:
├─ Check token exists in database
├─ Calculate distance from campus center
│  Campus: 28.658500, 77.212700
│  Delegate: 28.658234, 77.212890
│  Distance = Haversine formula = 145m
├─ Is distance <= 500m? YES
└─ Mark attendance
    ↓
Response to page:
{
  "success": true,
  "message": "Welcome, John Doe!",
  "delegate": {...},
  "next_step": "Proceed to Kit Collection Desk"
}
    ↓
Page updates:
┌─────────────────────────────────────┐
│ ✓ Attendance Marked!                │
├─────────────────────────────────────┤
│ Welcome, John Doe!                  │
│                                     │
│ Check-in Time: 09:03:45 AM         │
│ Method: Geolocation                 │
│                                     │
│ Next Step:                          │
│ → Go to Kit Collection Desk         │
│ → Show this screen to collect kit   │
│                                     │
│ Your Lane: [Based on name]         │
│ A-F / G-M / N-S / T-Z              │
└─────────────────────────────────────┘
```

#### If Outside Campus:
```
Distance = 850m (outside 500m radius)
    ↓
Response:
{
  "success": false,
  "inside_campus": false,
  "distance_meters": 850,
  "message": "Please come to campus"
}
    ↓
Page shows:
┌─────────────────────────────────────┐
│ ✗ Not on Campus                     │
├─────────────────────────────────────┤
│ You are 850m away from campus       │
│                                     │
│ Please walk to campus and try again │
│                                     │
│ [Button: Retry]                     │
│                                     │
│ Backup: Show QR code at desk        │
└─────────────────────────────────────┘
```

---

### **STEP 4: Admin Dashboard - Complete Features**

#### What We're Building:
Comprehensive control panel for organizers

#### Dashboard Sections:

**A. Overview Section**
```
┌─────────────────────────────────────────────┐
│ LIVE STATISTICS                              │
├─────────────────────────────────────────────┤
│ [200] Total Registered                       │
│ [185] Attendance Marked (92.5%)             │
│ [165] Kits Collected (82.5%)                │
│                                             │
│ Check-in Methods:                           │
│ [150] Geolocation (81%)                     │
│ [30]  QR Scan (16%)                         │
│ [5]   Manual (3%)                           │
│                                             │
│ [Refresh] [Export All Data]                 │
└─────────────────────────────────────────────┘
```

**B. Bulk Upload Section**
```
┌─────────────────────────────────────────────┐
│ BULK DELEGATE UPLOAD                         │
├─────────────────────────────────────────────┤
│ Upload CSV file with columns:                │
│ • name (required)                            │
│ • email (required)                           │
│ • committee (required)                       │
│                                             │
│ [Choose File] delegates.csv                  │
│ [Upload & Process]                           │
│                                             │
│ Status: Ready to upload                      │
└─────────────────────────────────────────────┘

After upload:
┌─────────────────────────────────────────────┐
│ PREVIEW: 200 delegates loaded                │
├─────────────────────────────────────────────┤
│ Name          | Email           | Committee  │
│ John Doe      | john@email.com  | UNSC      │
│ Jane Smith    | jane@email.com  | UNGA      │
│ ...                                          │
│                                             │
│ [Generate Links & Send Emails]               │
│ [Cancel]                                     │
└─────────────────────────────────────────────┘

After processing:
┌─────────────────────────────────────────────┐
│ ✓ Processing Complete                        │
├─────────────────────────────────────────────┤
│ • 200 delegates added to system              │
│ • 200 unique links generated                 │
│ • 200 QR codes created                       │
│ • 200 emails queued for sending              │
│                                             │
│ Email Sending Progress: 150/200 sent         │
└─────────────────────────────────────────────┘
```

**C. Delegate Management Section**
```
┌─────────────────────────────────────────────┐
│ DELEGATE LIST                                │
├─────────────────────────────────────────────┤
│ Filters:                                     │
│ [Committee: All ▼] [Status: All ▼]          │
│ [Search: _____________]                      │
│                                             │
│ Table:                                       │
│ Name | Committee | Attendance | Kit | Actions│
│ John | UNSC     | ✓ 09:03   | ✓   | [View] │
│ Jane | UNGA     | ✗ Absent  | ✗   | [Mark] │
│ Alex | UNHRC    | ✓ 09:15   | ✗   | [View] │
│                                             │
│ [Export Filtered Results]                    │
└─────────────────────────────────────────────┘
```

**D. Manual Check-in Section**
```
┌─────────────────────────────────────────────┐
│ MANUAL ATTENDANCE ENTRY                      │
├─────────────────────────────────────────────┤
│ For delegates without phone/internet         │
│                                             │
│ Search Delegate:                             │
│ [Name or Registration Number: ________]      │
│ [Search]                                     │
│                                             │
│ Results:                                     │
│ ┌─────────────────────────────────────────┐ │
│ │ John Doe                                │ │
│ │ UNSC - United States                    │ │
│ │ Registration: MUN2025XXXX               │ │
│ │                                         │ │
│ │ Current Status: Not checked in          │ │
│ │                                         │ │
│ │ [Mark Attendance Now]                   │ │
│ └─────────────────────────────────────────┘ │
└─────────────────────────────────────────────┘

After marking:
┌─────────────────────────────────────────────┐
│ ✓ Attendance Marked Manually                 │
├─────────────────────────────────────────────┤
│ Delegate: John Doe                           │
│ Time: 09:15:30 AM                           │
│ Method: Manual Entry                         │
│ Marked by: Admin                             │
└─────────────────────────────────────────────┘
```

**E. QR Scanner Section**
```
┌─────────────────────────────────────────────┐
│ QR CODE SCANNER                              │
├─────────────────────────────────────────────┤
│ Paste QR code data or scan:                  │
│                                             │
│ [____________QR_Data____________]            │
│ [Scan & Mark Attendance]                     │
│                                             │
│ OR                                           │
│                                             │
│ [Enable Camera Scan]                         │
│ (Requires HTTPS)                             │
│                                             │
│ Recent Scans:                                │
│ • John Doe - 09:03 ✓                        │
│ • Jane Smith - 09:05 ✓                      │
└─────────────────────────────────────────────┘
```

**F. Kit Distribution Section**
```
┌─────────────────────────────────────────────┐
│ KIT COLLECTION TRACKING                      │
├─────────────────────────────────────────────┤
│ Search by name or registration:              │
│ [Search: _____________]                      │
│                                             │
│ Result:                                      │
│ ┌─────────────────────────────────────────┐ │
│ │ John Doe - UNSC                         │ │
│ │ Attendance: ✓ Marked at 09:03           │ │
│ │ Kit Status: Not collected                │ │
│ │                                         │ │
│ │ [Mark Kit Collected]                    │ │
│ └─────────────────────────────────────────┘ │
│                                             │
│ Pending Kits: 35                             │
│ Collected Kits: 165                          │
└─────────────────────────────────────────────┘
```

**G. Committee Reports Section**
```
┌─────────────────────────────────────────────┐
│ EXECUTIVE BOARD REPORTS                      │
├─────────────────────────────────────────────┤
│ Generate attendance sheets for EB:           │
│                                             │
│ [Committee: UNSC ▼]                         │
│ [Generate Report]                            │
│ [Download PDF] [Download Excel]              │
│                                             │
│ Preview:                                     │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━    │
│ UNITED NATIONS SECURITY COUNCIL              │
│ Attendance Report - [Date]                   │
│                                             │
│ Total Delegates: 35                          │
│ Present: 32                                  │
│ Absent: 3                                    │
│ Attendance Rate: 91.4%                       │
│                                             │
│ DELEGATE LIST:                               │
│ Name          | Country    | Status | Time  │
│ John Doe      | USA        | ✓      | 09:03 │
│ Jane Smith    | UK         | ✓      | 09:05 │
│ Alex Kumar    | India      | ✗      | -     │
│ ...                                          │
│                                             │
│ Generated at: 09:30 AM                       │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━    │
│                                             │
│ [Print Report]                               │
└─────────────────────────────────────────────┘
```

**H. Download Center**
```
┌─────────────────────────────────────────────┐
│ EXPORT & DOWNLOADS                           │
├─────────────────────────────────────────────┤
│ Available Downloads:                         │
│                                             │
│ 1. Complete Delegate List                    │
│    [Download CSV] [Download Excel]           │
│                                             │
│ 2. Attendance Report (Present only)          │
│    [Download CSV] [Download Excel]           │
│                                             │
│ 3. Absent Delegates List                     │
│    [Download CSV] [Download Excel]           │
│                                             │
│ 4. Kit Distribution Report                   │
│    [Download CSV] [Download Excel]           │
│                                             │
│ 5. Committee-wise Summary                    │
│    [Download PDF]                            │
│                                             │
│ 6. Check-in Timeline Data                    │
│    [Download CSV] (for analysis)             │
│                                             │
│ 7. All Delegate QR Codes (Batch)            │
│    [Download ZIP] (200 images)               │
└─────────────────────────────────────────────┘
```

**I. Real-time Committee Dashboard**
```
┌─────────────────────────────────────────────┐
│ COMMITTEE-WISE LIVE STATUS                   │
├─────────────────────────────────────────────┤
│ UNSC                                         │
│ [████████████████░░░░] 32/35 (91.4%)        │
│ Kits: 30/32                                  │
│ [View Details] [Generate EB Report]          │
│                                             │
│ UNGA                                         │
│ [███████████████████░] 45/50 (90%)          │
│ Kits: 43/45                                  │
│ [View Details] [Generate EB Report]          │
│                                             │
│ UNHRC                                        │
│ [██████████████████░░] 28/30 (93.3%)        │
│ Kits: 27/28                                  │
│ [View Details] [Generate EB Report]          │
│                                             │
│ ... (other committees)                       │
└─────────────────────────────────────────────┘
```

---

### **STEP 5: QR Code System (Backup Method)**

#### What We're Building:
QR code scanning for delegates without smartphones or location issues

#### QR Code Data Format:
```json
{
  "qr_code": "unique_token_xyz123",
  "name": "John Doe",
  "committee": "UNSC",
  "registration_number": "MUN2025XXXX",
  "timestamp": "2025-11-03T08:30:00"
}
```

#### Scanner Interface Flow:
```
Volunteer opens Scanner Station page
    ↓
Two input options:
1. Paste QR data (for keyboard entry)
2. Camera scan (if HTTPS enabled)
    ↓
Delegate shows QR code
    ↓
Volunteer scans/pastes
    ↓
System calls API:
POST /api/mark-attendance-qr
{
  "qr_code": "token",
  "station_id": "Station A"
}
    ↓
Backend validates:
├─ Token exists?
├─ Already marked?
├─ Payment confirmed?
└─ Mark attendance
    ↓
Response shows:
┌─────────────────────────────────────┐
│ ✓ Success!                          │
├─────────────────────────────────────┤
│ John Doe                            │
│ UNSC - United States                │
│                                     │
│ Attendance marked at 09:15          │
│                                     │
│ → Direct to Kit Collection Desk     │
│    Lane: A-F                        │
└─────────────────────────────────────┘
```

---

### **STEP 6: Three Check-in Methods - Complete Logic**

#### Method 1: Geolocation (Primary - 80%)
```
Flow: Email Link → Browser → Location Permission → GPS Check → Auto Mark
Time: 10 seconds
Requirements: Smartphone, Location enabled, Internet
Success Rate: High (if on campus)
Advantages: Zero volunteer interaction, instant
```

#### Method 2: QR Code Scan (Backup - 15%)
```
Flow: Show QR → Volunteer Scans → Manual Verify → Mark
Time: 30 seconds
Requirements: QR code (printed or on phone), Volunteer with scanner
Success Rate: 100%
Advantages: Reliable backup, works without internet
```

#### Method 3: Manual Entry (Last Resort - 5%)
```
Flow: Tell Name/Reg Number → Volunteer Searches → Verify → Mark
Time: 30 seconds
Requirements: Volunteer with admin access
Success Rate: 100%
Advantages: Works in all scenarios
Use Cases: Forgot phone, battery dead, technical issues
```

---

### **STEP 7: Kit Distribution Workflow**

#### Layout:
```
ENTRANCE
    ↓
[Express Desk] ← Only for QR/Manual (20%)
    ↓
[Kit Collection Zone] ← All delegates come here
    ├─ Lane A-F (2 volunteers)
    ├─ Lane G-M (2 volunteers)
    ├─ Lane N-S (2 volunteers)
    └─ Lane T-Z (2 volunteers)
    ↓
EVENT HALL
```

#### Kit Desk Volunteer Process:
```
1. Delegate arrives at correct lane (by first name)
2. Volunteer asks: "Name?"
3. Delegate: "John Doe"
4. Volunteer:
   ├─ Opens admin dashboard on tablet
   ├─ Searches "John Doe"
   ├─ Sees: ✓ Attendance marked at 09:03 (Geolocation)
   ├─ Verifies face matches (optional)
   └─ Clicks "Mark Kit Collected"
5. System updates database
6. Volunteer hands over:
   ├─ Name tag with lanyard
   ├─ Country placard
   ├─ MUN folder
   ├─ Pen & notepad
   └─ Event schedule
7. Total time: 30 seconds
8. Delegate proceeds to event hall
```

#### If Attendance Not Marked:
```
Delegate arrives at kit desk
    ↓
Volunteer searches name
    ↓
System shows: ✗ Attendance not marked
    ↓
Volunteer: "Please go to Express Desk first"
    ↓
Delegate goes to Express Desk
    ↓
Marks attendance via QR/Manual
    ↓
Returns to kit desk
```

---

### **STEP 8: EB Report Generation**

#### What We're Building:
Auto-generated attendance sheets for each committee's Executive Board

#### Report Format (PDF/Excel):
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
         UNITED NATIONS SECURITY COUNCIL
              Attendance Report
           Date: [Event Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUMMARY:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total Registered:    35 delegates
Present:             32 delegates (91.4%)
Absent:              3 delegates (8.6%)
Kits Collected:      30 (93.8% of present)
Kits Pending:        2 (6.2% of present)

Report Generated: 09:30 AM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DELEGATE LIST:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Name             | Country      | Status  | Check-in Time | Kit
─────────────────┼──────────────┼─────────┼───────────────┼─────
John Doe         | USA          | Present | 09:03:45      | ✓
Jane Smith       | UK           | Present | 09:05:12      | ✓
Robert Johnson   | France       | Present | 09:07:33      | ✓
Maria Garcia     | Spain        | Present | 09:10:21      | ✓
...
Alex Kumar       | India        | ABSENT  | -             | -
...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ABSENT DELEGATES:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Alex Kumar (India)
• Sarah Wilson (Germany)
• Mohammed Ali (Egypt)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
This report can be regenerated at any time from
the Admin Dashboard → Committee Reports section
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### When to Generate:
```
Option 1: Real-time (9:30 AM before session starts)
  ├─ EB opens admin dashboard
  ├─ Selects their committee
  ├─ Clicks "Generate Current Report"
  └─ Gets latest status

Option 2: Scheduled (Auto-generate at 9:25 AM)
  ├─ System auto-generates for all committees
  ├─ Emails PDF to each EB email
  └─ Also available in dashboard

Option 3: On-demand (anytime during event)
  ├─ EB can regenerate anytime
  └─ Always shows current data
```

---

### **STEP 9: Data Export Formats**

#### Export Types:

**1. Complete Delegate List (CSV/Excel)**
```csv
Name,Email,Committee,Country,Registration_Number,Attendance_Marked,Attendance_Time,Attendance_Method,Kit_Collected,Arrival_Slot
John Doe,john@email.com,UNSC,USA,MUN2025XXXX,TRUE,2025-11-03 09:03:45,geolocation,TRUE,09:00-09:15
Jane Smith,jane@email.com,UNGA,UK,MUN2025YYYY,TRUE,2025-11-03 09:17:22,qr_scan,TRUE,09:15-09:30
Alex Kumar,alex@email.com,UNHRC,India,MUN2025ZZZZ,FALSE,,,FALSE,09:30-09:45
```

**2. Attendance Only (CSV/Excel)**
```csv
Name,Committee,Country,Check_in_Time,Method
John Doe,UNSC,USA,09:03:45,Geolocation
Jane Smith,UNGA,UK,09:17:22,QR Scan
```

**3. Absent List (CSV/Excel)**
```csv
Name,Email,Committee,Country,Registration_Number
Alex Kumar,alex@email.com,UNHRC,India,MUN2025ZZZZ
```

**4. Committee Summary (PDF)**
```
Per committee breakdown with charts
```

---

### **STEP 10: Technical Architecture**

#### Backend API Endpoints:

```
POST   /api/admin/bulk-upload           Upload CSV, process delegates
POST   /api/admin/generate-emails       Queue emails for all delegates
GET    /api/admin/email-status          Check email sending progress

POST   /api/geolocation-checkin         Mark attendance via GPS
POST   /api/mark-attendance-qr          Mark attendance via QR scan
POST   /api/mark-attendance-manual      Mark attendance manually

POST   /api/kit-collect                 Mark kit as collected
GET    /api/delegates                   Get all delegates (with filters)
GET    /api/delegate/{reg_number}       Get single delegate details
PATCH  /api/delegate/{reg_number}       Update delegate info

GET    /api/stats                       Overall statistics
GET    /api/committee-stats/{committee} Committee-specific stats

GET    /api/generate-eb-report/{committee}  Generate EB PDF report
GET    /api/export/all                  Export all data
GET    /api/export/present              Export present delegates
GET    /api/export/absent               Export absent delegates
GET    /api/export/committee/{committee} Export committee data

GET    /checkin/{unique_token}          Geolocation check-in page
GET    /api/qr-code/{reg_number}        Generate QR code image

POST   /api/admin/login                 Admin authentication
GET    /api/admin/dashboard             Admin dashboard data
```

#### File Structure:
```
mun-attendance-system/
├── backend/
│   ├── main.py                 (FastAPI app)
│   ├── database.py             (SQLAlchemy models)
│   ├── email_service.py        (Email sending)
│   ├── geolocation.py          (Haversine calculations)
│   ├── csv_processor.py        (Bulk upload handler)
│   ├── report_generator.py     (PDF/Excel generation)
│   └── requirements.txt
│
├── frontend/
│   ├── admin_dashboard.html    (Complete admin panel)
│   ├── checkin_page.html       (Geolocation check-in)
│   ├── scanner_station.html    (QR scanner interface)
│   ├── kit_desk.html           (Kit collection interface)
│   └── assets/
│       ├── css/
│       │   └── styles.css
│       └── js/
│           └── app.js
│
├── database/
│   └── mun_complete_system.db  (SQLite database)
│
├── uploads/
│   └── delegates.csv           (Uploaded CSV files)
│
├── exports/
│   ├── reports/                (Generated EB reports)
│   └── data/                   (CSV/Excel exports)
│
└── README.md

---

### **STEP 11: Campus Geofence Configuration**

#### Location Details:
```
Campus Center Coordinates:
Latitude:  28.658500
Longitude: 77.212700

Geofence Radius: 500 meters

Coverage Area:
├─ North Boundary:  28.663000, 77.212700 (500m north)
├─ South Boundary:  28.654000, 77.212700 (500m south)
├─ East Boundary:   28.658500, 77.219200 (500m east)
└─ West Boundary:   28.658500, 77.206200 (500m west)

This covers approximately:
- 0.785 square kilometers
- Entire campus + nearby approach roads
```

#### Distance Calculation Logic:
```python
def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Haversine formula to calculate distance between two GPS points
    Returns distance in meters
    """
    R = 6371000  # Earth radius in meters
    
    φ1 = radians(lat1)
    φ2 = radians(lat2)
    Δφ = radians(lat2 - lat1)
    Δλ = radians(lon2 - lon1)
    
    a = sin(Δφ/2)**2 + cos(φ1) * cos(φ2) * sin(Δλ/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    
    distance = R * c
    return distance

def is_on_campus(delegate_lat, delegate_lon):
    """
    Check if delegate is within campus boundary
    """
    campus_center_lat = 28.658500
    campus_center_lon = 77.212700
    max_distance = 500  # meters
    
    distance = calculate_distance(
        delegate_lat, 
        delegate_lon,
        campus_center_lat,
        campus_center_lon
    )
    
    return distance <= max_distance, distance
```

#### Example Scenarios:
```
Scenario 1: Delegate at main gate
Location: 28.658234, 77.212456
Distance: 34 meters
Result: ✓ Inside campus - Attendance marked

Scenario 2: Delegate at parking lot
Location: 28.658923, 77.213001
Distance: 87 meters
Result: ✓ Inside campus - Attendance marked

Scenario 3: Delegate at nearby cafe
Location: 28.659876, 77.215432
Distance: 623 meters
Result: ✗ Outside campus - Must come closer

Scenario 4: Delegate approaching campus
Location: 28.657123, 77.211890
Distance: 187 meters
Result: ✓ Inside campus - Attendance marked
```

---

### **STEP 12: Email System Configuration**

#### SMTP Setup Options:

**Option A: Gmail SMTP (Recommended for testing)**
```python
SMTP_CONFIG = {
    "server": "smtp.gmail.com",
    "port": 587,
    "email": "your-mun-email@gmail.com",
    "password": "your-app-password",  # Not regular password!
    "use_tls": True
}

Setup Steps:
1. Enable 2-Factor Authentication on Gmail
2. Generate App Password:
   - Go to: https://myaccount.google.com/apppasswords
   - Select "Mail" and device
   - Copy 16-character password
3. Use app password in config
```

**Option B: SendGrid (Recommended for production)**
```python
SMTP_CONFIG = {
    "server": "smtp.sendgrid.net",
    "port": 587,
    "username": "apikey",
    "password": "your-sendgrid-api-key",
    "use_tls": True
}

Advantages:
- Higher sending limits (100/day free, 40k/day paid)
- Better deliverability
- Email analytics
- No Gmail app password hassle
```

**Option C: College Email Server**
```python
SMTP_CONFIG = {
    "server": "smtp.college.edu",
    "port": 587,
    "email": "mun@college.edu",
    "password": "password",
    "use_tls": True
}

Advantages:
- Official college domain
- Higher trust factor
- Often unlimited sending
```

#### Email Queue System:
```
Batch Processing Strategy:
├─ Queue all 200 emails
├─ Send in batches of 10 (to avoid rate limits)
├─ Wait 2 seconds between batches
├─ Track success/failure for each
├─ Retry failed emails (max 3 attempts)
└─ Update admin dashboard with progress

Progress Display:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Email Sending Progress:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[████████████████████░░░░] 80%

Sent: 160/200
Failed: 5
Pending: 35

Failed Emails:
• john@invalid.com - Invalid address
• jane@bounce.com - Mailbox full
• alex@temp.com - Domain not found

[Retry Failed] [Skip Failed] [Cancel]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### **STEP 13: Security & Authentication**

#### Admin Dashboard Protection:

**Login System:**
```
┌─────────────────────────────────────┐
│ MUN Admin Dashboard                 │
├─────────────────────────────────────┤
│ Username: [____________]            │
│ Password: [____________]            │
│                                     │
│ [Login]                             │
│                                     │
│ Forgot password?                    │
└─────────────────────────────────────┘

Default Admin Credentials:
Username: admin
Password: mun2025admin
(Change immediately on first login)
```

**Admin Roles:**
```
1. Super Admin
   - Full access
   - Bulk upload
   - System configuration
   - User management

2. Organizer
   - View all data
   - Manual check-in
   - Generate reports
   - Export data

3. Volunteer
   - QR scanner access
   - Kit collection marking
   - View delegate details
   - No export/bulk operations
```

**Session Management:**
```
- JWT tokens for authentication
- Session expires after 8 hours
- Auto-logout on inactivity (30 min)
- Secure password hashing (bcrypt)
```

---

### **STEP 14: Error Handling & Edge Cases**

#### Common Issues & Solutions:

**Issue 1: Duplicate Email in CSV**
```
Problem: Two delegates with same email
Detection: During CSV upload validation
Solution:
├─ Show error message
├─ Highlight duplicate rows
├─ Require correction before processing
└─ Admin must fix CSV and re-upload
```

**Issue 2: Invalid Committee Name**
```
Problem: CSV has "UN-SC" instead of "UNSC"
Detection: During CSV validation
Solution:
├─ Show list of invalid committees
├─ Provide valid committee names
├─ Allow bulk find-replace
└─ Admin corrects and re-uploads
```

**Issue 3: Location Permission Denied**
```
Problem: Delegate clicks link but denies location
Flow:
Delegate clicks link
    ↓
Browser asks permission
    ↓
Delegate clicks "Block"
    ↓
Page shows:
┌─────────────────────────────────────┐
│ ✗ Location Permission Required      │
├─────────────────────────────────────┤
│ To use automatic check-in, please:  │
│ 1. Enable location in browser       │
│ 2. Reload this page                 │
│ 3. Click "Allow" when prompted      │
│                                     │
│ [Retry]                             │
│                                     │
│ Alternative:                         │
│ Go to registration desk and show    │
│ your QR code for manual check-in    │
└─────────────────────────────────────┘
```

**Issue 4: GPS Inaccuracy**
```
Problem: GPS shows delegate 520m away (just outside boundary)
Scenarios:
├─ Poor GPS signal
├─ Phone in power saving mode
├─ Indoor location detection

Solution:
├─ Show distance: "You are 520m away"
├─ Provide grace message:
│  "You're very close! Try these:
│   • Step outside if indoors
│   • Wait 10 seconds for better GPS
│   • Walk closer to main building
│   • Or use QR code at desk"
└─ Manual override option for volunteers
```

**Issue 5: Already Marked Attendance**
```
Problem: Delegate clicks link twice
Flow:
First click → ✓ Marked successfully
Second click → Shows:
┌─────────────────────────────────────┐
│ ✓ Already Checked In                │
├─────────────────────────────────────┤
│ John Doe                            │
│ Check-in time: 09:03:45 AM         │
│                                     │
│ Your attendance is already recorded │
│                                     │
│ Next Step:                          │
│ → Proceed to Kit Collection Desk    │
│    Lane: A-F                        │
│                                     │
│ Kit Status: Not collected           │
└─────────────────────────────────────┘
```

**Issue 6: Payment Not Confirmed**
```
Problem: Delegate tries to check in but payment pending
Flow:
Delegate clicks link
    ↓
Location verified (on campus)
    ↓
Backend checks payment_status
    ↓
payment_status = FALSE
    ↓
Response:
┌─────────────────────────────────────┐
│ ⚠ Payment Pending                   │
├─────────────────────────────────────┤
│ Your attendance cannot be marked    │
│ because your payment is pending.    │
│                                     │
│ Please visit the registration desk  │
│ to complete payment verification.   │
│                                     │
│ Registration: MUN2025XXXX           │
└─────────────────────────────────────┘
```

**Issue 7: Link Expired/Invalid**
```
Problem: Delegate clicks corrupted or old link
Flow:
Invalid token → Shows:
┌─────────────────────────────────────┐
│ ✗ Invalid Check-in Link             │
├─────────────────────────────────────┤
│ This link is not valid or may have  │
│ expired.                            │
│                                     │
│ Please check your email for the     │
│ correct link or visit registration  │
│ desk for assistance.                │
│                                     │
│ Contact: mun@college.edu            │
└─────────────────────────────────────┘
```

---

### **STEP 15: Testing Plan**

#### Testing Phases:

**Phase 1: Backend Testing (Week 1)**
```
Test CSV Upload:
├─ Valid CSV with 5 delegates
├─ CSV with duplicate emails
├─ CSV with invalid committees
├─ CSV with missing columns
└─ Large CSV with 200 delegates

Test Geolocation:
├─ Coordinates inside boundary
├─ Coordinates outside boundary
├─ Coordinates exactly at 500m
├─ Invalid coordinates
└─ Missing coordinates

Test Attendance Marking:
├─ First time check-in
├─ Duplicate check-in
├─ Multiple methods (geo, QR, manual)
├─ Payment pending scenario
└─ Invalid tokens

Test Kit Collection:
├─ Mark kit collected
├─ Collect kit without attendance
├─ Already collected scenario
└─ Bulk kit operations
```

**Phase 2: Frontend Testing (Week 2)**
```
Test Admin Dashboard:
├─ Upload CSV file
├─ View delegate list with filters
├─ Manual check-in process
├─ QR scanner functionality
├─ Export downloads (CSV, Excel, PDF)
├─ Committee report generation
└─ Real-time statistics update

Test Geolocation Page:
├─ Valid location on campus
├─ Invalid location off campus
├─ Permission denied scenario
├─ Already marked scenario
├─ Mobile responsiveness
└─ Different browsers

Test Scanner Station:
├─ Paste QR data
├─ Invalid QR data
├─ Already marked QR
├─ Camera scanning (if HTTPS)
└─ Multiple rapid scans
```

**Phase 3: Integration Testing (Week 3)**
```
End-to-End Flow:
1. Upload 10 test delegates
2. Verify emails sent
3. Click unique links on phones
4. Test on campus (use VPN/location spoofing)
5. Test off campus
6. Try QR scan backup
7. Try manual entry
8. Collect kits
9. Generate EB reports
10. Export all data
```

**Phase 4: Load Testing (Week 3)**
```
Simulate 200 delegates:
├─ 160 geolocation check-ins simultaneously
├─ 30 QR scans within 5 minutes
├─ 10 manual entries
├─ All accessing dashboard together
└─ Verify no crashes or slowdowns
```

**Phase 5: Event Day Dry Run (Week 4)**
```
Full Simulation:
├─ Setup tablets at 4 kit desks
├─ Setup 1 express desk tablet
├─ 10 volunteers act as delegates
├─ Test all three methods
├─ Time each process
├─ Generate EB reports
├─ Check for bottlenecks
└─ Fix any issues found
```

---

### **STEP 16: Event Day Setup Checklist**

#### One Day Before Event:

**Admin Tasks:**
```
□ Verify all 200 delegates in system
□ Confirm payment status for all
□ Send pre-check-in reminder emails
□ Generate preliminary EB reports
□ Print backup delegate list (paper)
□ Charge all tablets/devices
□ Test internet connectivity at venue
□ Prepare delegate kits by alphabet
□ Print signage for lanes (A-F, G-M, etc.)
□ Brief all volunteers (15 min session)
```

**Volunteer Briefing Content:**
```
Kit Desk Volunteers (4 people):
1. How to use admin dashboard
2. Search delegate by name
3. Verify attendance is marked
4. Click "Mark Kit Collected"
5. Hand over materials
6. What to do if attendance not marked
7. How to handle issues

Express Desk Volunteer (1 person):
1. How to scan QR codes
2. How to manually enter names
3. When to call organizer
4. Payment issue handling
```

#### Event Day Morning (8:00 AM - 1 hour before):

**Setup Checklist:**
```
ENTRANCE AREA:
□ Setup Express Desk
   └─ 1 tablet with scanner app loaded
   └─ Power bank backup
   └─ Signage: "Express Check-in - QR/Manual"

KIT COLLECTION ZONE:
□ Setup 4 desks in row
   └─ Desk 1: Lane A-F
      ├─ Tablet with admin dashboard
      ├─ Kit boxes (A-F names)
      └─ Signage
   └─ Desk 2: Lane G-M
      ├─ Tablet with admin dashboard
      ├─ Kit boxes (G-M names)
      └─ Signage
   └─ Desk 3: Lane N-S
      ├─ Tablet with admin dashboard
      ├─ Kit boxes (N-S names)
      └─ Signage
   └─ Desk 4: Lane T-Z
      ├─ Tablet with admin dashboard
      ├─ Kit boxes (T-Z names)
      └─ Signage

□ Floor markings/stanchions for queuing
□ Directional signage throughout
□ WiFi connectivity verified
□ All tablets logged into admin dashboard
□ Backup printed list at each desk

ADMIN CONTROL:
□ Organizer laptop with admin dashboard
□ Monitor real-time statistics
□ Ready to generate EB reports at 9:30 AM
□ Contact numbers for tech support
```

#### During Event (9:00 AM - 10:30 AM):

**Monitoring Tasks:**
```
Admin Dashboard - Monitor:
├─ Check-in rate (target: 150+ by 9:30)
├─ Committee-wise attendance
├─ Kit collection rate
├─ Any error patterns
└─ Volunteer requests

Every 15 Minutes:
├─ Generate updated stats
├─ Share with organizing team
├─ Identify absent delegates
└─ Prepare for EB report generation

At 9:30 AM:
├─ Generate all EB reports
├─ Print for each committee
├─ Email to EB members
└─ Deliver physical copies to rooms
```

---

### **STEP 17: Post-Event Analytics**

#### Data to Collect:

**Attendance Metrics:**
```
Overall:
├─ Total registered: 200
├─ Total present: 185 (92.5%)
├─ Total absent: 15 (7.5%)
├─ Average check-in time: 9:12 AM
└─ Total processing duration: 28 minutes

By Method:
├─ Geolocation: 148 (80%) - Avg time: 10 sec
├─ QR Scan: 32 (17.3%) - Avg time: 28 sec
└─ Manual: 5 (2.7%) - Avg time: 35 sec

By Committee:
├─ UNSC: 32/35 (91.4%)
├─ UNGA: 45/50 (90%)
├─ UNHRC: 28/30 (93.3%)
├─ DISEC: 42/45 (93.3%)
└─ ECOSOC: 38/40 (95%)

By Time Slot:
├─ 09:00-09:15 (UNSC): 29 checked in on time, 3 late
├─ 09:15-09:30 (UNGA): 41 on time, 4 late
├─ 09:30-09:45 (UNHRC): 26 on time, 2 late
└─ etc.
```

**Kit Distribution Metrics:**
```
├─ Total kits prepared: 200
├─ Kits distributed: 178
├─ Pending collection: 7 (of present delegates)
├─ Average kit handover time: 32 seconds
└─ Lane efficiency:
    ├─ Lane A-F: 48 kits in 24 minutes
    ├─ Lane G-M: 52 kits in 26 minutes
    ├─ Lane N-S: 43 kits in 22 minutes
    └─ Lane T-Z: 35 kits in 18 minutes
```

**System Performance:**
```
├─ Email delivery rate: 198/200 (99%)
├─ Geolocation accuracy: 95% (7 needed to retry)
├─ QR scan success rate: 100%
├─ Dashboard uptime: 100%
├─ Database queries: 1,247 total
└─ Average response time: 0.8 seconds
```

**Issues Encountered:**
```
Minor Issues:
├─ 7 delegates couldn't get location initially (poor GPS)
├─ 2 delegates' emails bounced (invalid addresses)
├─ 1 tablet battery died (backup worked)
└─ 3 delegates went to wrong lane initially

Major Issues:
└─ None reported
```

---





#
## 🎯 Summary: What Makes This System Work

### **Key Success Factors:**

1. **Three Check-in Methods**
   - Primary (80%): Geolocation - Zero volunteer needed
   - Backup (15%): QR Code - Reliable fallback
   - Emergency (5%): Manual - Always works

2. **Distributed Processing**
   - Not one desk, but 5 stations
   - Attendance happens automatically
   - Kit desks only distribute

3. **Real-time Visibility**
   - Admin sees everything live
   - EB gets instant reports
   - No waiting for data

4. **Foolproof Backups**
   - Multiple check-in methods
   - Printed lists as backup
   - Manual override always available

5. **Delegate Experience**
   - Click link → 10 seconds → Done
   - No standing in queue
   - Professional, modern experience

---

## 📝 Next Steps

1. **Review this plan with organizing team**
2. **Assign roles (developers, volunteers, etc.)**
3. **Set timeline based on event date**
4. **Start with Week 1 development**
5. **Test thoroughly in Week 3**
6. **Train volunteers in Week 4**
7. **Execute flawlessly on event day**

---

**This system will transform your MUN from chaotic to professional. Let's build it! 🚀**