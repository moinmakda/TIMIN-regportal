#!/bin/bash
# TIMUN Attendance System - Production Startup Script
# Handles 700 concurrent users easily!

echo "🚀 Starting TIMUN Attendance System..."

# Kill any existing gunicorn processes
pkill -f "gunicorn backend.main:app" 2>/dev/null
sleep 2

# Start the server with 8 workers (more than enough for 700 users)
echo "✅ Starting server with 8 workers..."
cd /Users/moinmakda/Desktop/TIMUN-regdesk

./venv/bin/gunicorn backend.main:app \
    --workers 8 \
    --worker-class uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:8000 \
    --timeout 600 \
    --worker-connections 1000 \
    --backlog 2048 \
    --access-logfile - \
    --error-logfile - \
    --daemon

sleep 3

# Check if server started successfully
if curl -s http://localhost:8000/health > /dev/null; then
    echo "✅ Server started successfully!"
    echo "🌐 Access at: http://localhost:8000"
    echo "📊 Admin panel: http://localhost:8000/admin"
    echo ""
    echo "Database Status:"
    echo "  • 700 delegates registered"
    echo "  • PostgreSQL database (300 connection pool)"
    echo "  • 8 workers for concurrent handling"
    echo ""
    echo "To stop the server: pkill -f 'gunicorn backend.main:app'"
else
    echo "❌ Server failed to start. Check logs with:"
    echo "   tail -f /tmp/gunicorn.log"
fi
