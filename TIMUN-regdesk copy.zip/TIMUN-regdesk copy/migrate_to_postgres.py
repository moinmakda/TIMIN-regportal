#!/usr/bin/env python3
"""
Migrate data from SQLite to PostgreSQL
"""
import sys
sys.path.insert(0, "/Users/moinmakda/Desktop/TIMUN-regdesk/backend")

# Import SQLite database
from database_sqlite_backup import engine as sqlite_engine, Delegate as SQLiteDelegate
from sqlalchemy.orm import sessionmaker as sqlite_sessionmaker

# Import PostgreSQL database
from database import init_database, SessionLocal as pg_session, Delegate as PGDelegate

print("🔄 Starting migration from SQLite to PostgreSQL...")

# Initialize PostgreSQL tables
init_database()

# Create SQLite session
SQLiteSession = sqlite_sessionmaker(bind=sqlite_engine)
sqlite_db = SQLiteSession()

# Get all delegates from SQLite
print("📊 Reading delegates from SQLite...")
sqlite_delegates = sqlite_db.query(SQLiteDelegate).all()
print(f"   Found {len(sqlite_delegates):,} delegates")

# Migrate to PostgreSQL
print("📝 Writing to PostgreSQL...")
pg_db = pg_session()

migrated = 0
for delegate in sqlite_delegates:
    try:
        pg_delegate = PGDelegate(
            registration_number=delegate.registration_number,
            name=delegate.name,
            email=delegate.email,
            committee=delegate.committee,
            country=delegate.country,
            school=delegate.school,
            qr_code_token=delegate.qr_code_token,
            unique_checkin_link=delegate.unique_checkin_link,
            arrival_slot=delegate.arrival_slot,
            payment_status=delegate.payment_status,
            attendance_marked=delegate.attendance_marked,
            attendance_time=delegate.attendance_time,
            kit_collected=delegate.kit_collected,
            kit_collected_time=delegate.kit_collected_time,
        )
        pg_db.add(pg_delegate)
        migrated += 1
        
        if migrated % 1000 == 0:
            pg_db.commit()
            print(f"   ✓ Migrated {migrated:,} / {len(sqlite_delegates):,}")
    except Exception as e:
        print(f"   ⚠️  Failed to migrate {delegate.registration_number}: {e}")
        pg_db.rollback()

pg_db.commit()
pg_db.close()
sqlite_db.close()

print(f"\n✅ Migration complete!")
print(f"   Total: {migrated:,} delegates migrated to PostgreSQL")
print(f"   Database: postgresql://localhost/timun_attendance")
